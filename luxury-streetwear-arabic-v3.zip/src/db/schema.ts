import { integer, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import type { CustomerDetails, OrderLine, OrderStatus, PaymentMethod, SizeStock } from "@/lib/store-data";

export const products = pgTable("mx_abdou_products", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  shortName: text("short_name").notNull(),
  category: text("category").notNull(),
  price: integer("price").notNull(),
  description: text("description").notNull(),
  fabric: text("fabric").notNull(),
  fit: text("fit").notNull(),
  care: jsonb("care").$type<string[]>().notNull(),
  sizeChart: jsonb("size_chart").$type<Record<string, string>>().notNull(),
  stock: jsonb("stock").$type<SizeStock>().notNull(),
  art: text("art").notNull(),
  frontImage: text("front_image"),
  backImage: text("back_image"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const orders = pgTable("mx_abdou_orders", {
  id: text("id").primaryKey(),
  receipt: text("receipt").notNull().unique(),
  customer: jsonb("customer").$type<CustomerDetails>().notNull(),
  items: jsonb("items").$type<OrderLine[]>().notNull(),
  total: integer("total").notNull(),
  payment: text("payment").$type<PaymentMethod>().notNull(),
  status: text("status").$type<OrderStatus>().notNull().default("Pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});
