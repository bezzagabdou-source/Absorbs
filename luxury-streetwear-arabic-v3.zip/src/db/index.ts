import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

// Do not throw at import time: `next build` imports every route, and DATABASE_URL may be
// missing then. The pool connects lazily, so queries simply fail (and routes fall back) until it is set.
const databaseUrl = process.env.DATABASE_URL ?? "postgresql://missing:missing@localhost:5432/missing";

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

export const pool =
  globalForDb.__arenaNextJsPostgresqlPool ??
  new Pool({
    connectionString: databaseUrl,
  });

if (process.env.NODE_ENV !== "production") {
  globalForDb.__arenaNextJsPostgresqlPool = pool;
}

export const db = drizzle(pool);
