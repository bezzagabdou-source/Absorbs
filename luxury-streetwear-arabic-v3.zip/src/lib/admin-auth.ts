export function isAdminPinValid(pin: string | null | undefined): boolean {
  const expected = process.env.ADMIN_PIN || "2026";
  return Boolean(pin) && pin === expected;
}

export function isAdminRequest(request: Request): boolean {
  return isAdminPinValid(request.headers.get("x-admin-pin"));
}
