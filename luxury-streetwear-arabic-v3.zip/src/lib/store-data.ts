export const SIZES = ["S", "M", "L", "XL", "2XL"] as const;
export type Size = (typeof SIZES)[number];
export type SizeStock = Record<Size, number>;
export type Category = "JACKETS" | "SHIRTS" | "HOODIES" | "PANTS";
export type Currency = "DZD" | "USD" | "EUR";
export type ProductArt = "photo";

export type StoreProduct = {
  id: string;
  name: string;
  shortName: string;
  category: Category;
  price: number;
  description: string;
  fabric: string;
  fit: string;
  care: string[];
  sizeChart: Record<"Chest" | "Length" | "Shoulder", string>;
  stock: SizeStock;
  art: ProductArt;
  frontImage?: string;
  backImage?: string;
};

export type CartEntry = {
  productId: string;
  size: Size;
  quantity: number;
};

export type CustomerDetails = {
  /** الاسم الكامل (الاسم + اللقب) — يبقى موجوداً ليعمل البحث ولوحة الإدارة والطلبات القديمة */
  name: string;
  firstName?: string;
  lastName?: string;
  phone: string;
  wilaya: string;
  commune?: string;
  address?: string;
  notes?: string;
};

export type OrderStatus = "Pending" | "Confirmed" | "Shipped" | "Delivered";
export type PaymentMethod = "Cash on delivery" | "Card / Express";

export type OrderLine = {
  productId: string;
  title: string;
  art: ProductArt;
  frontImage?: string;
  price: number;
  size: Size;
  quantity: number;
};

export type StoreOrder = {
  id: string;
  receipt: string;
  customer: CustomerDetails;
  items: OrderLine[];
  total: number;
  payment: PaymentMethod;
  status: OrderStatus;
  createdAt: string;
};

const standardStock = (): SizeStock => ({ S: 5, M: 8, L: 7, XL: 4, "2XL": 2 });

export const LEGACY_SEED_IDS = [
  "vca-strike-shirt",
  "cream-varsity-bomber",
  "crimson-racing-jacket",
  "obsidian-technical-hoodie",
  "slate-teal-track-jacket",
  "monochrome-pinstripe-shirt",
  "washed-charcoal-tee",
  "desert-cargo-overshirt",
];

export const seedProducts: StoreProduct[] = [
  {
    id: "jordan-gloss-black-puffer",
    name: "جاكيت جوردن منفوخ أسود لامع بقبعة",
    shortName: "جوردن أسود لامع",
    category: "JACKETS",
    price: 24500,
    description: "جاكيت منفوخ أسود عميق بلمعة عالية وشعار الجامبمان الأحمر على الصدر.",
    fabric: "قشرة لامعة مقاومة للماء · حشوة ناعمة · قبعة مبطّنة",
    fit: "قصّة عادية · أساور وحافة مرنة",
    care: ["غسيل بارد بدورة لطيفة", "أغلق السحّابات قبل الغسيل", "تجفيف بحرارة منخفضة مع كرات التجفيف", "يُمنع الكي"],
    sizeChart: { Chest: "60 سم", Length: "66 سم", Shoulder: "52 سم" },
    stock: standardStock(),
    art: "photo",
    frontImage: "/products/jordan-black.webp",
  },
  {
    id: "jordan-pink-gloss-puffer",
    name: "جاكيت جوردن منفوخ وردي لامع بقبعة",
    shortName: "جوردن وردي لامع",
    category: "JACKETS",
    price: 24500,
    description: "وردي باستيل ناعم بلمعة لؤلؤية وقصّات منفوخة وشعار جامبمان أسود.",
    fabric: "قشرة لامعة مقاومة للماء · حشوة ناعمة · قبعة مبطّنة",
    fit: "قصّة عادية · أساور وحافة مرنة",
    care: ["غسيل بارد بدورة لطيفة", "أغلق السحّابات قبل الغسيل", "تجفيف بحرارة منخفضة مع كرات التجفيف", "يُمنع الكي"],
    sizeChart: { Chest: "58 سم", Length: "64 سم", Shoulder: "50 سم" },
    stock: { S: 3, M: 6, L: 6, XL: 3, "2XL": 1 },
    art: "photo",
    frontImage: "/products/jordan-pink.webp",
  },
  {
    id: "cross-tie-dye-fleece",
    name: "جاكيت فرو صناعي بنقشة تاي داي وصليب مطرّز",
    shortName: "فرو تاي داي",
    category: "JACKETS",
    price: 18900,
    description: "جاكيت فرو صناعي ناعم بنقشة سحابية وياقة عالية وصليب مطرّز على الصدر.",
    fabric: "فرو صناعي من الخارج · بطانة صوف ناعمة",
    fit: "قصّة مريحة · ياقة عالية · أساور وحافة مرنة",
    care: ["غسيل يدوي بارد أو دورة لطيفة", "يُمنع المبيّض", "تجفيف أفقي في الهواء", "مشّط الفرو بلطف لاستعادة نعومته"],
    sizeChart: { Chest: "64 سم", Length: "68 سم", Shoulder: "58 سم" },
    stock: { S: 4, M: 7, L: 7, XL: 4, "2XL": 2 },
    art: "photo",
    frontImage: "/products/fleece-cross.webp",
  },
  {
    id: "nike-black-down-puffer",
    name: "جاكيت نايك منفوخ أسود بقبعة",
    shortName: "نايك أسود منفوخ",
    category: "JACKETS",
    price: 29900,
    description: "جاكيت منفوخ أسود مطفي وقبعة وقصّات متعرجة وجيوب بسحّاب وشعار نايك صغير.",
    fabric: "قشرة ريب ستوب طاردة للماء · حشوة عازلة · سحّاب أمامي كامل",
    fit: "قصّة عادية · قبعة قابلة للتعديل · جيوب بسحّاب",
    care: ["غسيل آلي بارد بدورة لطيفة", "أغلق كل السحّابات قبل الغسيل", "تجفيف بحرارة منخفضة", "يُمنع المبيّض"],
    sizeChart: { Chest: "62 سم", Length: "72 سم", Shoulder: "55 سم" },
    stock: { S: 2, M: 5, L: 6, XL: 4, "2XL": 3 },
    art: "photo",
    frontImage: "/products/nike-puffer.webp",
  },
  {
    id: "moncler-blue-gloss-puffer",
    name: "جاكيت مونكلير منفوخ أزرق لامع بقبعة",
    shortName: "مونكلير أزرق لامع",
    category: "JACKETS",
    price: 78000,
    description: "أزرق ملكي لامع بقصّات منفوخة عريضة وقبعة قابلة للفك وشارة الديك على الذراع. قطعة تُرى من بعيد.",
    fabric: "قشرة لامعة مقاومة للماء · حشوة دافئة · قبعة قابلة للفك",
    fit: "قصّة عادية · أساور مرنة · جيوب بسحّاب",
    care: ["غسيل بارد بدورة لطيفة", "أغلق السحّابات قبل الغسيل", "تجفيف بحرارة منخفضة مع كرات التجفيف", "يُمنع الكي"],
    sizeChart: { Chest: "62 سم", Length: "68 سم", Shoulder: "54 سم" },
    stock: { S: 2, M: 4, L: 4, XL: 2, "2XL": 1 },
    art: "photo",
    frontImage: "/products/moncler-blue.webp",
  },
  {
    id: "tnf-purple-nuptse-puffer",
    name: "جاكيت ذا نورث فيس نوبتسي بنفسجي",
    shortName: "نورث فيس بنفسجي",
    category: "JACKETS",
    price: 32500,
    description: "بنفسجي عميق مع كتفين أسودين وشعار مطرّز على الصدر. قصّة كلاسيكية من التسعينات.",
    fabric: "قشرة ريب ستوب · حشوة منفوخة · سحّاب أمامي كامل",
    fit: "قصّة قصيرة · ياقة عالية · جيوب جانبية",
    care: ["غسيل بارد بدورة لطيفة", "أغلق السحّابات قبل الغسيل", "تجفيف بحرارة منخفضة مع كرات التجفيف", "يُمنع الكي"],
    sizeChart: { Chest: "60 سم", Length: "60 سم", Shoulder: "52 سم" },
    stock: { S: 5, M: 8, L: 7, XL: 4, "2XL": 2 },
    art: "photo",
    frontImage: "/products/tnf-purple.webp",
  },
  {
    id: "tnf-grey-nuptse-puffer",
    name: "جاكيت ذا نورث فيس نوبتسي رمادي",
    shortName: "نورث فيس رمادي",
    category: "JACKETS",
    price: 32500,
    description: "رمادي هادئ يميل إلى الموف مع كتفين أسودين وشعار أبيض. يلبس مع كل شيء.",
    fabric: "قشرة ناعمة · حشوة منفوخة · سحّاب أمامي كامل",
    fit: "قصّة قصيرة · ياقة عالية · جيوب بسحّاب",
    care: ["غسيل بارد بدورة لطيفة", "أغلق السحّابات قبل الغسيل", "تجفيف بحرارة منخفضة مع كرات التجفيف", "يُمنع الكي"],
    sizeChart: { Chest: "58 سم", Length: "58 سم", Shoulder: "50 سم" },
    stock: { S: 5, M: 8, L: 7, XL: 4, "2XL": 2 },
    art: "photo",
    frontImage: "/products/tnf-grey.webp",
  },
  {
    id: "sky-blue-puffer-jacket",
    name: "جاكيت منفوخ أزرق سماوي",
    shortName: "منفوخ أزرق سماوي",
    category: "JACKETS",
    price: 14900,
    description: "أزرق سماوي فاتح بقصّة واسعة وياقة عالية وأساور مرنة. خفيف في المظهر ودافئ في الاستعمال.",
    fabric: "قشرة ناعمة · حشوة منفوخة · سحّاب أمامي كامل",
    fit: "قصّة واسعة · ياقة عالية · جيوب جانبية",
    care: ["غسيل بارد بدورة لطيفة", "أغلق السحّابات قبل الغسيل", "تجفيف بحرارة منخفضة مع كرات التجفيف", "يُمنع الكي"],
    sizeChart: { Chest: "66 سم", Length: "66 سم", Shoulder: "58 سم" },
    stock: { S: 5, M: 8, L: 7, XL: 4, "2XL": 2 },
    art: "photo",
    frontImage: "/products/sky-puffer.webp",
  },
  {
    id: "nike-black-puffer-vest",
    name: "جيليه نايك منفوخ أسود",
    shortName: "جيليه نايك أسود",
    category: "JACKETS",
    price: 16900,
    description: "جيليه أسود بدون أكمام وياقة عالية وجيوب بسحّاب وشعار نايك صغير. طبقة مثالية فوق السترة.",
    fabric: "قشرة مقاومة للماء · حشوة منفوخة · سحّاب أمامي كامل",
    fit: "قصّة عادية · ياقة عالية · جيوب بسحّاب",
    care: ["غسيل بارد بدورة لطيفة", "أغلق السحّابات قبل الغسيل", "تجفيف بحرارة منخفضة مع كرات التجفيف", "يُمنع الكي"],
    sizeChart: { Chest: "58 سم", Length: "68 سم", Shoulder: "– سم" },
    stock: { S: 4, M: 7, L: 7, XL: 3, "2XL": 2 },
    art: "photo",
    frontImage: "/products/nike-vest.webp",
  },
];

export const WILAYAS = [
  "Adrar", "Chlef", "Laghouat", "Oum El Bouaghi", "Batna", "Béjaïa", "Biskra", "Béchar",
  "Blida", "Bouira", "Tamanrasset", "Tébessa", "Tlemcen", "Tiaret", "Tizi Ouzou", "Algiers",
  "Djelfa", "Jijel", "Sétif", "Saïda", "Skikda", "Sidi Bel Abbès", "Annaba", "Guelma",
  "Constantine", "Médéa", "Mostaganem", "M'Sila", "Mascara", "Ouargla", "Oran", "El Bayadh",
  "Illizi", "Bordj Bou Arréridj", "Boumerdès", "El Tarf", "Tindouf", "Tissemsilt", "El Oued",
  "Khenchela", "Souk Ahras", "Tipaza", "Mila", "Aïn Defla", "Naâma", "Aïn Témouchent",
  "Ghardaïa", "Relizane", "Timimoun", "Bordj Badji Mokhtar", "Ouled Djellal", "Béni Abbès",
  "In Salah", "In Guezzam", "Touggourt", "Djanet", "El M'Ghair", "El Meniaa",
];

export const CATEGORY_AR: Record<Category | "ALL", string> = { ALL: "الكل", JACKETS: "جاكيتات", SHIRTS: "قمصان", HOODIES: "هوديز", PANTS: "سراويل" };

export const ACCENTS: Record<string, string> = {
  "jordan-gloss-black-puffer": "#d7192d",
  "jordan-pink-gloss-puffer": "#f08cb3",
  "cross-tie-dye-fleece": "#8ea0e0",
  "nike-black-down-puffer": "#5a5a5a",
  "moncler-blue-gloss-puffer": "#1f4bff",
  "tnf-purple-nuptse-puffer": "#7a35d6",
  "tnf-grey-nuptse-puffer": "#9a91a8",
  "sky-blue-puffer-jacket": "#7fa8ee",
  "nike-black-puffer-vest": "#3a3a3a",
};
export const NEW_SEED_IDS = ["moncler-blue-gloss-puffer", "tnf-purple-nuptse-puffer", "tnf-grey-nuptse-puffer", "sky-blue-puffer-jacket", "nike-black-puffer-vest"];
export const ORIGINAL_ENGLISH_NAMES: Record<string, string> = {
  "jordan-gloss-black-puffer": "Jordan Gloss Black Hooded Puffer Jacket",
  "jordan-pink-gloss-puffer": "Jordan Pink Gloss Hooded Puffer Jacket",
  "cross-tie-dye-fleece": "Cross Embroidered Tie-Dye Faux Fur Zip Jacket",
  "nike-black-down-puffer": "Nike Black Hooded Down-Fill Puffer Jacket",
};
