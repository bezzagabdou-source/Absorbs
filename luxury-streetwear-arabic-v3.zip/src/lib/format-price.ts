import type { Currency } from "@/lib/store-data";

export function formatPrice(price: number, currency: Currency): string {
  if (currency === "USD") {
    return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(price * 0.0074);
  }
  if (currency === "EUR") {
    return new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(price * 0.0068);
  }
  return `${new Intl.NumberFormat("fr-DZ", { maximumFractionDigits: 0 }).format(price)} DA`;
}
