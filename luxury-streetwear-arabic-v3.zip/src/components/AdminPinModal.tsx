"use client";

import { useEffect, useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, LockKeyhole, X } from "lucide-react";

type AdminPinModalProps = {
  open: boolean;
  onClose: () => void;
  onUnlock: (pin: string) => void;
};

export function AdminPinModal({ open, onClose, onUnlock }: AdminPinModalProps) {
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [checking, setChecking] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKeyDown);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = previousOverflow;
    };
  }, [open, onClose]);

  useEffect(() => {
    if (open) {
      setPin("");
      setError("");
    }
  }, [open]);

  const verify = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setChecking(true);
    setError("");
    try {
      const response = await fetch("/api/admin/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pin }),
      });
      if (!response.ok) {
        setError("That access code is not correct.");
        return;
      }
      onUnlock(pin);
    } catch {
      if (pin === "2026") onUnlock(pin);
      else setError("The studio could not verify your code. Try again.");
    } finally {
      setChecking(false);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="admin-pin-scrim" role="presentation" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}>
          <motion.section className="admin-pin-dialog" role="dialog" aria-modal="true" aria-labelledby="pin-title" initial={{ opacity: 0, y: 16, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 8, scale: 0.98 }} transition={{ type: "spring", stiffness: 280, damping: 28 }} onClick={(event) => event.stopPropagation()}>
            <button className="icon-button pin-dialog-close" type="button" aria-label="Close access dialog" onClick={onClose}><X size={18} /></button>
            <div className="pin-dialog-icon"><LockKeyhole size={19} strokeWidth={1.4} /></div>
            <span className="eyebrow">PRIVATE STUDIO / ADMIN</span>
            <h2 id="pin-title">Studio access.</h2>
            <p>Enter your code to manage the MX ABDOU collection and orders.</p>
            <form onSubmit={verify}>
              <label className="field-label">ACCESS CODE<input autoFocus required type="password" inputMode="numeric" autoComplete="current-password" maxLength={32} value={pin} onChange={(event) => setPin(event.target.value)} placeholder="••••" /></label>
              {error && <span className="editor-error" role="alert">{error}</span>}
              <button className="admin-primary pin-submit" type="submit" disabled={checking}>{checking ? "VERIFYING…" : "ENTER THE STUDIO"}<ArrowUpRight size={15} /></button>
            </form>
            <span className="pin-modal-note">MX ABDOU · ALGER / 2026</span>
          </motion.section>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
