"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  seedProducts,
  type CartEntry,
  type CustomerDetails,
  type OrderLine,
  type OrderStatus,
  type PaymentMethod,
  type Size,
  type StoreOrder,
  type StoreProduct,
} from "@/lib/store-data";

type StoreContextValue = {
  products: StoreProduct[];
  cart: CartEntry[];
  wishlist: string[];
  orders: StoreOrder[];
  adminPin: string;
  ready: boolean;
  bagCount: number;
  subtotal: number;
  setAdminPin: (pin: string) => void;
  addToCart: (product: StoreProduct, size: Size) => boolean;
  setCartQuantity: (productId: string, size: Size, quantity: number) => void;
  removeFromCart: (productId: string, size: Size) => void;
  clearCart: () => void;
  toggleWishlist: (productId: string) => void;
  submitOrder: (customer: CustomerDetails, payment: PaymentMethod) => Promise<StoreOrder>;
  upsertProduct: (product: StoreProduct) => Promise<boolean>;
  removeProduct: (productId: string) => Promise<boolean>;
  updateOrderStatus: (orderId: string, status: OrderStatus) => Promise<boolean>;
};

const StoreContext = createContext<StoreContextValue | null>(null);
const STORAGE = {
  products: "mx-abdou-products-v1",
  cart: "mx-abdou-bag-v1",
  wishlist: "mx-abdou-wishlist-v1",
  orders: "mx-abdou-orders-v1",
  adminPin: "mx-abdou-admin-pin-v1",
};

function readStored<T>(key: string, fallback: T): T {
  try {
    const value = window.localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

function saveStored(key: string, value: unknown) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.warn("MX ABDOU could not update the local cache.", error);
  }
}

function replaceProduct(products: StoreProduct[], product: StoreProduct) {
  const index = products.findIndex((candidate) => candidate.id === product.id);
  if (index === -1) return [...products, product];
  return products.map((candidate) => candidate.id === product.id ? product : candidate);
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<StoreProduct[]>(seedProducts);
  const [cart, setCart] = useState<CartEntry[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [orders, setOrders] = useState<StoreOrder[]>([]);
  const [adminPin, setAdminPinState] = useState("");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let mounted = true;
    const localProducts = readStored<StoreProduct[]>(STORAGE.products, seedProducts);
    setProducts(localProducts);
    setCart(readStored<CartEntry[]>(STORAGE.cart, []));
    setWishlist(readStored<string[]>(STORAGE.wishlist, []));
    setOrders(readStored<StoreOrder[]>(STORAGE.orders, []));
    setAdminPinState(window.localStorage.getItem(STORAGE.adminPin) ?? "");

    void (async () => {
      try {
        const response = await fetch("/api/products", { cache: "no-store" });
        if (response.ok) {
          const remoteProducts = (await response.json()) as StoreProduct[];
          if (mounted && Array.isArray(remoteProducts) && remoteProducts.length > 0) {
            setProducts(remoteProducts);
            saveStored(STORAGE.products, remoteProducts);
          }
        }
      } catch {
        // The local catalogue remains fully usable when the network is unavailable.
      } finally {
        if (mounted) setReady(true);
      }
    })();

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    saveStored(STORAGE.products, products);
    saveStored(STORAGE.cart, cart);
    saveStored(STORAGE.wishlist, wishlist);
    saveStored(STORAGE.orders, orders);
  }, [products, cart, wishlist, orders, ready]);

  useEffect(() => {
    if (!adminPin) return;
    let mounted = true;
    void fetch("/api/orders", {
      cache: "no-store",
      headers: { "x-admin-pin": adminPin },
    })
      .then(async (response) => {
        if (!response.ok) return null;
        return (await response.json()) as StoreOrder[];
      })
      .then((remoteOrders) => {
        if (mounted && Array.isArray(remoteOrders)) {
          setOrders(remoteOrders);
          saveStored(STORAGE.orders, remoteOrders);
        }
      })
      .catch(() => undefined);
    return () => {
      mounted = false;
    };
  }, [adminPin]);

  const setAdminPin = useCallback((pin: string) => {
    setAdminPinState(pin);
    try {
      if (pin) window.localStorage.setItem(STORAGE.adminPin, pin);
      else window.localStorage.removeItem(STORAGE.adminPin);
    } catch {
      // Session state still works if browser storage is disabled.
    }
  }, []);

  const addToCart = useCallback((product: StoreProduct, size: Size) => {
    const available = product.stock[size] ?? 0;
    const existing = cart.find((entry) => entry.productId === product.id && entry.size === size);
    if (available < 1 || (existing?.quantity ?? 0) >= available) return false;
    setCart((current) => {
      const match = current.find((entry) => entry.productId === product.id && entry.size === size);
      return match
        ? current.map((entry) => entry.productId === product.id && entry.size === size
          ? { ...entry, quantity: Math.min(available, entry.quantity + 1) }
          : entry)
        : [...current, { productId: product.id, size, quantity: 1 }];
    });
    return true;
  }, [cart]);

  const setCartQuantity = useCallback((productId: string, size: Size, quantity: number) => {
    const product = products.find((item) => item.id === productId);
    const available = product?.stock[size] ?? 0;
    if (quantity <= 0 || available <= 0) {
      setCart((current) => current.filter((entry) => !(entry.productId === productId && entry.size === size)));
      return;
    }
    setCart((current) => current.map((entry) => entry.productId === productId && entry.size === size
      ? { ...entry, quantity: Math.min(available, Math.floor(quantity)) }
      : entry));
  }, [products]);

  const removeFromCart = useCallback((productId: string, size: Size) => {
    setCart((current) => current.filter((entry) => !(entry.productId === productId && entry.size === size)));
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const toggleWishlist = useCallback((productId: string) => {
    setWishlist((current) => current.includes(productId)
      ? current.filter((id) => id !== productId)
      : [...current, productId]);
  }, []);

  const submitOrder = useCallback(async (customer: CustomerDetails, payment: PaymentMethod) => {
    const lines: OrderLine[] = cart.map((entry) => {
      const product = products.find((item) => item.id === entry.productId);
      if (!product) throw new Error("A piece in your bag is no longer available.");
      if ((product.stock[entry.size] ?? 0) < entry.quantity) {
        throw new Error(`Only ${product.stock[entry.size] ?? 0} ${entry.size} size available for ${product.shortName}.`);
      }
      return {
        productId: product.id,
        title: product.name,
        art: product.art,
        frontImage: product.frontImage,
        price: product.price,
        size: entry.size,
        quantity: entry.quantity,
      };
    });
    if (!lines.length) throw new Error("Your bag is empty.");

    const createdAt = new Date().toISOString();
    const draft: StoreOrder = {
      id: typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `mx-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      receipt: `#MX-${Math.floor(1000 + Math.random() * 9000)}`,
      customer,
      items: lines,
      total: lines.reduce((sum, line) => sum + line.price * line.quantity, 0),
      payment,
      status: "Pending",
      createdAt,
    };

    let savedOrder = draft;
    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(draft),
      });
      if (response.status === 409 || response.status === 400) {
        const message = (await response.json()) as { error?: string };
        throw new Error(message.error ?? "Please check your bag and delivery details.");
      }
      if (response.ok) {
        const result = (await response.json()) as { order?: StoreOrder };
        if (result.order) savedOrder = result.order;
      }
    } catch (error) {
      if (error instanceof Error && !error.message.includes("fetch")) throw error;
      // Keep checkout available as a local, persisted order if the database is offline.
    }

    const updatedProducts = products.map((product) => {
      const ordered = lines.filter((line) => line.productId === product.id);
      if (ordered.length === 0) return product;
      const stock = { ...product.stock };
      for (const line of ordered) stock[line.size] = Math.max(0, (stock[line.size] ?? 0) - line.quantity);
      return { ...product, stock };
    });
    setProducts(updatedProducts);
    setOrders((current) => [savedOrder, ...current.filter((order) => order.id !== savedOrder.id)]);
    setCart([]);
    return savedOrder;
  }, [cart, products]);

  const upsertProduct = useCallback(async (product: StoreProduct) => {
    setProducts((current) => replaceProduct(current, product));
    try {
      const response = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-admin-pin": adminPin },
        body: JSON.stringify(product),
      });
      return response.ok;
    } catch {
      return false;
    }
  }, [adminPin]);

  const removeProduct = useCallback(async (productId: string) => {
    setProducts((current) => current.filter((product) => product.id !== productId));
    setCart((current) => current.filter((entry) => entry.productId !== productId));
    try {
      const response = await fetch(`/api/products/${encodeURIComponent(productId)}`, {
        method: "DELETE",
        headers: { "x-admin-pin": adminPin },
      });
      return response.ok;
    } catch {
      return false;
    }
  }, [adminPin]);

  const updateOrderStatus = useCallback(async (orderId: string, status: OrderStatus) => {
    setOrders((current) => current.map((order) => order.id === orderId ? { ...order, status } : order));
    try {
      const response = await fetch(`/api/orders/${encodeURIComponent(orderId)}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", "x-admin-pin": adminPin },
        body: JSON.stringify({ status }),
      });
      return response.ok;
    } catch {
      return false;
    }
  }, [adminPin]);

  const value = useMemo<StoreContextValue>(() => ({
    products,
    cart,
    wishlist,
    orders,
    adminPin,
    ready,
    bagCount: cart.reduce((sum, entry) => sum + entry.quantity, 0),
    subtotal: cart.reduce((sum, entry) => {
      const product = products.find((item) => item.id === entry.productId);
      return sum + (product?.price ?? 0) * entry.quantity;
    }, 0),
    setAdminPin,
    addToCart,
    setCartQuantity,
    removeFromCart,
    clearCart,
    toggleWishlist,
    submitOrder,
    upsertProduct,
    removeProduct,
    updateOrderStatus,
  }), [products, cart, wishlist, orders, adminPin, ready, setAdminPin, addToCart, setCartQuantity, removeFromCart, clearCart, toggleWishlist, submitOrder, upsertProduct, removeProduct, updateOrderStatus]);

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) throw new Error("useStore must be used inside StoreProvider.");
  return context;
}
