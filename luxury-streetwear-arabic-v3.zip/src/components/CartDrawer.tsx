"use client";

import { useEffect, useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, Check, Minus, Plus, Trash2, X } from "lucide-react";
import { CATEGORY_AR, type Currency, type PaymentMethod, type StoreOrder } from "@/lib/store-data";
import { OTHER_COMMUNE, WILAYAS_DZ, findWilaya, normalizeDzPhone } from "@/lib/algeria";
import { formatPrice } from "@/lib/format-price";
import { useStore } from "@/components/StoreContext";
import { GarmentArtwork } from "@/components/GarmentArtwork";

type CartDrawerProps = {
  open: boolean;
  currency: Currency;
  onClose: () => void;
};

type DrawerView = "bag" | "checkout" | "success";

type Form = { firstName: string; lastName: string; phone: string; wilaya: string; commune: string; communeOther: string; notes: string };
const emptyForm: Form = { firstName: "", lastName: "", phone: "", wilaya: "", commune: "", communeOther: "", notes: "" };

export function CartDrawer({ open, currency, onClose }: CartDrawerProps) {
  const { cart, products, subtotal, setCartQuantity, removeFromCart, submitOrder } = useStore();
  const [view, setView] = useState<DrawerView>("bag");
  const [form, setForm] = useState<Form>(emptyForm);
  const [payment, setPayment] = useState<PaymentMethod>("Cash on delivery");
  const [confirmation, setConfirmation] = useState<StoreOrder | null>(null);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [open, onClose]);

  useEffect(() => {
    if (open) {
      setView("bag");
      setConfirmation(null);
      setError("");
    }
  }, [open]);

  const entries = cart.flatMap((entry) => {
    const product = products.find((item) => item.id === entry.productId);
    return product ? [{ entry, product }] : [];
  });

  const update = (key: keyof Form, value: string) => {
    setForm((current) => ({ ...current, [key]: value, ...(key === "wilaya" ? { commune: "", communeOther: "" } : {}) }));
    setError("");
  };
  const communes = findWilaya(form.wilaya)?.communes ?? [];

  const placeOrder = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError("");
    const phone = normalizeDzPhone(form.phone);
    const commune = form.commune === OTHER_COMMUNE ? form.communeOther.trim() : form.commune;
    if (!phone) { setError("رقم الهاتف غير صحيح. اكتب رقماً جزائرياً يبدأ بـ 05 أو 06 أو 07."); return; }
    if (!form.wilaya || !commune) { setError("اختر الولاية ثم البلدية."); return; }
    const firstName = form.firstName.trim();
    const lastName = form.lastName.trim();
    setSubmitting(true);
    try {
      const order = await submitOrder({ name: `${firstName} ${lastName}`, firstName, lastName, phone, wilaya: form.wilaya, commune, notes: form.notes.trim() }, payment);
      setConfirmation(order);
      setView("success");
    } catch (submissionError) {
      setError(submissionError instanceof Error ? submissionError.message : "حاول مرة أخرى.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.button
            className="drawer-scrim"
            type="button"
            aria-label="إغلاق السلة"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.aside
            className="cart-drawer"
            role="dialog"
            aria-modal="true"
            aria-labelledby="cart-title"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 280, damping: 28 }}
          >
            <header className="drawer-header">
              <div><h2 id="cart-title">{view === "checkout" ? "التوصيل" : view === "success" ? "تم الطلب" : "سلّتك"}<span className="drawer-count">{view === "bag" ? String(cart.reduce((sum, item) => sum + item.quantity, 0)).padStart(2, "0") : ""}</span></h2></div>
              <button type="button" className="icon-button" onClick={onClose} aria-label="إغلاق"><X size={19} strokeWidth={1.5} /></button>
            </header>

            <AnimatePresence mode="wait" initial={false}>
              {view === "bag" && (
                <motion.div key="bag" className="drawer-view" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }} transition={{ duration: 0.2 }}>
                  <div className="bag-scroll-area">
                    {entries.length === 0 ? (
                      <div className="empty-bag">
                        <div className="empty-bag-mark">MX</div>
                        <p>سلتك فارغة</p>
                        <span>قطعتك القادمة تنتظرك على الرفّ.</span>
                        <button type="button" className="text-button" onClick={onClose}>تابع التصفّح <ArrowRight size={14} /></button>
                      </div>
                    ) : (
                      <div className="bag-items">
                        {entries.map(({ entry, product }) => (
                          <article className="bag-item" key={`${entry.productId}-${entry.size}`}>
                            <div className="bag-item-art"><GarmentArtwork product={product} side="front" className="garment-svg bag-garment-svg" /></div>
                            <div className="bag-item-copy">
                              <div className="bag-item-title-row"><div><span className="bag-item-category">{CATEGORY_AR[product.category]}</span><h3>{product.shortName}</h3></div><span className="bag-item-price">{formatPrice(product.price * entry.quantity, currency)}</span></div>
                              <p className="bag-item-size">المقاس <strong>{entry.size}</strong> <i>·</i> {formatPrice(product.price, currency)} / للقطعة</p>
                              <div className="bag-item-controls">
                                <div className="quantity-control" aria-label={`Quantity ${entry.quantity}`}>
                                  <button type="button" aria-label="Decrease quantity" onClick={() => setCartQuantity(product.id, entry.size, entry.quantity - 1)}><Minus size={12} /></button>
                                  <span>{entry.quantity}</span>
                                  <button type="button" aria-label="Increase quantity" disabled={entry.quantity >= (product.stock[entry.size] ?? 0)} onClick={() => setCartQuantity(product.id, entry.size, entry.quantity + 1)}><Plus size={12} /></button>
                                </div>
                                <button type="button" className="remove-item" onClick={() => removeFromCart(product.id, entry.size)}><Trash2 size={13} /> حذف</button>
                              </div>
                            </div>
                          </article>
                        ))}
                      </div>
                    )}
                  </div>
                  {entries.length > 0 && (
                    <div className="drawer-summary">
                      <div className="summary-line"><span>المجموع</span><strong>{formatPrice(subtotal, currency)}</strong></div>
                      <div className="summary-line summary-secondary"><span>التوصيل</span><span>مجاني</span></div>
                      <p className="drawer-tax-note">الضرائب مشمولة. التوصيل لكل الولايات.</p>
                      <button type="button" className="checkout-button" onClick={() => setView("checkout")}>متابعة إلى التوصيل <ArrowRight size={16} /></button>
                      <button type="button" className="keep-shopping" onClick={onClose}>واصل التسوّق</button>
                    </div>
                  )}
                </motion.div>
              )}

              {view === "checkout" && (
                <motion.form key="checkout" className="drawer-view checkout-form" onSubmit={placeOrder} initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }} transition={{ duration: 0.2 }}>
                  <button type="button" className="back-to-bag" onClick={() => setView("bag")}><ArrowLeft size={14} /> العودة إلى السلة</button>
                  <div className="checkout-intro"><p>أين نوصّل طلبك؟</p></div>
                  <div className="field-pair">
                    <label className="field-label">الاسم<input required autoComplete="given-name" value={form.firstName} onChange={(event) => update("firstName", event.target.value)} /></label>
                    <label className="field-label">اللقب<input required autoComplete="family-name" value={form.lastName} onChange={(event) => update("lastName", event.target.value)} /></label>
                  </div>
                  <label className="field-label">رقم الهاتف<input required dir="ltr" autoComplete="tel" inputMode="tel" value={form.phone} onChange={(event) => update("phone", event.target.value)} placeholder="05 55 12 34 56" /></label>
                  <div className="field-pair">
                    <label className="field-label">الولاية<select required value={form.wilaya} onChange={(event) => update("wilaya", event.target.value)}><option value="" disabled>اختر الولاية</option>{WILAYAS_DZ.map((wilaya) => <option key={wilaya.code} value={wilaya.name}>{String(wilaya.code).padStart(2, "0")} - {wilaya.name}</option>)}</select></label>
                    <label className="field-label">البلدية<select required disabled={!form.wilaya} value={form.commune} onChange={(event) => update("commune", event.target.value)}><option value="" disabled>{form.wilaya ? "اختر البلدية" : "اختر الولاية أولاً"}</option>{communes.map((commune) => <option key={commune} value={commune}>{commune}</option>)}<option value={OTHER_COMMUNE}>{OTHER_COMMUNE}</option></select></label>
                  </div>
                  {form.commune === OTHER_COMMUNE && <label className="field-label">اسم بلديتك<input required value={form.communeOther} onChange={(event) => update("communeOther", event.target.value)} /></label>}
                  <label className="field-label">ملاحظة للتوصيل <span className="optional-label">اختياري</span><textarea rows={2} value={form.notes} onChange={(event) => update("notes", event.target.value)} placeholder="الحي، أو أي تفصيل يساعد فريق التوصيل" /></label>

                  <fieldset className="payment-options">
                    <legend>طريقة الدفع</legend>
                    <button type="button" className={`payment-choice${payment === "Cash on delivery" ? " payment-choice-selected" : ""}`} onClick={() => setPayment("Cash on delivery")} aria-pressed={payment === "Cash on delivery"}>
                      <span className="payment-radio" />
                      <span className="payment-copy"><strong>الدفع عند الاستلام</strong><small>ادفع عند وصول طلبك</small></span>
                      <span className="payment-mark">COD</span>
                    </button>
                    <button type="button" className={`payment-choice${payment === "Card / Express" ? " payment-choice-selected" : ""}`} onClick={() => setPayment("Card / Express")} aria-pressed={payment === "Card / Express"}>
                      <span className="payment-radio" />
                      <span className="payment-copy"><strong>بطاقة / دفع سريع</strong><small>نؤكد تفاصيل الدفع معك هاتفياً</small></span>
                      <span className="payment-mark">↗</span>
                    </button>
                  </fieldset>

                  {error && <p className="checkout-error" role="alert">{error}</p>}
                  <div className="checkout-total"><span>إجمالي الطلب</span><strong>{formatPrice(subtotal, currency)}</strong></div>
                  <button type="submit" className="checkout-button checkout-submit" disabled={submitting || cart.length === 0}>{submitting ? <span className="button-loading"><i /> جارٍ إرسال طلبك</span> : <>تأكيد الطلب <ArrowRight size={16} /></>}</button>
                  
                </motion.form>
              )}

              {view === "success" && confirmation && (
                <motion.div key="success" className="drawer-view order-success" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.28 }}>
                  <div className="success-seal"><Check size={26} strokeWidth={1.3} /></div>
                  
                  <h3>وصلنا طلبك</h3>
                  <p className="success-thanks">شكراً {confirmation.customer.firstName ?? confirmation.customer.name.split(" ")[0]}، استلمنا طلبك وسنتصل بك قريباً لتأكيده.</p>
                  <div className="receipt-card">
                    <div><span>رقم التتبّع</span><strong>{confirmation.receipt}</strong></div>
                    <i />
                    <div className="receipt-meta"><span>{confirmation.items.length} {confirmation.items.length === 1 ? "قطعة" : "قطع"} · {confirmation.payment === "Cash on delivery" ? "الدفع عند الاستلام" : "بطاقة / دفع سريع"}</span><strong>{formatPrice(confirmation.total, currency)}</strong></div>
                    <p>سنتصل بك على <strong>{confirmation.customer.phone}</strong> لتأكيد التوصيل إلى {confirmation.customer.commune ? `${confirmation.customer.commune}، ` : ""}{confirmation.customer.wilaya}.</p>
                  </div>
                  <div className="success-order-lines">{confirmation.items.map((item) => <div key={`${item.productId}-${item.size}`}><span>{item.title} <i>· {item.size} × {item.quantity}</i></span><span>{formatPrice(item.price * item.quantity, currency)}</span></div>)}</div>
                  <button type="button" className="checkout-button success-continue" onClick={onClose}>العودة إلى الاستوديو <ArrowRight size={16} /></button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
