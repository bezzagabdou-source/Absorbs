"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

const WORD = "MX ABDOU".split("");
const EASE = [0.22, 1, 0.36, 1] as const;
const TOTAL_MS = 2800;

/**
 * افتتاحية سينمائية: شريطان أسودان يفتحان الشاشة (letterbox)، والاسم يظهر بحرفٍ حرف،
 * ثم شعاع ضوء يمرّ فوقه. كل الحركة transform/opacity فقط حتى تبقى خفيفة على الهاتف.
 */
export function IntroCinematic() {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    let seen = false;
    try { seen = window.sessionStorage.getItem("mx-intro") === "1"; } catch { /* التخزين محجوب */ }
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (seen || reduce) { setVisible(false); return; }
    document.body.style.overflow = "hidden";
    const done = window.setTimeout(() => setVisible(false), TOTAL_MS);
    return () => { window.clearTimeout(done); document.body.style.overflow = ""; };
  }, []);

  useEffect(() => {
    if (visible) return;
    document.body.style.overflow = "";
    document.documentElement.dataset.intro = "done"; // يبدأ بعده ظهور العنوان في الصفحة
    try { window.sessionStorage.setItem("mx-intro", "1"); } catch { /* التخزين محجوب */ }
  }, [visible]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div className="intro-cinema" role="presentation" exit={{ opacity: 0, transition: { duration: 0.35, delay: 0.75 } }}>
          <motion.i className="intro-bar intro-bar-top" initial={{ scaleY: 1 }} animate={{ scaleY: 0.14 }} exit={{ scaleY: 0, transition: { duration: 0.8, ease: [0.76, 0, 0.24, 1] } }} transition={{ duration: 1.1, ease: EASE, delay: 0.15 }} />
          <motion.i className="intro-bar intro-bar-bottom" initial={{ scaleY: 1 }} animate={{ scaleY: 0.14 }} exit={{ scaleY: 0, transition: { duration: 0.8, ease: [0.76, 0, 0.24, 1] } }} transition={{ duration: 1.1, ease: EASE, delay: 0.15 }} />

          <motion.div className="intro-stage" initial={{ scale: 0.9 }} animate={{ scale: 1.04 }} exit={{ scale: 1.5, opacity: 0, transition: { duration: 0.7, ease: [0.76, 0, 0.24, 1] } }} transition={{ duration: TOTAL_MS / 1000, ease: "linear" }}>
            <h1 className="intro-word" dir="ltr" aria-label="MX ABDOU">
              {WORD.map((letter, index) => (
                <span className="intro-letter-mask" key={index} aria-hidden="true">
                  <motion.span className="intro-letter" initial={{ y: "110%" }} animate={{ y: "0%" }} transition={{ duration: 0.9, ease: EASE, delay: 0.5 + index * 0.06 }}>
                    {letter === " " ? "\u00A0" : letter}
                  </motion.span>
                </span>
              ))}
              <span className="intro-sheen" aria-hidden="true" />
            </h1>
            <motion.p className="intro-tagline" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8, delay: 1.5 }}>قطع للحركة اليومية</motion.p>
          </motion.div>

          <button type="button" className="intro-skip" onClick={() => setVisible(false)}>تخطّي</button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
