"use client";

import { useEffect, useRef, useState, type CSSProperties } from "react";
import { AnimatePresence, motion, useMotionValueEvent, useReducedMotion, useScroll, useSpring, useTransform, useMotionValue } from "framer-motion";
import { ArrowLeft, ArrowRight, ShieldCheck, Smartphone, Truck, Wallet } from "lucide-react";
import { ACCENTS, type Currency, type StoreProduct } from "@/lib/store-data";
import { formatPrice } from "@/lib/format-price";

const EASE = [0.22, 1, 0.36, 1] as const;
const SLOT_DVH = 85; // طول التمرير لكل قطعة

export function TrustBar() {
  const items = [
    { icon: Truck, title: "توصيل مجاني", text: "إلى كل ولايات الجزائر" },
    { icon: Wallet, title: "الدفع عند الاستلام", text: "ادفع عندما يصلك الطلب" },
    { icon: Smartphone, title: "تأكيد بالهاتف", text: "نتصل بك قبل الشحن" },
    { icon: ShieldCheck, title: "صور حقيقية", text: "ما تراه هو ما تستلمه" },
  ];
  return (
    <ul className="trust-bar" aria-label="مزايا المتجر">
      {items.map(({ icon: Icon, title, text }) => (
        <li key={title}><Icon size={20} strokeWidth={1.4} /><div><strong>{title}</strong><span>{text}</span></div></li>
      ))}
    </ul>
  );
}

type Props = { products: StoreProduct[]; currency: Currency; onSelect: (product: StoreProduct) => void };

/**
 * عرض سينمائي مثبّت: الشاشة تبقى ثابتة والتمرير هو "الكاميرا".
 * كل قطعة تأخذ شريحة من التمرير، وتتمايل في مكانها كأنها على منصة دوّارة، والخلفية تأخذ لون القطعة.
 * الحركة كلها transform/opacity على مؤشر التمرير، فلا تثقل الهاتف.
 */
export function CinemaShowcase({ products, currency, onSelect }: Props) {
  const reduce = useReducedMotion();
  const reelRef = useRef<HTMLElement>(null);
  const indexRef = useRef(0);
  const [index, setIndex] = useState(0);
  const [direction, setDirection] = useState(1);
  const count = products.length;
  const pinned = !reduce && count > 1;

  const { scrollYProgress } = useScroll({ target: reelRef, offset: ["start start", "end end"] });

  const setActive = (next: number) => {
    if (next === indexRef.current) return;
    setDirection(next > indexRef.current ? 1 : -1);
    indexRef.current = next;
    setIndex(next);
  };

  useMotionValueEvent(scrollYProgress, "change", (value) => {
    if (!pinned) return;
    setActive(Math.min(count - 1, Math.max(0, Math.floor(value * count))));
  });

  // إذا تغيّرت القائمة (بحث/فئة) نعود للقطعة الأولى
  useEffect(() => {
    indexRef.current = 0;
    setIndex(0);
  }, [count]);

  // ميل المؤشر + تمايل مع التمرير (sin = صفر عند حدود الشرائح فلا يحدث قفز)
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 110, damping: 18 });
  const sy = useSpring(my, { stiffness: 110, damping: 18 });
  const sway = useTransform(scrollYProgress, (v) => Math.sin(v * count * Math.PI * 2));
  const swaySpring = useSpring(sway, { stiffness: 120, damping: 22 });
  const rotateY = useTransform([swaySpring, sx], ([a, b]: number[]) => a * 18 + b * 12);
  const rotateX = useTransform(sy, [-1, 1], [7, -7]);
  const wordX = useTransform(scrollYProgress, (v) => Math.cos(v * count * Math.PI * 2) * -70);
  const sheenX = useTransform(sx, [-1, 1], ["-40%", "140%"]);
  const railFill = useTransform(scrollYProgress, [0, 1], [0, 1]);

  useEffect(() => {
    if (count < 2) return;
    for (const offset of [1, -1]) {
      const next = products[(((index + offset) % count) + count) % count];
      if (next?.frontImage) { const img = new Image(); img.decoding = "async"; img.src = next.frontImage; }
    }
  }, [index, count, products]);

  const go = (target: number) => {
    const next = ((target % count) + count) % count;
    if (!pinned) { setActive(next); return; }
    const el = reelRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const top = rect.top + window.scrollY + ((next + 0.5) / count) * (rect.height - window.innerHeight);
    window.scrollTo({ top, behavior: "smooth" });
  };

  const current = products[Math.min(index, Math.max(0, count - 1))];
  if (!current) return null;
  const accent = ACCENTS[current.id] ?? "#6b6b6b";

  return (
    <section ref={reelRef} className="reel" style={pinned ? { height: `calc(${count} * ${SLOT_DVH}dvh)` } : undefined} aria-label="عرض سينمائي للمجموعة">
      <div className={pinned ? "reel-sticky" : "reel-static"}>
        <div
          className="cinema-stage"
          style={{ "--accent": accent } as CSSProperties}
          onPointerMove={(event) => {
            if (event.pointerType === "touch") return;
            const box = event.currentTarget.getBoundingClientRect();
            mx.set(((event.clientX - box.left) / box.width) * 2 - 1);
            my.set(((event.clientY - box.top) / box.height) * 2 - 1);
          }}
          onPointerLeave={() => { mx.set(0); my.set(0); }}
        >
          <div className="cinema-tint" aria-hidden="true" />

          <AnimatePresence mode="popLayout" initial={false}>
            <motion.div key={`${current.id}-word`} className="cinema-word" aria-hidden="true" style={{ x: reduce ? 0 : wordX }}
              initial={{ opacity: 0, y: 50 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -50 }} transition={{ duration: 0.7, ease: EASE }}>
              {current.shortName}
            </motion.div>
          </AnimatePresence>

          <div className="cinema-perspective">
            <AnimatePresence mode="popLayout" custom={direction} initial={false}>
              <motion.div
                key={current.id}
                className="cinema-piece"
                custom={direction}
                variants={{
                  enter: (dir: number) => ({ opacity: 0, y: dir * 160, scale: 0.8, rotateX: dir * -25 }),
                  center: { opacity: 1, y: 0, scale: 1, rotateX: 0 },
                  exit: (dir: number) => ({ opacity: 0, y: dir * -160, scale: 0.8, rotateX: dir * 25 }),
                }}
                initial="enter" animate="center" exit="exit"
                transition={{ type: "spring", stiffness: 130, damping: 20, mass: 0.9 }}
              >
                <motion.div className="cinema-tilt" style={reduce ? undefined : { rotateY, rotateX }}>
                  <motion.img src={current.frontImage} alt={current.name} draggable={false} decoding="async" fetchPriority={index === 0 ? "high" : "auto"}
                    animate={reduce ? undefined : { y: [0, -12, 0] }} transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }} />
                  {!reduce && <motion.span className="cinema-sheen" aria-hidden="true" style={{ left: sheenX }} />}
                </motion.div>
                <span className="cinema-floor" aria-hidden="true" />
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="cinema-info">
            <AnimatePresence mode="wait" initial={false}>
              <motion.div key={current.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.4, ease: EASE }}>
                <h2>{current.name}</h2>
                <p className="cinema-price">{formatPrice(current.price, currency)}</p>
                <button type="button" className="cinema-cta" onClick={() => onSelect(current)}>اكتشف القطعة <ArrowLeft size={16} /></button>
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="cinema-controls" dir="ltr">
            <button type="button" aria-label="القطعة السابقة" onClick={() => go(index - 1)}><ArrowLeft size={17} /></button>
            <button type="button" aria-label="القطعة التالية" onClick={() => go(index + 1)}><ArrowRight size={17} /></button>
          </div>

          <div className="cinema-count" dir="ltr" aria-hidden="true"><b>{String(index + 1).padStart(2, "0")}</b><span>/ {String(count).padStart(2, "0")}</span></div>

          {pinned && (
            <>
              <div className="cinema-rail" aria-hidden="true"><motion.i style={{ scaleY: railFill }} /></div>
              {index === 0 && <p className="cinema-hint" aria-hidden="true">مرّر للأسفل لتتصفح القطع</p>}
            </>
          )}
        </div>
      </div>
    </section>
  );
}
