import type { CSSProperties } from "react";
import type { StoreProduct } from "@/lib/store-data";

type GarmentArtworkProps = {
  product: StoreProduct;
  side?: "front" | "back";
  className?: string;
  style?: CSSProperties;
  /** Show a hanger hook above the garment (used on the clothing rack). */
  hanger?: boolean;
};

function HangerHook() {
  return (
    <svg className="garment-photo-hanger" viewBox="0 0 44 44" aria-hidden="true">
      <defs>
        <linearGradient id="hook-metal" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#f1f1ee" />
          <stop offset=".5" stopColor="#9a9a95" />
          <stop offset="1" stopColor="#5d5d59" />
        </linearGradient>
      </defs>
      <path
        d="M22 44 V31 C22 27 26 26 26 21 C26 14 17 14 17 9 C17 4 23 2 27 5"
        fill="none"
        stroke="url(#hook-metal)"
        strokeWidth="2.6"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function GarmentArtwork({ product, side = "front", className = "", style, hanger = false }: GarmentArtworkProps) {
  const src = side === "back" ? product.backImage ?? product.frontImage : product.frontImage ?? product.backImage;
  const label = `${product.name}, ${side} view`;

  return (
    <span className={`garment-photo${hanger ? " garment-photo-hung" : ""} ${className}`.trim()} style={style}>
      {hanger && <HangerHook />}
      {src ? (
        // eslint-disable-next-line @next/next/no-img-element -- catalogue photos may be uploaded data URLs
        <img className="garment-photo-img" src={src} alt={label} draggable={false} decoding="async" />
      ) : (
        <span className="garment-photo-empty" role="img" aria-label={label}>NO PHOTO YET</span>
      )}
    </span>
  );
}
