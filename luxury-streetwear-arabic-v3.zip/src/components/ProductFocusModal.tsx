"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, ChevronDown, Expand, Heart, X } from "lucide-react";
import type { Currency, Size, StoreProduct } from "@/lib/store-data";
import { SIZES, CATEGORY_AR } from "@/lib/store-data";
import { formatPrice } from "@/lib/format-price";
import { GarmentArtwork } from "@/components/GarmentArtwork";

type ProductFocusModalProps = {
  product: StoreProduct;
  currency: Currency;
  wishlisted: boolean;
  onWishlist: () => void;
  onClose: () => void;
  onAdd: (product: StoreProduct, size: Size) => void;
};

export function ProductFocusModal({ product, currency, wishlisted, onWishlist, onClose, onAdd }: ProductFocusModalProps) {
  const [side, setSide] = useState<"front" | "back">("front");
  const [selectedSize, setSelectedSize] = useState<Size | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [zoomed, setZoomed] = useState(false);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKeyDown);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = previousOverflow;
    };
  }, [onClose]);

  useEffect(() => {
    setSide("front");
    setSelectedSize(null);
    setDetailsOpen(false);
    setZoomed(false);
  }, [product.id]);

  const selectedStock = selectedSize ? product.stock[selectedSize] ?? 0 : 0;
  const canAdd = Boolean(selectedSize && selectedStock > 0);

  return (
    <>
      <motion.div
        className="focus-backdrop"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.32 }}
        onClick={onClose}
        aria-hidden="true"
      />
      <motion.section
        className="focus-panel"
        role="dialog"
        aria-modal="true"
        aria-labelledby="focus-title"
        initial={{ opacity: 0, scale: 0.965, y: 14, filter: "blur(8px)" }}
        animate={{ opacity: 1, scale: 1, y: 0, filter: "blur(0px)" }}
        exit={{ opacity: 0, scale: 0.98, y: 10, filter: "blur(8px)" }}
        transition={{ type: "spring", stiffness: 280, damping: 28 }}
        onClick={(event) => event.stopPropagation()}
      >
        <header className="focus-topline">
          <span><i className="status-dot" /> قطعة {product.id.slice(0, 3).toUpperCase()} — MX / 26</span>
          <button type="button" className="icon-button focus-close" aria-label="Return to clothing rack" onClick={onClose}><X size={19} strokeWidth={1.5} /></button>
        </header>

        <div className="focus-content">
          <div className="focus-visual-column">
            <div className={`focus-art-stage${zoomed ? " focus-art-zoomed" : ""}`}>
              <div className="focus-art-index"><span>0{side === "front" ? "1" : "2"}</span><i />{side === "front" ? "الواجهة" : "الخلف"}</div>
              <button className="icon-button focus-zoom-button" type="button" onClick={() => setZoomed((value) => !value)} aria-label={zoomed ? "Zoom out" : "Zoom in"}>
                {zoomed ? <Check size={16} strokeWidth={1.5} /> : <Expand size={16} strokeWidth={1.5} />}
              </button>
              <div className="focus-garment-perspective">
                <AnimatePresence mode="wait" initial={false}>
                  <motion.div
                    key={`${product.id}-${side}`}
                    className="focus-garment-transition"
                    initial={{ opacity: 0, rotateY: side === "front" ? 48 : -48, scale: 0.94 }}
                    animate={{ opacity: 1, rotateY: 0, scale: 1 }}
                    exit={{ opacity: 0, rotateY: side === "front" ? -35 : 35, scale: 0.97 }}
                    transition={{ type: "spring", stiffness: 280, damping: 28 }}
                  >
                    <motion.div className="focus-garment-layout" layoutId={`garment-${product.id}`} transition={{ type: "spring", stiffness: 280, damping: 28 }}>
                      <GarmentArtwork product={product} side={side} className="garment-svg focus-garment-svg" />
                    </motion.div>
                  </motion.div>
                </AnimatePresence>
              </div>
              {product.backImage && (
              <div className="focus-side-toggle" role="group" aria-label="Choose garment side">
                {(["front", "back"] as const).map((view) => (
                  <button key={view} type="button" className={side === view ? "side-toggle-option side-toggle-active" : "side-toggle-option"} onClick={() => setSide(view)} aria-pressed={side === view}>
                    {view === "front" ? "أمام" : "خلف"}
                  </button>
                ))}
              </div>
              )}
              <span className="focus-art-note">قصّ · خياطة · عناية</span>
            </div>
            <div className="focus-art-footer"><span>دراسة المنتج</span><span>الإصدار 01 / 2026</span></div>
          </div>

          <div className="focus-details-column">
            <div className="focus-product-heading">
              <p className="eyebrow">{CATEGORY_AR[product.category]} <span>·</span> الإصدار 01 / 2026</p>
              <div className="focus-title-line">
                <div>
                  <h1 id="focus-title">{product.name}</h1>
                  <p className="focus-short-name">{product.shortName} / موديل {product.id.slice(-3).toUpperCase()}</p>
                </div>
                <button type="button" className={`icon-button focus-wishlist${wishlisted ? " is-favorited" : ""}`} aria-label={wishlisted ? "Remove from wishlist" : "Add to wishlist"} onClick={onWishlist}>
                  <Heart size={18} strokeWidth={1.5} fill={wishlisted ? "currentColor" : "none"} />
                </button>
              </div>
              <div className="focus-price-row"><span className="focus-price">{formatPrice(product.price, currency)}</span><span className="focus-tax-note">شامل الضرائب</span></div>
              <p className="focus-description">{product.description}</p>
            </div>

            <div className="focus-control-group">
              <div className="size-heading"><span>اختر المقاس</span><span className="size-guide-label">دليل المقاسات ↓</span></div>
              <div className="size-selector" role="group" aria-label="Available sizes">
                {SIZES.map((size) => {
                  const available = (product.stock[size] ?? 0) > 0;
                  return (
                    <button
                      key={size}
                      className={`size-pill${selectedSize === size ? " size-pill-selected" : ""}${available ? "" : " size-pill-sold"}`}
                      type="button"
                      aria-label={`${size}${available ? `, ${product.stock[size]} available` : ", out of stock"}`}
                      aria-pressed={selectedSize === size}
                      disabled={!available}
                      onClick={() => setSelectedSize(size)}
                    >{size}</button>
                  );
                })}
              </div>
              {selectedSize && selectedStock > 0 && selectedStock <= 3 && <p className="low-stock-note"><i className="status-dot" /> بقيت {selectedStock} قطع فقط في المقاس {selectedSize}</p>}
            </div>

            <div className="focus-actions">
              <button className={`add-to-bag${canAdd ? " add-to-bag-ready" : ""}`} type="button" disabled={!canAdd} onClick={() => selectedSize && onAdd(product, selectedSize)}>
                <span>{canAdd ? `أضف إلى السلة — ${formatPrice(product.price, currency)}` : "اختر مقاساً"}</span>
                {canAdd && <span aria-hidden="true">↗</span>}
              </button>
              <button className="details-trigger" type="button" onClick={() => setDetailsOpen(true)}>
                التفاصيل والتوفّر <span>↗</span>
              </button>
            </div>

            <div className="focus-delivery-note"><span className="delivery-icon">↗</span><p>توصيل مجاني لكل الجزائر <i>·</i> الدفع عند الاستلام متاح</p></div>
            <div className="focus-ref-line"><span>المرجع {product.id.toUpperCase()}</span><span>صُنع للحركة</span></div>
          </div>
        </div>
      </motion.section>

      <AnimatePresence>
        {detailsOpen && (
          <>
            <motion.button
              className="details-scrim"
              type="button"
              aria-label="Close product details"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDetailsOpen(false)}
            />
            <motion.aside
              className="details-sheet"
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 280, damping: 28 }}
              aria-label="Fabric, fit and care details"
            >
              <div className="details-sheet-head"><span className="eyebrow">تفاصيل القطعة</span><button type="button" className="icon-button" aria-label="Close details" onClick={() => setDetailsOpen(false)}><X size={18} /></button></div>
              <p className="details-sheet-name">{product.shortName}</p>
              <div className="detail-block"><span className="detail-label">الخامة</span><p>{product.fabric}</p></div>
              <div className="detail-block"><span className="detail-label">القصّة والملمس</span><p>{product.fit}</p></div>
              <div className="detail-block">
                <span className="detail-label">القياسات <i>سم · مقاس M</i></span>
                <div className="measurement-table">{Object.entries(product.sizeChart).map(([label, value]) => <div key={label}><span>{({ Chest: "الصدر", Length: "الطول", Shoulder: "الكتف" } as Record<string, string>)[label] ?? label}</span><span>{value}</span></div>)}</div>
              </div>
              <div className="detail-block"><span className="detail-label">العناية</span><ul>{product.care.map((instruction) => <li key={instruction}>{instruction}</li>)}</ul></div>
              <div className="details-sheet-foot"><span>MX ABDOU / STUDIO ALGER</span><span>01—26</span></div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
