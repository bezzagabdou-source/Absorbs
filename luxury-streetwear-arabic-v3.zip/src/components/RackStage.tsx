"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, ArrowRight, MoveHorizontal } from "lucide-react";
import { CATEGORY_AR, type StoreProduct } from "@/lib/store-data";
import { GarmentArtwork } from "@/components/GarmentArtwork";

type RackStageProps = {
  products: StoreProduct[];
  activeId: string;
  onActive: (id: string) => void;
  onSelect: (product: StoreProduct) => void;
};

export function RackStage({ products, activeId, onActive, onSelect }: RackStageProps) {
  const windowRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef<HTMLElement>(null);
  const rafRef = useRef<number | null>(null);
  const activeIndex = Math.max(0, products.findIndex((product) => product.id === activeId));

  useEffect(() => {
    const rack = windowRef.current;
    if (!rack) return;
    const handleWheel = (event: WheelEvent) => {
      if (Math.abs(event.deltaY) > Math.abs(event.deltaX)) {
        event.preventDefault();
        rack.scrollLeft += event.deltaY;
      }
    };
    rack.addEventListener("wheel", handleWheel, { passive: false });
    return () => rack.removeEventListener("wheel", handleWheel);
  }, []);

  useEffect(() => {
    const rack = windowRef.current;
    if (!rack) return;
    const handleScroll = () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
      rafRef.current = requestAnimationFrame(() => {
        const rackBounds = rack.getBoundingClientRect();
        const center = rackBounds.left + rackBounds.width / 2;
        const cards = Array.from(rack.querySelectorAll<HTMLElement>("[data-rack-id]"));
        let nearestId = "";
        let nearestDistance = Number.POSITIVE_INFINITY;
        for (const card of cards) {
          const bounds = card.getBoundingClientRect();
          const distance = Math.abs(bounds.left + bounds.width / 2 - center);
          if (distance < nearestDistance) {
            nearestDistance = distance;
            nearestId = card.dataset.rackId ?? "";
          }
        }
        if (nearestId) onActive(nearestId);
      });
    };
    rack.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => {
      rack.removeEventListener("scroll", handleScroll);
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    };
  }, [onActive, products.length]);

  useEffect(() => {
    if (!products.some((product) => product.id === activeId)) {
      if (products[0]) onActive(products[0].id);
      return;
    }
    const rack = windowRef.current;
    const active = rack?.querySelector<HTMLElement>(`[data-rack-id="${CSS.escape(activeId)}"]`);
    if (!rack || !active) return;
    const rackCenter = rack.getBoundingClientRect().left + rack.clientWidth / 2;
    const activeCenter = active.getBoundingClientRect().left + active.clientWidth / 2;
    if (Math.abs(activeCenter - rackCenter) > rack.clientWidth * 0.22) {
      active.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
    }
  }, [activeId, products, onActive]);

  const goTo = (index: number) => {
    const clamped = Math.min(products.length - 1, Math.max(0, index));
    const product = products[clamped];
    if (!product) return;
    onActive(product.id);
    const card = windowRef.current?.querySelector<HTMLElement>(`[data-rack-id="${CSS.escape(product.id)}"]`);
    card?.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
  };

  if (products.length === 0) {
    return <div className="rack-empty"><span>الرفّ فارغ</span><p>جرّب فئة أخرى أو بحثاً آخر.</p></div>;
  }

  return (
    <section className="rack-stage" ref={frameRef} aria-label="MX ABDOU collection clothing rack">
      <div className="rack-structure" aria-hidden="true">
        <span className="rack-bracket rack-bracket-left"><i /></span>
        <span className="rack-bracket rack-bracket-right"><i /></span>
        <span className="rack-shadow-line" />
        <span className="rack-rail"><i /></span>
      </div>

      <button
        className="rack-arrow rack-arrow-left"
        type="button"
        aria-label="Previous garment"
        disabled={activeIndex === 0}
        onClick={() => goTo(activeIndex - 1)}
      ><ArrowLeft size={17} strokeWidth={1.5} /></button>

      <div className="rack-window" ref={windowRef} tabIndex={0} aria-label="Swipe or scroll horizontally to browse garments">
        <div className="rack-track">
          {products.map((product, index) => {
            const active = product.id === activeId;
            const direction = index < activeIndex ? -1 : 1;
            return (
              <motion.article
                className={`rack-item${active ? " rack-item-active" : ""}`}
                key={product.id}
                data-rack-id={product.id}
                onPointerEnter={() => onActive(product.id)}
                animate={{
                  scale: active ? 1 : 0.84,
                  rotateY: active ? 0 : direction * 25,
                  y: active ? -5 : 10,
                  opacity: active ? 1 : 0.76,
                }}
                transition={{ type: "spring", stiffness: 280, damping: 28 }}
                style={{ transformStyle: "preserve-3d", zIndex: active ? 3 : 1 }}
              >
                <button
                  className="rack-piece-button"
                  type="button"
                  aria-label={`Inspect ${product.name}`}
                  onFocus={() => onActive(product.id)}
                  onClick={() => onSelect(product)}
                >
                  <motion.div className="rack-art-shell" layoutId={`garment-${product.id}`} transition={{ type: "spring", stiffness: 280, damping: 28 }}>
                    <GarmentArtwork product={product} side="front" hanger className="garment-svg rack-garment-svg" />
                  </motion.div>
                  <span className="rack-piece-name">{product.shortName}</span>
                  <span className="rack-piece-category">{CATEGORY_AR[product.category]} <i>·</i> {product.stock.S + product.stock.M + product.stock.L + product.stock.XL + product.stock["2XL"] > 0 ? "متوفر" : "نفدت الكمية"}</span>
                </button>
              </motion.article>
            );
          })}
        </div>
      </div>

      <button
        className="rack-arrow rack-arrow-right"
        type="button"
        aria-label="Next garment"
        disabled={activeIndex === products.length - 1}
        onClick={() => goTo(activeIndex + 1)}
      ><ArrowRight size={17} strokeWidth={1.5} /></button>

      <div className="rack-caption" aria-hidden="true"><MoveHorizontal size={13} strokeWidth={1.4} /><span>اسحب للاستكشاف</span></div>
      <div className="rack-pagination" aria-label={`Garment ${activeIndex + 1} of ${products.length}`}>
        {products.map((product, index) => (
          <button
            key={product.id}
            type="button"
            aria-label={`Go to ${product.shortName}`}
            aria-current={product.id === activeId ? "true" : undefined}
            className={product.id === activeId ? "rack-dot rack-dot-active" : "rack-dot"}
            onClick={() => goTo(index)}
          />
        ))}
        <span className="rack-count">{String(activeIndex + 1).padStart(2, "0")} <i>/</i> {String(products.length).padStart(2, "0")}</span>
      </div>
    </section>
  );
}
