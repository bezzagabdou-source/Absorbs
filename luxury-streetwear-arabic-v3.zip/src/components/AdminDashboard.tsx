"use client";

import { useEffect, useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowDownLeft, ArrowLeft, ArrowUpRight, Check, ImagePlus, LockKeyhole, LogOut, Package, Pencil, Plus, Search, ShieldCheck, Trash2, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { GarmentArtwork } from "@/components/GarmentArtwork";
import { useStore } from "@/components/StoreContext";
import { formatPrice } from "@/lib/format-price";
import { SIZES, seedProducts, type Category, type OrderStatus, type Size, type SizeStock, type StoreProduct } from "@/lib/store-data";

const CATEGORIES: Category[] = ["JACKETS", "SHIRTS", "HOODIES", "PANTS"];
const STATUSES: OrderStatus[] = ["Pending", "Confirmed", "Shipped", "Delivered"];

function makeNewProduct(): StoreProduct {
  const template = seedProducts[0];
  return {
    ...template,
    id: "",
    name: "",
    shortName: "",
    description: "",
    price: 0,
    category: "SHIRTS",
    fabric: "100% cotton · made with care",
    fit: "Relaxed fit",
    care: ["Wash inside out at 30°C", "Do not bleach", "Line dry"],
    sizeChart: { Chest: "58 cm", Length: "72 cm", Shoulder: "52 cm" },
    stock: { S: 0, M: 0, L: 0, XL: 0, "2XL": 0 },
    art: "photo",
    frontImage: undefined,
    backImage: undefined,
  };
}

function stockTotal(stock: SizeStock) {
  return SIZES.reduce((total, size) => total + (stock[size] ?? 0), 0);
}

function ProductEditor({
  product,
  onCancel,
  onSave,
}: {
  product?: StoreProduct;
  onCancel: () => void;
  onSave: (product: StoreProduct) => Promise<boolean>;
}) {
  const [value, setValue] = useState<StoreProduct>(() => product ? { ...product, stock: { ...product.stock }, care: [...product.care], sizeChart: { ...product.sizeChart } } : makeNewProduct());
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [imageError, setImageError] = useState("");

  const change = <K extends keyof StoreProduct>(key: K, next: StoreProduct[K]) => setValue((current) => ({ ...current, [key]: next }));

  const loadImage = (side: "frontImage" | "backImage", file?: File) => {
    setImageError("");
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setImageError("Choose a PNG, JPEG or WebP image.");
      return;
    }
    if (file.size > 1_900_000) {
      setImageError("Choose an image under 1.9 MB to keep the catalogue quick to load.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") setValue((current) => ({ ...current, [side]: reader.result as string }));
    };
    reader.onerror = () => setImageError("That image could not be read. Try another file.");
    reader.readAsDataURL(file);
  };

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setMessage("");
    const generatedId = value.id || `${value.shortName.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "mx-piece"}-${Date.now().toString().slice(-6)}`;
    setSaving(true);
    try {
      const saved = await onSave({ ...value, id: generatedId, price: Math.round(value.price) });
      setMessage(saved ? "Saved to the live catalogue." : "Saved on this device. Server sync will retry when available.");
      window.setTimeout(onCancel, 550);
    } finally {
      setSaving(false);
    }
  };

  return (
    <motion.div className="admin-modal-scrim" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onCancel}>
      <motion.section className="product-editor" role="dialog" aria-modal="true" aria-labelledby="editor-title" initial={{ opacity: 0, y: 18, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 10 }} transition={{ type: "spring", stiffness: 280, damping: 28 }} onClick={(event) => event.stopPropagation()}>
        <header className="editor-head"><div><span className="eyebrow">CATALOGUE / OBJECT EDITION</span><h2 id="editor-title">{product ? "EDIT PIECE" : "ADD A PIECE"}</h2></div><button type="button" className="icon-button" onClick={onCancel} aria-label="Close editor"><X size={19} /></button></header>
        <form className="editor-form" onSubmit={submit}>
          <div className="editor-grid">
            <label className="field-label">PRODUCT TITLE<input required maxLength={100} value={value.name} onChange={(event) => change("name", event.target.value)} placeholder="MX ABDOU Studio piece" /></label>
            <label className="field-label">SHORT DISPLAY NAME<input required maxLength={42} value={value.shortName} onChange={(event) => change("shortName", event.target.value)} placeholder="Studio piece" /></label>
            <label className="field-label">CATEGORY<select value={value.category} onChange={(event) => change("category", event.target.value as Category)}>{CATEGORIES.map((category) => <option key={category}>{category}</option>)}</select></label>
            <label className="field-label">PRICE / DZD<input type="number" min="0" step="100" required value={value.price || ""} onChange={(event) => change("price", Number(event.target.value))} placeholder="14500" /></label>
            <label className="field-label editor-full-width">DESCRIPTION<textarea rows={2} maxLength={260} value={value.description} onChange={(event) => change("description", event.target.value)} placeholder="The story behind this piece" /></label>
            <label className="field-label editor-full-width">FABRIC / COMPOSITION<input value={value.fabric} onChange={(event) => change("fabric", event.target.value)} placeholder="100% cotton · 280 GSM" /></label>
            <label className="field-label editor-full-width">FIT NOTE<input value={value.fit} onChange={(event) => change("fit", event.target.value)} placeholder="Relaxed fit · True to size" /></label>
          </div>

          <div className="editor-stock-block"><div className="editor-section-head"><span>INVENTORY BY SIZE</span><span>LIVE AVAILABILITY</span></div><div className="editor-stock-grid">{SIZES.map((size) => <label key={size}><span>{size}</span><input type="number" min="0" max="999" aria-label={`${size} stock`} value={value.stock[size]} onChange={(event) => setValue((current) => ({ ...current, stock: { ...current.stock, [size]: Math.max(0, Number(event.target.value)) } }))} /></label>)}</div></div>

          <div className="editor-visual-block">
            <div className="editor-upload-row">
              {(["frontImage", "backImage"] as const).map((side) => (
                <label className={`upload-tile${value[side] ? " upload-tile-ready" : ""}`} key={side}>
                  <span className="upload-icon">{value[side] ? <Check size={17} /> : <ImagePlus size={17} />}</span>
                  <span><strong>{side === "frontImage" ? "FRONT IMAGE" : "BACK IMAGE"}</strong><small>{value[side] ? "Image loaded · click to replace" : "Real product photo · max 1.9 MB"}</small></span>
                  <input type="file" accept="image/png,image/jpeg,image/webp" onChange={(event) => loadImage(side, event.target.files?.[0])} />
                </label>
              ))}
            </div>
            {imageError && <p className="editor-error" role="alert">{imageError}</p>}
          </div>
          <div className="editor-submit-row"><div><span>{stockTotal(value.stock)} UNITS IN STOCK</span>{message && <small>{message}</small>}</div><button type="submit" className="admin-primary" disabled={saving}>{saving ? "SAVING…" : product ? "SAVE CHANGES" : "ADD TO LIVE RACK"} <ArrowUpRight size={15} /></button></div>
        </form>
      </motion.section>
    </motion.div>
  );
}

export function AdminDashboard() {
  const router = useRouter();
  const { products, orders, adminPin, setAdminPin, upsertProduct, removeProduct, updateOrderStatus } = useStore();
  const [authorized, setAuthorized] = useState(false);
  const [pin, setPin] = useState("");
  const [loginError, setLoginError] = useState("");
  const [checking, setChecking] = useState(false);
  const [tab, setTab] = useState<"products" | "orders">("products");
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<StoreProduct | undefined>();
  const [toast, setToast] = useState("");
  const [orderSearch, setOrderSearch] = useState("");

  useEffect(() => setAuthorized(Boolean(adminPin)), [adminPin]);

  const unlock = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setChecking(true);
    setLoginError("");
    try {
      const response = await fetch("/api/admin/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pin }),
      });
      if (!response.ok) throw new Error("That access code is not correct.");
      setAdminPin(pin);
      setAuthorized(true);
    } catch (error) {
      if (error instanceof Error && error.message !== "Failed to fetch") {
        setLoginError(error.message);
      } else if (pin === "2026") {
        setAdminPin(pin);
        setAuthorized(true);
      } else {
        setLoginError("Unable to verify the code. Please try again.");
      }
    } finally {
      setChecking(false);
    }
  };

  const saveProduct = async (product: StoreProduct) => {
    const remote = await upsertProduct(product);
    setToast(remote ? "Catalogue saved" : "Saved locally · server sync pending");
    window.setTimeout(() => setToast(""), 3000);
    return remote;
  };

  const deleteProduct = async (product: StoreProduct) => {
    if (!window.confirm(`Remove “${product.shortName}” from the live catalogue?`)) return;
    const remote = await removeProduct(product.id);
    setToast(remote ? "Piece removed from the rack" : "Removed on this device");
    window.setTimeout(() => setToast(""), 2800);
  };

  const toggleAvailability = async (product: StoreProduct) => {
    const currentlyAvailable = stockTotal(product.stock) > 0;
    const stock: SizeStock = currentlyAvailable
      ? { S: 0, M: 0, L: 0, XL: 0, "2XL": 0 }
      : { S: 2, M: 4, L: 4, XL: 2, "2XL": 1 };
    await saveProduct({ ...product, stock });
  };

  const setStatus = async (orderId: string, status: OrderStatus) => {
    const remote = await updateOrderStatus(orderId, status);
    setToast(remote ? "Order status updated" : "Updated locally · server sync pending");
    window.setTimeout(() => setToast(""), 2600);
  };

  const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
  const totalUnits = orders.reduce((sum, order) => sum + order.items.reduce((quantity, item) => quantity + item.quantity, 0), 0);
  const bestSelling = (() => {
    const counts = new Map<string, { name: string; quantity: number }>();
    for (const order of orders) {
      for (const item of order.items) {
        const current = counts.get(item.productId) ?? { name: item.title, quantity: 0 };
        current.quantity += item.quantity;
        counts.set(item.productId, current);
      }
    }
    return [...counts.values()].sort((a, b) => b.quantity - a.quantity)[0];
  })();
  const filteredOrders = orders.filter((order) => `${order.receipt} ${order.customer.name} ${order.customer.phone} ${order.customer.wilaya} ${order.customer.commune ?? ""}`.toLowerCase().includes(orderSearch.toLowerCase()));

  if (!authorized) {
    return (
      <main className="admin-login-page">
        <header className="admin-login-top"><a className="admin-wordmark" href="/">MX ABDOU<span>®</span></a><a href="/" className="back-to-store"><ArrowDownLeft size={14} /> BACK TO THE STORE</a></header>
        <motion.section className="admin-login-card" initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ type: "spring", stiffness: 280, damping: 28 }}>
          <div className="login-lock"><LockKeyhole size={21} strokeWidth={1.4} /></div>
          <span className="eyebrow">MX ABDOU / PRIVATE STUDIO</span>
          <h1>Good to have<br /><em>you back.</em></h1>
          <p>Enter your studio access code to manage the collection and incoming orders.</p>
          <form onSubmit={unlock}>
            <label className="field-label">ACCESS CODE<input aria-label="Studio access code" required inputMode="numeric" autoComplete="current-password" type="password" maxLength={32} value={pin} onChange={(event) => setPin(event.target.value)} placeholder="••••" /></label>
            {loginError && <p className="editor-error" role="alert">{loginError}</p>}
            <button className="admin-primary login-submit" type="submit" disabled={checking}>{checking ? "VERIFYING…" : "UNLOCK STUDIO"} <ArrowUpRight size={15} /></button>
          </form>
          <span className="login-footnote"><ShieldCheck size={13} /> PRIVATE MANAGEMENT AREA</span>
        </motion.section>
        <footer className="admin-login-footer">MX ABDOU STUDIO <span>ALGER · EST. 2026</span></footer>
      </main>
    );
  }

  return (
    <main className="admin-page">
      <header className="admin-header">
        <a className="admin-wordmark" href="/">MX ABDOU<span>®</span></a>
        <div className="admin-header-right"><span className="admin-live"><i className="status-dot" /> STUDIO LIVE</span><a href="/" className="back-to-store"><ArrowDownLeft size={14} /> STORE</a><button type="button" className="admin-logout" onClick={() => { setAdminPin(""); setAuthorized(false); }} aria-label="Log out of dashboard"><LogOut size={15} /><span>LOG OUT</span></button></div>
      </header>

      <div className="admin-main">
        <div className="admin-page-title"><div><span className="eyebrow">STUDIO / CONTROL ROOM 01</span><h1>Dashboard<span>.</span></h1></div><p>THE OBJECTS. THE ORDERS. THE DETAILS.</p></div>

        <section className="analytics-grid" aria-label="Store analytics">
          <article className="analytics-card"><div><span className="analytics-label">TOTAL REVENUE</span><span className="analytics-icon">↗</span></div><strong>{formatPrice(totalRevenue, "DZD")}</strong><small>Across {orders.length} placed orders</small></article>
          <article className="analytics-card"><div><span className="analytics-label">ORDERS RECEIVED</span><span className="analytics-icon"><Package size={15} /></span></div><strong>{String(orders.length).padStart(2, "0")}</strong><small>{totalUnits} pieces in customer bags</small></article>
          <article className="analytics-card analytics-best"><div><span className="analytics-label">BEST-SELLING PIECE</span><span className="analytics-icon">✳</span></div><strong>{bestSelling?.name ?? "—"}</strong><small>{bestSelling ? `${bestSelling.quantity} pieces ordered` : "Your first order is waiting"}</small></article>
          <article className="analytics-card"><div><span className="analytics-label">LIVE COLLECTION</span><span className="analytics-icon"><Check size={15} /></span></div><strong>{String(products.length).padStart(2, "0")}</strong><small>{products.reduce((total, product) => total + stockTotal(product.stock), 0)} units ready to ship</small></article>
        </section>

        <div className="admin-toolbar">
          <div className="admin-tabs" role="tablist" aria-label="Dashboard sections">
            <button type="button" role="tab" aria-selected={tab === "products"} className={tab === "products" ? "admin-tab admin-tab-active" : "admin-tab"} onClick={() => setTab("products")}>PRODUCTS <span>{products.length}</span></button>
            <button type="button" role="tab" aria-selected={tab === "orders"} className={tab === "orders" ? "admin-tab admin-tab-active" : "admin-tab"} onClick={() => setTab("orders")}>ORDERS <span>{orders.length}</span></button>
          </div>
          {tab === "products" ? <button type="button" className="admin-primary add-product-button" onClick={() => { setEditing(undefined); setEditorOpen(true); }}><Plus size={15} /> ADD NEW PIECE</button> : <label className="order-search"><Search size={15} /><input value={orderSearch} onChange={(event) => setOrderSearch(event.target.value)} placeholder="Search receipt or customer" /></label>}
        </div>

        {tab === "products" ? (
          <section className="admin-product-list" aria-label="Product manager">
            {products.length === 0 ? <div className="admin-empty"><Package size={24} /><strong>No pieces in the collection</strong><p>Add a piece to bring it back to the rack.</p></div> : products.map((product, index) => {
              const count = stockTotal(product.stock);
              return (
                <article className="admin-product-row" key={product.id}>
                  <div className="admin-product-index">{String(index + 1).padStart(2, "0")}</div>
                  <div className="admin-product-preview"><GarmentArtwork product={product} side="front" className="garment-svg admin-garment-svg" /></div>
                  <div className="admin-product-information"><span className="admin-product-category">{product.category} / {product.art.replaceAll("-", " ")}</span><h2>{product.name}</h2><span className="admin-product-code">REF. {product.id.toUpperCase()}</span></div>
                  <div className="admin-product-price"><span>PRICE</span><strong>{formatPrice(product.price, "DZD")}</strong></div>
                  <div className="admin-product-inventory"><span>INVENTORY</span><strong className={count > 0 ? "inventory-in-stock" : "inventory-out-stock"}><i className="status-dot" />{count > 0 ? `${count} UNITS` : "SOLD OUT"}</strong><small>S / M / L / XL / 2XL</small></div>
                  <div className="admin-product-actions"><button className="stock-toggle-action" type="button" onClick={() => void toggleAvailability(product)} aria-label={count > 0 ? `Mark ${product.shortName} out of stock` : `Restock ${product.shortName}`} title={count > 0 ? "Mark out of stock" : "Restock all sizes"}><Package size={14} /><span>{count > 0 ? "OUT" : "RESTOCK"}</span></button><button type="button" onClick={() => { setEditing(product); setEditorOpen(true); }} aria-label={`Edit ${product.shortName}`}><Pencil size={15} /> <span>EDIT</span></button><button type="button" onClick={() => void deleteProduct(product)} aria-label={`Delete ${product.shortName}`}><Trash2 size={15} /></button></div>
                </article>
              );
            })}
            <div className="admin-list-foot"><span>LIVE RACK / {String(products.length).padStart(2, "0")} OBJECTS</span><span>INVENTORY UPDATES IN REAL TIME</span></div>
          </section>
        ) : (
          <section className="admin-orders-list" aria-label="Order manager">
            {filteredOrders.length === 0 ? <div className="admin-empty"><Package size={24} /><strong>{orders.length ? "No matching orders" : "No orders yet"}</strong><p>{orders.length ? "Try another receipt, customer or Wilaya." : "Incoming orders and their delivery details will appear here."}</p></div> : filteredOrders.map((order, index) => (
              <article className="admin-order-card" key={order.id}>
                <div className="admin-order-top"><div className="admin-order-reference"><span>ORDER / {String(filteredOrders.length - index).padStart(2, "0")}</span><h2>{order.receipt}</h2><small>{new Date(order.createdAt).toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" })}</small></div><label className="order-status-control"><span>ORDER STATUS</span><select value={order.status} className={`status-select status-${order.status.toLowerCase()}`} onChange={(event) => void setStatus(order.id, event.target.value as OrderStatus)}>{STATUSES.map((status) => <option value={status} key={status}>{status}</option>)}</select></label></div>
                <div className="admin-order-body">
                  <div className="admin-customer-details"><span className="analytics-label">CUSTOMER / DELIVERY</span><strong>{order.customer.name}</strong><a href={`tel:${order.customer.phone}`}>{order.customer.phone}</a><span>{[order.customer.wilaya, order.customer.commune, order.customer.address].filter(Boolean).join(" - ")}</span>{order.customer.notes && <small>NOTE / {order.customer.notes}</small>}</div>
                  <div className="admin-order-lines"><span className="analytics-label">ORDERED PIECES</span>{order.items.map((item, lineIndex) => <div className="admin-order-line" key={`${item.productId}-${item.size}-${lineIndex}`}><span>{item.title}<small>SIZE {item.size} <i>·</i> QTY {item.quantity}</small></span><strong>{formatPrice(item.price * item.quantity, "DZD")}</strong></div>)}<div className="admin-order-total"><span>{order.payment.toUpperCase()}</span><strong>{formatPrice(order.total, "DZD")}</strong></div></div>
                </div>
              </article>
            ))}
          </section>
        )}

        <footer className="admin-footer"><span>MX ABDOU / PRIVATE STUDIO</span><span>MADE IN ALGER · {new Date().getFullYear()}</span></footer>
      </div>

      <AnimatePresence>{editorOpen && <ProductEditor key={editing?.id ?? "new-product"} product={editing} onCancel={() => setEditorOpen(false)} onSave={saveProduct} />}</AnimatePresence>
      <AnimatePresence>{toast && <motion.div className="admin-toast" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }}><Check size={14} />{toast}</motion.div>}</AnimatePresence>
    </main>
  );
}
