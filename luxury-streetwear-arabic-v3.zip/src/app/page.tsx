"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Heart, LockKeyhole, Search, ShoppingBag, SlidersHorizontal, UserRound, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { AdminPinModal } from "@/components/AdminPinModal";
import { CartDrawer } from "@/components/CartDrawer";
import { ProductFocusModal } from "@/components/ProductFocusModal";
import { RackStage } from "@/components/RackStage";
import { useStore } from "@/components/StoreContext";
import { CATEGORY_AR, type Category, type Currency, type StoreProduct } from "@/lib/store-data";
import { IntroCinematic } from "@/components/IntroCinematic";
import { CinemaShowcase, TrustBar } from "@/components/CinemaShowcase";

const CATEGORY_OPTIONS: (Category | "ALL")[] = ["ALL", "JACKETS", "SHIRTS", "HOODIES", "PANTS"];

export default function HomePage() {
  const router = useRouter();
  const { products, wishlist, bagCount, adminPin, setAdminPin, addToCart, toggleWishlist } = useStore();
  const [category, setCategory] = useState<Category | "ALL">("ALL");
  const [filterOpen, setFilterOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [currency, setCurrency] = useState<Currency>("DZD");
  const [showWishlist, setShowWishlist] = useState(false);
  const [activeId, setActiveId] = useState(products[0]?.id ?? "");
  const [focusedProduct, setFocusedProduct] = useState<StoreProduct | null>(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [pinOpen, setPinOpen] = useState(false);
  const tapState = useRef({ last: 0, count: 0 });
  const searchInput = useRef<HTMLInputElement>(null);

  const visibleProducts = useMemo(() => products.filter((product) => {
    const categoryMatch = category === "ALL" || product.category === category;
    const wishlistMatch = !showWishlist || wishlist.includes(product.id);
    const query = searchText.trim().toLowerCase();
    const queryMatch = !query || `${product.name} ${product.shortName} ${product.category} ${product.description}`.toLowerCase().includes(query);
    return categoryMatch && wishlistMatch && queryMatch;
  }), [products, category, showWishlist, wishlist, searchText]);

  useEffect(() => {
    if (visibleProducts.length > 0 && !visibleProducts.some((product) => product.id === activeId)) setActiveId(visibleProducts[0].id);
  }, [visibleProducts, activeId]);

  useEffect(() => {
    if (searchOpen) window.requestAnimationFrame(() => searchInput.current?.focus());
  }, [searchOpen]);

  const setActive = useCallback((id: string) => setActiveId(id), []);
  const openProduct = useCallback((product: StoreProduct) => {
    setActiveId(product.id);
    setFocusedProduct(product);
  }, []);
  const closeProduct = useCallback(() => setFocusedProduct(null), []);

  const logoTap = (event: React.MouseEvent<HTMLAnchorElement>) => {
    event.preventDefault();
    const now = Date.now();
    if (now - tapState.current.last > 1100) tapState.current.count = 0;
    tapState.current.count += 1;
    tapState.current.last = now;
    if (tapState.current.count >= 5) {
      tapState.current.count = 0;
      setPinOpen(true);
    }
  };

  const unlockAdmin = (pin: string) => {
    setAdminPin(pin);
    setPinOpen(false);
    router.push("/admin");
  };

  const addSelectedToBag = (product: StoreProduct, size: Parameters<typeof addToCart>[1]) => {
    if (addToCart(product, size)) {
      setFocusedProduct(null);
      setCartOpen(true);
    }
  };

  return (
    <main className={`storefront${focusedProduct ? " storefront-is-focusing" : ""}`}>
      <IntroCinematic />
      <div className="scroll-progress" aria-hidden="true" />
      <header className="studio-header">
        <nav className="header-left" aria-label="Shop controls">
          <button className={`header-icon-button${searchOpen ? " header-icon-active" : ""}`} type="button" aria-label={searchOpen ? "إغلاق البحث" : "بحث"} onClick={() => { setSearchOpen((open) => !open); setSearchText(""); }}>
            {searchOpen ? <X size={17} strokeWidth={1.5} /> : <Search size={17} strokeWidth={1.5} />}
          </button>
          <div className="category-control">
            <button className={`category-trigger${filterOpen ? " category-trigger-open" : ""}`} type="button" aria-expanded={filterOpen} onClick={() => { setFilterOpen((open) => !open); setShowWishlist(false); }}>
              <SlidersHorizontal size={15} strokeWidth={1.4} /><span>{CATEGORY_AR[category]}</span><span className="category-chevron">⌄</span>
            </button>
            <AnimatePresence>
              {filterOpen && <motion.div className="category-menu" initial={{ opacity: 0, y: 7 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 5 }} transition={{ duration: 0.16 }}>
                <span className="category-menu-label">تسوّق حسب الفئة</span>
                {CATEGORY_OPTIONS.map((option) => <button key={option} type="button" className={category === option ? "category-option category-option-active" : "category-option"} onClick={() => { setCategory(option); setShowWishlist(false); setFilterOpen(false); }}>{CATEGORY_AR[option]}<span>{option === "ALL" ? products.length : products.filter((product) => product.category === option).length}</span></button>)}
              </motion.div>}
            </AnimatePresence>
          </div>
          <label className="currency-picker"><span className="currency-globe">◎</span><select aria-label="Choose currency" value={currency} onChange={(event) => setCurrency(event.target.value as Currency)}><option value="DZD">DZD</option><option value="USD">USD</option><option value="EUR">EUR</option></select><span className="currency-chevron">⌄</span></label>
        </nav>

        <a className="studio-wordmark" href="/" onClick={logoTap} aria-label="MX ABDOU — الصفحة الرئيسية">MX ABDOU<span>®</span></a>

        <nav className="header-right" aria-label="Account and shopping bag">
          <button className="header-icon-button account-trigger" type="button" aria-label="حسابي" onClick={() => setPinOpen(true)}><UserRound size={17} strokeWidth={1.45} /><span className="account-word">حسابي</span></button>
          <button className={`header-icon-button wishlist-trigger${showWishlist ? " header-icon-active" : ""}`} type="button" aria-label={`المفضلة، ${wishlist.length}`} aria-pressed={showWishlist} onClick={() => { setShowWishlist((current) => !current); setSearchText(""); }}>
            <Heart size={17} strokeWidth={1.45} fill={showWishlist ? "currentColor" : "none"} /><span className="header-count">{String(wishlist.length).padStart(2, "0")}</span>
          </button>
          <button className="header-icon-button bag-trigger" type="button" aria-label={`السلة، ${bagCount}`} onClick={() => setCartOpen(true)}>
            <ShoppingBag size={18} strokeWidth={1.45} /><span className="bag-label">السلة</span><span className="bag-badge">{bagCount}</span>
          </button>
        </nav>
      </header>

      <div className="search-strip-wrap"><AnimatePresence>
        {searchOpen && <motion.div className="search-strip" initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}>
          <Search size={17} strokeWidth={1.4} /><input ref={searchInput} value={searchText} onChange={(event) => setSearchText(event.target.value)} placeholder="ابحث في المجموعة…" aria-label="Search the collection" /><span>{visibleProducts.length} قطعة</span><button type="button" className="search-clear" onClick={() => setSearchText("")} aria-label="Clear search"><X size={15} /></button>
        </motion.div>}
      </AnimatePresence></div>

      <div className={`storefront-content${focusedProduct ? " storefront-content-blurred" : ""}`}>
        <section className="collection-intro">
          <div className="collection-heading-row">
            <h1 className="hero-title" aria-label="لمن يعيش بين الأمكنة.">{["لمن", "يعيش", "بين", "الأمكنة."].map((word, i) => <span className="hero-line" aria-hidden="true" key={word}><span style={{ transitionDelay: `${0.08 * i}s` }}>{word}</span></span>)}</h1>
            <p className="collection-deck">جاكيتات منفوخة بصور حقيقية للقطع. توصيل لكل الولايات والدفع عند الاستلام.</p>
          </div>
        </section>

        <TrustBar />
        <CinemaShowcase products={visibleProducts} currency={currency} onSelect={openProduct} />

        <div className="rack-section-heading"><div><span className="eyebrow">رفّ الاستوديو</span><span className="rack-edition-label">الإصدار الافتتاحي</span></div><span className="rack-availability">{showWishlist ? "قائمة أمنياتك" : category === "ALL" ? "المجموعة كاملة" : CATEGORY_AR[category]}</span></div>

        <RackStage products={visibleProducts} activeId={activeId} onActive={setActive} onSelect={openProduct} />

        <section className="how-to-order" aria-label="كيف تطلب">
          <h2>كيف تطلب</h2>
          <ol>
            <li><strong>اختر قطعتك</strong><span>حدّد المقاس وأضفها إلى السلة.</span></li>
            <li><strong>اكتب بياناتك</strong><span>الاسم واللقب ورقم الهاتف، ثم الولاية والبلدية.</span></li>
            <li><strong>نتصل بك</strong><span>نؤكد الطلب بالهاتف قبل الشحن، وتدفع عند الاستلام.</span></li>
          </ol>
        </section>

        <footer className="studio-footer">
          <div className="footer-brand"><a href="/" onClick={logoTap}>MX ABDOU<span>®</span></a><span>قطع للحركة اليومية</span></div>
          <div className="footer-middle"><span>الجزائر العاصمة</span><span>تأسّس 2026</span></div>
          <div className="footer-right"><button type="button" onClick={() => setPinOpen(true)}><LockKeyhole size={13} /> دخول الاستوديو</button><span>© MX ABDOU 2026</span></div>
        </footer>
      </div>

      <AnimatePresence>
        {focusedProduct && <ProductFocusModal key={focusedProduct.id} product={products.find((product) => product.id === focusedProduct.id) ?? focusedProduct} currency={currency} wishlisted={wishlist.includes(focusedProduct.id)} onWishlist={() => toggleWishlist(focusedProduct.id)} onClose={closeProduct} onAdd={addSelectedToBag} />}
      </AnimatePresence>

      <CartDrawer open={cartOpen} currency={currency} onClose={() => setCartOpen(false)} />
      <AdminPinModal open={pinOpen} onClose={() => setPinOpen(false)} onUnlock={unlockAdmin} />

    </main>
  );
}
