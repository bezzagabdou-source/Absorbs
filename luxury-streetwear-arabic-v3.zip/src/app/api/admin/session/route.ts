import { NextResponse } from "next/server";
import { isAdminPinValid } from "@/lib/admin-auth";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { pin?: string };
    if (!isAdminPinValid(body.pin)) {
      return NextResponse.json({ valid: false, error: "That access code is not correct." }, { status: 401 });
    }
    return NextResponse.json({ valid: true });
  } catch {
    return NextResponse.json({ valid: false, error: "A valid access code is required." }, { status: 400 });
  }
}
