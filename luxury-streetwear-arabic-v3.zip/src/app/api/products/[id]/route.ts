import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { isAdminRequest } from "@/lib/admin-auth";

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!isAdminRequest(request)) {
    return NextResponse.json({ error: "Admin access required." }, { status: 401 });
  }

  const { id } = await params;
  try {
    await db.delete(products).where(eq(products.id, id));
    return NextResponse.json({ deleted: true });
  } catch {
    return NextResponse.json({ error: "The product could not be removed." }, { status: 500 });
  }
}
