import { and, asc, eq, inArray } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { products as productTable } from "@/db/schema";
import { isAdminRequest } from "@/lib/admin-auth";
import { LEGACY_SEED_IDS, NEW_SEED_IDS, ORIGINAL_ENGLISH_NAMES, seedProducts, type StoreProduct } from "@/lib/store-data";

export const dynamic = "force-dynamic";

function databaseProduct(product: StoreProduct) {
  return {
    ...product,
    frontImage: product.frontImage ?? null,
    backImage: product.backImage ?? null,
  };
}

export async function GET() {
  try {
    // Drop the old illustrated demo products (they have no photo) so the real photo catalogue shows.
    await db.delete(productTable).where(inArray(productTable.id, LEGACY_SEED_IDS));
    let rows = await db.select().from(productTable).orderBy(asc(productTable.id));
    if (rows.length === 0) {
      await db.insert(productTable).values(seedProducts.map(databaseProduct)).onConflictDoNothing();
      rows = await db.select().from(productTable).orderBy(asc(productTable.id));
    } else {
      // Add the new catalogue pieces, and move the original four to Arabic unless the owner already edited them.
      const fresh = seedProducts.filter((product) => NEW_SEED_IDS.includes(product.id));
      if (fresh.length > 0) await db.insert(productTable).values(fresh.map(databaseProduct)).onConflictDoNothing();
      for (const [id, englishName] of Object.entries(ORIGINAL_ENGLISH_NAMES)) {
        const seed = seedProducts.find((product) => product.id === id);
        if (!seed) continue;
        await db.update(productTable)
          .set({ name: seed.name, shortName: seed.shortName, description: seed.description, fabric: seed.fabric, fit: seed.fit, care: seed.care, sizeChart: seed.sizeChart })
          .where(and(eq(productTable.id, id), eq(productTable.name, englishName)));
      }
      rows = await db.select().from(productTable).orderBy(asc(productTable.id));
    }
    return NextResponse.json(rows.map(({ createdAt: _createdAt, frontImage, backImage, ...product }) => ({
      ...product,
      frontImage: frontImage ?? undefined,
      backImage: backImage ?? undefined,
    })));
  } catch {
    return NextResponse.json(seedProducts);
  }
}

export async function POST(request: Request) {
  if (!isAdminRequest(request)) {
    return NextResponse.json({ error: "Admin access required." }, { status: 401 });
  }

  let product: StoreProduct;
  try {
    product = (await request.json()) as StoreProduct;
  } catch {
    return NextResponse.json({ error: "Invalid product data." }, { status: 400 });
  }

  if (
    !product.id || !product.name?.trim() || !product.shortName?.trim() ||
    !Number.isInteger(product.price) || product.price < 0 || !product.stock || !product.art
  ) {
    return NextResponse.json({ error: "A name, valid price, artwork, and size stock are required." }, { status: 400 });
  }

  try {
    const values = databaseProduct(product);
    await db.insert(productTable).values(values).onConflictDoUpdate({
      target: productTable.id,
      set: {
        name: values.name,
        shortName: values.shortName,
        category: values.category,
        price: values.price,
        description: values.description,
        fabric: values.fabric,
        fit: values.fit,
        care: values.care,
        sizeChart: values.sizeChart,
        stock: values.stock,
        art: values.art,
        frontImage: values.frontImage,
        backImage: values.backImage,
      },
    });
    return NextResponse.json(product);
  } catch {
    return NextResponse.json({ error: "The product could not be saved to the catalogue." }, { status: 500 });
  }
}
