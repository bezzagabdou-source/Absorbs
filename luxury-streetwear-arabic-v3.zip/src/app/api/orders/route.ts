import { and, desc, eq, inArray } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, products } from "@/db/schema";
import { isAdminRequest } from "@/lib/admin-auth";
import { OTHER_COMMUNE, findWilaya, normalizeDzPhone } from "@/lib/algeria";
import { SIZES, type OrderLine, type PaymentMethod, type Size, type StoreOrder } from "@/lib/store-data";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  if (!isAdminRequest(request)) {
    return NextResponse.json({ error: "Admin access required." }, { status: 401 });
  }
  try {
    const rows = await db.select().from(orders).orderBy(desc(orders.createdAt));
    return NextResponse.json(rows);
  } catch {
    return NextResponse.json({ error: "Orders are temporarily unavailable." }, { status: 503 });
  }
}

export async function POST(request: Request) {
  let incoming: {
    id?: string;
    receipt?: string;
    customer?: StoreOrder["customer"];
    items?: OrderLine[];
    payment?: PaymentMethod;
  };

  try {
    incoming = (await request.json()) as typeof incoming;
  } catch {
    return NextResponse.json({ error: "Invalid order data." }, { status: 400 });
  }

  const { id, receipt, customer, items, payment } = incoming;
  const wilaya = findWilaya(customer?.wilaya ?? "");
  const phone = normalizeDzPhone(customer?.phone ?? "");
  const firstName = customer?.firstName?.trim() ?? "";
  const lastName = customer?.lastName?.trim() ?? "";
  const commune = customer?.commune?.trim() ?? "";
  if (
    !id || !receipt || !customer || !firstName || !lastName || !phone || !wilaya || !commune ||
    firstName.length > 60 || lastName.length > 60 || commune.length > 80 || commune === OTHER_COMMUNE ||
    (customer.notes ?? "").length > 500 || !Array.isArray(items) ||
    items.length === 0 || !["Cash on delivery", "Card / Express"].includes(payment ?? "")
  ) {
    return NextResponse.json({ error: "أكمل بيانات التوصيل: الاسم واللقب ورقم هاتف صحيح والولاية والبلدية." }, { status: 400 });
  }
  // نبني بيانات الزبون من القيم المنظّفة فقط، ولا نخزّن أي حقل زائد أرسله المتصفح
  const cleanCustomer: StoreOrder["customer"] = {
    name: `${firstName} ${lastName}`, firstName, lastName, phone, wilaya: wilaya.name, commune,
    notes: (customer.notes ?? "").trim(),
  };
  if (items.some((item) => !item.productId || !SIZES.includes(item.size) || !Number.isSafeInteger(item.quantity) || item.quantity < 1 || item.quantity > 20)) {
    return NextResponse.json({ error: "One or more bag quantities are invalid." }, { status: 400 });
  }

  try {
    const result = await db.transaction(async (transaction) => {
      const productIds = [...new Set(items.map((item) => item.productId))];
      const currentProducts = await transaction
        .select()
        .from(products)
        .where(inArray(products.id, productIds))
        .for("update");
      if (currentProducts.length !== productIds.length) throw new Error("PRODUCT_UNAVAILABLE");

      const byId = new Map(currentProducts.map((product) => [product.id, product]));
      const remainingStock = new Map(currentProducts.map((product) => [product.id, { ...product.stock }]));
      const verifiedItems: OrderLine[] = items.map((item) => {
        const product = byId.get(item.productId);
        const stock = remainingStock.get(item.productId);
        if (!product || !stock) throw new Error("PRODUCT_UNAVAILABLE");
        const size = item.size as Size;
        if ((stock[size] ?? 0) < item.quantity) throw new Error("OUT_OF_STOCK");
        stock[size] -= item.quantity;
        return {
          productId: product.id,
          title: product.name,
          art: product.art as OrderLine["art"],
          frontImage: product.frontImage ?? undefined,
          price: product.price,
          size,
          quantity: item.quantity,
        };
      });

      for (const product of currentProducts) {
        const nextStock = remainingStock.get(product.id);
        if (nextStock) {
          await transaction.update(products).set({ stock: nextStock }).where(eq(products.id, product.id));
        }
      }

      const now = new Date();
      const order: StoreOrder = {
        id,
        receipt,
        customer: cleanCustomer,
        items: verifiedItems,
        total: verifiedItems.reduce((sum, item) => sum + item.price * item.quantity, 0),
        payment: payment as PaymentMethod,
        status: "Pending",
        createdAt: now.toISOString(),
      };
      await transaction.insert(orders).values({
        ...order,
        createdAt: now,
      });
      return order;
    });

    return NextResponse.json({ order: result });
  } catch (error) {
    if (error instanceof Error && error.message === "OUT_OF_STOCK") {
      return NextResponse.json({ error: "A selected size has just sold out. Please update your bag." }, { status: 409 });
    }
    if (error instanceof Error && error.message === "PRODUCT_UNAVAILABLE") {
      return NextResponse.json({ error: "A piece in your bag is no longer available." }, { status: 409 });
    }
    if (error instanceof Error && error.message.includes("duplicate key")) {
      return NextResponse.json({ error: "Please try placing your order once more." }, { status: 409 });
    }
    return NextResponse.json({ error: "Your order could not be saved. Please try again." }, { status: 503 });
  }
}
