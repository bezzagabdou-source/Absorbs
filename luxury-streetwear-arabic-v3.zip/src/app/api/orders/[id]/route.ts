import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { isAdminRequest } from "@/lib/admin-auth";
import type { OrderStatus } from "@/lib/store-data";

const orderStatuses: OrderStatus[] = ["Pending", "Confirmed", "Shipped", "Delivered"];

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!isAdminRequest(request)) {
    return NextResponse.json({ error: "Admin access required." }, { status: 401 });
  }

  const { id } = await params;
  let status: OrderStatus;
  try {
    const body = (await request.json()) as { status?: OrderStatus };
    if (!body.status || !orderStatuses.includes(body.status)) {
      return NextResponse.json({ error: "Choose a valid order status." }, { status: 400 });
    }
    status = body.status;
  } catch {
    return NextResponse.json({ error: "Invalid order update." }, { status: 400 });
  }

  try {
    const [updated] = await db.update(orders).set({ status }).where(eq(orders.id, id)).returning();
    if (!updated) return NextResponse.json({ error: "Order not found." }, { status: 404 });
    return NextResponse.json(updated);
  } catch {
    return NextResponse.json({ error: "The order status could not be updated." }, { status: 503 });
  }
}
