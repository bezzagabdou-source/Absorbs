import type { Metadata } from "next";
import type { ReactNode } from "react";
import { StoreProvider } from "@/components/StoreContext";
import { Readex_Pro, Reem_Kufi } from "next/font/google";
import "./globals.css";

// خطوط محلية تُحمَّل مع الموقع (بدون طلب خارجي يعطّل العرض)
const display = Reem_Kufi({ subsets: ["arabic", "latin"], weight: ["400", "500", "600", "700"], display: "swap", variable: "--font-display" });
const body = Readex_Pro({ subsets: ["arabic", "latin"], weight: ["300", "400", "500", "600", "700"], display: "swap", variable: "--font-body" });

export const metadata: Metadata = {
  title: "MX ABDOU — قطع للحركة اليومية",
  description: "طبقات مدروسة للحياة اليومية. صُمّمت في الجزائر. صُنعت للحركة.",
  applicationName: "MX ABDOU Studio",
  keywords: ["MX ABDOU", "Algerian streetwear", "studio essentials", "streetwear"],
  openGraph: {
    title: "MX ABDOU — قطع للحركة اليومية",
    description: "الإصدار الافتتاحي. صُمّم في الجزائر. صُنع للحركة.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={`${display.variable} ${body.variable}`}>
      <body>
        <StoreProvider>{children}</StoreProvider>
      </body>
    </html>
  );
}
