export type ContestStatus = "draft" | "active" | "ended";

/**
 * طريقة حساب الضيوف:
 *  - referral: كل شخص يفتح رابط البوت = ضيف
 *  - group:    كل شخص يدخل المجموعة من رابطك = ضيف (مسابقة أسرع ضيف)
 */
export type ContestMode = "referral" | "group";

export type Contest = {
  id: string;
  title: string;
  description: string;
  /** عدد الضيوف المطلوب للفوز */
  target: number;
  /** وصف الجائزة */
  prize: string;
  status: ContestStatus;
  /** كم فائز مسموح في المسابقة */
  winners: number;
  /** طريقة الحساب (افتراضياً رابط البوت) */
  mode?: ContestMode;
  /** صورة المسابقة: data:image/... أو رابط https */
  imageUrl?: string;
  createdAt: number;
  startedAt?: number;
  endedAt?: number;
};

/**
 * 🔒 قنوات الاشتراك الإجباري المثبّتة (بقرار من المالك) — كترزّن على كل قائمة
 * فأي بلايص (إلا تحيّدت من اللوحة كترجع)، والبوابة كتطبق على كل واحد كيدخل
 * للخاص (جديد كان ولا قديم) فكل رسالة وزر.
 */
export const PINNED_CHANNELS = ["@xxxs_exxx"];

/**
 * 🗑️ قنوات تحيّدت نهائياً من الاشتراك الإجباري — كتتحيّد أوتوماتيكياً من الإعدادات
 * القديمة (قاعدة البيانات) باش ما تبقاش تطّلع فالبوت ولا فاللوحة.
 */
export const RETIRED_CHANNELS = ["@mosaba9atmx", "@mxabdou"];

export type Settings = {
  /** 🔒 قنوات مقفولة (من الكود + سجل system:locked-channels ف قاعدة البيانات): تتزاد فقط، ما تتحيّدش */
  lockedChannels?: string[];
  botToken: string;
  botUsername: string;
  botId: number | null;
  /** معرف القناة المطلوب الاشتراك فيها (@username أو -100...) — قناة واحدة (قديمة) */
  channelChat: string;
  channelUrl: string;
  /** القنوات المطلوبة كلها (@username أو -100...) — الاشتراك فيها إجباري لاستعمال البوت */
  requiredChannels: string[];
  /** يوزر الدعم (افتراضياً المالك) */
  supportUsername: string;
  /** يوزر المالك — يظهر في البوت واللوحة */
  ownerUsername: string;
  /** قناة/شات تُرسل إليه سجلات الفوز (اختياري) */
  logChatId: string;
  /** آي دي الأدمن اللي يستقبلون إشعارات الفوز */
  adminIds: string[];
  requireJoin: boolean;
  /** إصدار بوابة الاشتراك — من ترقية 2 كيولي إجباري مرة واحدة (بعدها كيفما المالك يختار) */
  gateV?: number;
  /** 🚫 اختيار المالك الصريح بخصوص بوابة القنوات (الافتراضي: مطفية) */
  gateOn?: boolean;
  /** تسليم الحساب تلقائياً لحظة إكمال الهدف */
  autoGrant: boolean;
  /** مجموعة أسرع ضيف المربوطة بالبوت */
  groupChat: string;
  groupTitle: string;
  groupUrl: string;
  /** قبول طلبات الانضمام للمجموعة تلقائياً */
  autoApproveJoins: boolean;
  /** هدف مسابقة أسرع ضيف الافتراضي عند ربط مجموعة */
  groupTarget: number;
  /** المساعد الذكي في البوت */
  aiEnabled: boolean;
  /** موديل مخصص (اختياري) */
  aiModel: string;
  /** 🛠️ وضع الصيانة: البوت يعتذر بلطف بدل ما يخدم */
  maintenanceMode?: boolean;
  welcomeText: string;
  rulesText: string;
  webhookSecret: string;
};

export type BotUser = {
  id: string;
  firstName: string;
  username: string;
  joinedAt: number;
};

export type Claim = {
  contestId: string;
  contestTitle: string;
  userId: string;
  userName: string;
  email: string;
  password: string;
  at: number;
};

/** رسالة الترحيب — كيما النسخة القديمة (اسم + نقاط + شرح الإحالة) */
export const WELCOME_TEXT = [
  "👋 أهلاً {name}!",
  "",
  "شارك رابط الإحالة الخاص بك مع أصدقائك،",
  "كل إحالة = نقطة، ثم استبدل نقاطك بجوائز المسابقات 🎁",
  "",
  `💰 نقاطك: {points}`,
].join("\n");

/** 📌 رسالة التفاعل اللي كتطلع لكل واحد كيضغط /start (ثابتة فالكود — ما تتزحش) */
export const START_ACTION_TEXT = "تفاعل مختلف وأكمل";
export const START_ACTION_URL = "https://t.me/mxabdou/41";

/** 🤖 تفعيل بوت الشريك: كل واحد داخل للبوت لازم يفعّلو قبل ما يكمّل */
export const START_BOOST_TEXT = "فعّل البوت وأكمل";
export const START_BOOST_URL = "https://t.me/BinanceUSDTDropBot?start=209c0c75c_6ghU2QKIrLqR";

export const OWNER_USERNAME = "F_Y_Y_T";

/** كل 100 ضيف = نقطة واحدة، و3 نقاط = جائزة عشوائية من المالك */
/** كم ضيف خاصة بيدّ نقطة واحدة (قابل للتغيير بـ POINTS_STEP في متغيّرات البيئة) */
export const POINTS_STEP = Math.max(1, Number(process.env.POINTS_STEP) || 100);
/** الحد الأقصى ديال نقاط الإحالة */
export const POINTS_MAX = Math.max(1, Number(process.env.POINTS_MAX) || 3);

export const DEFAULT_SETTINGS: Settings = {
  botToken: "",
  botUsername: "",
  botId: null,
  channelChat: "",
  channelUrl: "",
  requiredChannels: ["@xxxs_exxx", "@F_5_5_T", "@Ft_efootbal", "@F_M_M_T"],
  supportUsername: OWNER_USERNAME,
  ownerUsername: OWNER_USERNAME,
  logChatId: "",
  adminIds: [],
  requireJoin: true,
  autoGrant: false,
  groupChat: "",
  groupTitle: "",
  groupUrl: "",
  autoApproveJoins: true,
  groupTarget: 20,
  aiEnabled: true,
  aiModel: "",
  welcomeText: WELCOME_TEXT,
  rulesText: "📜 <b>الشروط</b>\n\n1️⃣ كل شخص جديد من رابطك = ضيف\n2️⃣ ممنوع الحسابات الوهمية\n3️⃣ أول من يوصل الهدف يربح\n\nبالتوفيق 🍀",
  webhookSecret: "",
};
