# Khaam Motion v1.4 - Project Setup & Usage Guide

## Overview

**Khaam Motion** is a Claude skill for creating Arabic-first motion graphics with kinetic typography, sound effects, and narration. It generates MP4 videos locally using Claude Code.

## Quick Start

### Prerequisites

1. **Claude Code** (desktop app)
2. **Opus 5.5 model** with **max effort**
3. **ElevenLabs account** (optional, for AI narration)

### Installation Steps

1. **Open Claude Desktop** → **Code** tab
2. **Set model and effort**:
   ```
   /model opus
   /effort max
   ```
3. **Install the skill**:
   - Drag `khaam-motion.zip` into the Claude window
   - Type: **"Install skill"**
4. **Run preflight check**:
   ```
   cd <your-project-folder>
   python "<skill-path>/scripts/preflight.py"
   ```

## Project Structure

```
<project-folder>/
├── assets/
│   ├── fonts/              # Arabic and Latin fonts
│   ├── sfx/               # Sound effects
│   └── logo/              # Project logo
├── styles/                # Project style configuration
├── TASTE.md              # User style and preferences
├── PROGRESS.md           # Project progress tracking
├── LOG.md                # Session log
├── .khaam/               # Configuration
│   └── config.json       # Project settings
├── templates/            # Motion templates
├── scripts/              # Utility scripts
├── reference/            # Documentation guides
└── README.md             # Project README
```

## Core Components

### 1. **Core Skill Files**

- **`SKILL.md`** - Claude's main instructions and workflow
- **`START-HERE.md`** - Initial setup guide
- **`README.md`** - Skill overview and capabilities

### 2. **Reference Documentation**

The `reference/` folder contains comprehensive guides:

- **Arabic Typography**: `reference/arabic-typography.md` - Arabic text rules, motion guidelines
- **Fonts**: `reference/arabic-fonts.md` - Font library and licensing
- **Hooks**: `reference/hooks.md` - Social media hook research
- **Explainer Reels**: `reference/explainer-reel-system.md` - Video structure and components
- **Visual Design**: `reference/visual-design.md` - Design principles and layout
- **Voiceover**: `reference/voiceover.md` - AI narration setup
- **Cinematic Toolkit**: `reference/cinematic-toolkit.md` - 3D scene creation

### 3. **Style Templates**

The `styles/` folder contains:

- **Example styles**: 8 sample style configurations for inspiration
- **Template**: `_template.md` - Build your own project style

### 4. **Scripts**

The `scripts/` folder provides utilities:

- **`preflight.py`** - System readiness check (read-only)
- **`get_fonts.py`** - Download and install Arabic fonts
- **`openverse_sfx.py`** - Source free sound effects
- **`gen_tts_elevenlabs.py`** - Generate AI narration

### 5. **Templates**

The `templates/` folder includes:

- **`templates/render/`** - Deterministic rendering starter kit
- **`templates/sfx-catalog.example.json`** - Sound effects catalog schema

## Project Workflow

### Phase 1: Initial Setup

1. **Create project folder**: `
   mkdir -p <project-folder>/assets/{fonts,sfx,logo>`
2. **Copy style template**:
   ```
   cp styles/_template.md <project-folder>/styles/project-style.md
   ```
3. **Create TASTE.md**:
   ```
   cp styles/_template.md <project-folder>/TASTE.md
   ```
4. **Create PROGRESS.md**:
   ```
   # Track project status and progress
   ```
5. **Create LOG.md**:
   ```
   # Log project sessions and changes
   ```

### Phase 2: Project Configuration

1. **Edit `.khaam/config.json`**:
   ```json
   {
     "project_name": "project-name",
     "style": "path/to/styles/",
     "toolkit_dir": "/path/to/toolkit",
     "audio_python": "python3"
   }
   ```

2. **Add assets**:
   - Arabic fonts to `assets/fonts/`
   - Sound effects to `assets/sfx/`
   - Logo to `assets/logo/`

### Phase 3: Style Development

1. **Configure TASTE.md**:
   - Define visual style preferences
   - Set animation characteristics
   - Choose color schemes and typography
   - Specify sound design approach

2. **Build your style**:
   - Use `styles/_template.md` as a base
   - Reference example styles for inspiration
   - Customize to match your project

### Phase 4: Video Creation

The workflow follows the three-gate system:

#### Gate A: Planning
1. **Hook Research**: Use `reference/hooks.md` for 3-second hook options
2. **Storyboard**: Create 3-6 rendered stills including hook frames
3. **Plan Approval**: Complete plan with hook, script, style, sound, narration

#### Gate B: Build
1. **Generate Narration**: Use `scripts/gen_tts_elevenlabs.py` for voiceover
2. **Source SFX**: Use `scripts/openverse_sfx.py` for free sound effects
3. **Animate**: Create scenes using `templates/render/`
4. **Mix**: Combine audio and render video

#### Gate C: Review
1. **Preview**: Show first complete video (motion + sound + narration)
2. **Feedback**: Collect user feedback
3. **Iterate**: Make targeted fixes

### Phase 5: Delivery

1. **Final Render**: Full resolution MP4
2. **Documentation**: Update LOG.md and PROGRESS.md
3. **Delivery**: Complete project documentation

## Project Examples

### Example: Tech Innovation Reel

```markdown
# TASTE.md - Tech Innovation Reel

## Taste
- **Visual**: Minimalist, clean, tech-focused
- **Motion**: Smooth transitions, 60fps
- **Colors**: Deep blues, cyan accents
- **Typography**: Modern sans-serif
- **Animation**: Subtle reveals, data visualizations

## Animation
- **Duration**: 20 seconds
- **Format**: 9:16 (mobile)
- **Frame Rate**: 60fps
- **Resolution**: Full HD (1080×1920)

## Style
- **Color Scheme**: #0F1117 (dark), #00D9FF (cyan), #FFFFFF (white)
- **Font Pairings**: Inter + IBM Plex Mono
- **Visual Elements**: Geometric shapes, data charts
- **Typography**: Bold headlines, code mono text

## Tooling
- **Toolkit**: Shared (toolchain in `~/.cache/khaam-motion/toolkit`)
- **Environment**: Node.js 18+, FFmpeg, Playwright
- **Version Control**: Git with `.gitignore`

## Experience
- **Audience**: Tech professionals
- **Purpose**: Product demonstration
- **Tone**: Professional, technical
- **Complexity**: Advanced
```

### Example: Cultural Heritage Reel

```markdown
# TASTE.md - Cultural Heritage Reel

## Taste
- **Visual**: Traditional, decorative, artistic
- **Motion**: Elegant, flowing, rhythmic
- **Colors**: Rich golds, deep reds, warm browns
- **Typography**: Calligraphic, traditional Arabic scripts
- **Animation**: Flowing motions, rotational elements

## Animation
- **Duration**: 25 seconds
- **Format**: Square (1:1)
- **Frame Rate**: 30fps
- **Resolution**: HD (1080×1080)

## Style
- **Color Scheme**: #8B0000 (burgundy), #FFD700 (gold), #FFFFFF (white)
- **Font Pairings**: Amiri + Traditional Arabic
- **Visual Elements**: Traditional patterns, calligraphy
- **Typography**: Ornate headlines, elegant body

## Tooling
- **Toolkit**: Project-specific (custom toolkit)
- **Environment**: Python 3.10+, FFmpeg, custom audio tools
- **Version Control**: Git with large file handling

## Experience
- **Audience**: Cultural enthusiasts
- **Purpose**: Cultural celebration
- **Tone**: Reverent, artistic
- **Complexity**: Intermediate
```

## Project Templates

### Basic Explainer Reel Template

```markdown
# templates/project-name/TASTE.md

## Story
- **Topic**: [Your topic]
- **Message**: [Your main message]
- **Audience**: [Target audience]

## Style
- **Visual**: [Visual style]
- **Motion**: [Motion style]
- **Colors**: [Color scheme]
- **Typography**: [Text style]

## Elements
- **Hook**: [3 hook options]
- **Storyboard**: [Scene descriptions]
- **SFX**: [Sound effects]
- **Narration**: [Voiceover style]
```

## Best Practices

### Project Structure
- **Organize assets by type**
- **Use consistent naming conventions**
- **Maintain version control**
- **Document all decisions**

### File Management
- **Keep TASTE.md updated**
- **Update PROGRESS.md regularly**
- **Log all changes in LOG.md**
- **Document licensing information**

### Workflow Management
- **Follow the three-gate system**
- **Use preview system effectively**
- **Document user feedback**
- **Iterate based on feedback**

## Troubleshooting

### Common Issues

1. **Font Loading**
   - Ensure fonts are properly installed
   - Check font file formats
   - Verify font licensing

2. **Sound Playback**
   - Test sound files before use
   - Ensure proper attribution
   - Check file formats

3. **Style Application**
   - Verify TASTE.md configuration
   - Check file paths
   - Ensure naming consistency

### Getting Help

1. **Use documentation**
   - Refer to `README.md` for setup
   - Use `SKILL.md` for workflow
   - Consult `reference/` guides

2. **Check project logs**
   - Review `LOG.md` for session info
   - Check `PROGRESS.md` for status
   - Document issues in logs

## Quick Reference Commands

### Initial Setup
```bash
# Create project structure
mkdir -p project/assets/{fonts,sfx,logo}
cp styles/_template.md project/TASTE.md

# Install fonts
cd project
python3 scripts/get_fonts.py

# Source sound effects
python3 scripts/openverse_sfx.py
```

### Video Creation
```bash
# Plan with hooks
cd project
claude "Plan a 15-second tech explainer reel with 3 hooks"

# Create storyboard
claude "Create storyboard for hook 1"

# Build video
claude "Build complete explainer reel with motion, SFX, and narration"

# Preview
claude "Show me preview of the explainer reel"

# Deliver
claude "Render final explainer reel at full resolution"
```

### Project Management
```bash
# Update progress
cd project
echo "- [x] Hook approved" >> PROGRESS.md
echo "- [ ] Storyboard created" >> PROGRESS.md

# Log session
cd project
date >> LOG.md
echo "Session: [Description]" >> LOG.md
```

## Configuration Options

### Environment Variables
```bash
# Override toolkit location
export KHAAM_TOOLKIT=/custom/toolkit/path

# Override audio Python interpreter
export KHAAM_AUDIO_PYTHON=python3.11

# Override SFX library
export KHAAM_SFX_LIBRARY=/custom/sfx/library

# Override Chromium
export KHAAM_CHROMIUM=/custom/chromium/path
```

### Configuration File

Edit `project/.khaam/config.json`:

```json
{
  "project_name": "project-name",
  "style": "project-name/styles/",
  "toolkit_dir": "/path/to/toolkit",
  "audio_python": "python3",
  "toolkit_type": "shared",
  "user_taste": "~/.cache/khaam-motion/user-taste.md"
}
```

## Advanced Features

### Custom Style Development

1. **Copy example style**
   ```
   cp styles/example-style.md project/styles/custom-style.md
   ```

2. **Edit custom style**
   - Modify to match your project
   - Save in `project/styles/`

3. **Update TASTE.md**
   ```
   styles/custom-style.md
   ```

### Arabic Typography

Follow `reference/arabic-typography.md`:

1. **Choose fonts**
   - Download fonts using `scripts/get_fonts.py`
   - Add to `assets/fonts/`

2. **Configure Arabic text**
   - Use `templates/render/lib/arabic.js`
   - Apply RTL text rules
   - Ensure proper kerning and ligatures

3. **Test rendering**
   - Use preview system
   - Check Arabic QA checklist
   - Verify text readability

### Sound Design

Follow `reference/local-sound-workflow.md`:

1. **Source order**:
   - User's licensed sounds → Openverse → Procedural → ElevenLabs

2. **Mix rules**:
   - Place sounds on visual events
   - Trim tails, preserve clarity
   - Target -14 LUFS

### Automation

Use scripts for automation:

1. **Preflight check**
   ```bash
   python3 scripts/preflight.py
   ```

2. **Font installation**
   ```bash
   python3 scripts/get_fonts.py
   ```

3. **Sound sourcing**
   ```bash
   python3 scripts/openverse_sfx.py
   ```

4. **Preview generation**
   ```bash
   node scripts/preview.mjs
   ```

## Migration Guide

### From Previous Versions

1. **Copy existing assets**:
   ```
   cp -r old-project/assets/ new-project/assets/
   cp old-project/TASTE.md new-project/
   cp old-project/.khaam/config.json new-project/.khaam/
   ```

2. **Update configuration**:
   - Check for deprecated settings
   - Update paths to new structure
   - Verify toolkit compatibility

### Project Migration

1. **Backup old project**
   ```
   cp -r old-project/ ~/backups/project-backup-
   ```

2. **Create new project**
   ```
   mkdir new-project
   cd new-project
   # Follow setup guide
   ```

3. **Import assets**:
   - Copy fonts, sounds, styles
   - Update TASTE.md
   - Configure toolkit

## Project Maintenance

### Regular Tasks

1. **Update TASTE.md**
   - Add new style elements
   - Update style choices
   - Document project changes

2. **Update PROGRESS.md**
   - Mark completed tasks
   - Add ongoing work
   - Document feedback

3. **Update LOG.md**
   - Log session details
   - Document decisions
   - Track changes

### Maintenance Commands
```bash
# Check project status
cd project
python3 scripts/preflight.py

# Update documentation
cd project
git add TASTE.md PROGRESS.md LOG.md
```

## Conclusion

Khaam Motion provides a complete solution for creating Arabic-first motion graphics videos. By following the project structure and workflow outlined in this guide, you can efficiently develop professional motion graphics with proper style management, sound design, and Arabic typography support.

The key to success is:
1. **Consistent project structure**
2. **Regular documentation**
3. **Following the three-gate workflow**
4. **Using the reference guides effectively**

Start by setting up your project structure, configure your TASTE.md, and follow the workflow step by step. The system will guide you through each phase, ensuring quality results while maintaining flexibility for creative experimentation.