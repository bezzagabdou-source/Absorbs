import React, { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Toaster, toast } from 'react-hot-toast'
import POS from './pages/POSScreen.jsx'
import Repair from './pages/RepairScreen.jsx'
import Inventory from './pages/InventoryScreen.jsx'
import Wallet from './pages/WalletScreen.jsx'
import { DatabaseProvider } from './context/DatabaseContext.jsx'
import './App.css'

const App = () => {
  const [systemInfo, setSystemInfo] = useState({
    language: localStorage.getItem('language') || 'ar',
    theme: localStorage.getItem('theme') || 'dark',
    barcodeReaderEnabled: localStorage.getItem('barcodeReaderEnabled') !== 'false'
  })

  useEffect(() => {
    localStorage.setItem('language', systemInfo.language)
    localStorage.setItem('theme', systemInfo.theme)
    localStorage.setItem('barcodeReaderEnabled', systemInfo.barcodeReaderEnabled.toString())

    document.documentElement.setAttribute('dir', systemInfo.language === 'ar' ? 'rtl' : 'ltr')
    document.documentElement.setAttribute('lang', systemInfo.language)
  }, [systemInfo])

  return (
    <DatabaseProvider>
      <Router>
        <div className="min-h-screen bg-gray-900 text-white font-ar">
          <Toaster position="top-right" />

          <header className="bg-gray-800 border-b border-gray-700 p-4">
            <div className="max-w-7xl mx-auto flex justify-between items-center">
              <h1 className="text-2xl font-bold text-yellow-400">
                📱 Mobile Shop & Repair POS System
              </h1>
              <div className="flex gap-4 items-center">
                <span className="text-sm text-gray-400">v1.0.0</span>
                <button
                  onClick={() => setSystemInfo(prev => ({
                    ...prev,
                    language: prev.language === 'ar' ? 'fr' : 'ar'
                  }))}
                  className="px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-sm"
                >
                  {systemInfo.language === 'ar' ? 'FR' : 'AR'}
                </button>
              </div>
            </div>
          </header>

          <main className="max-w-7xl mx-auto p-6">
            <Routes>
              <Route path="/pos" element={<POS />} />
              <Route path="/repair" element={<Repair />} />
              <Route path="/inventory" element={<Inventory />} />
              <Route path="/wallet" element={<Wallet />} />
              <Route path="/" element={<POS />} />
            </Routes>
          </main>
        </div>
      </Router>
    </DatabaseProvider>
  )
}

export default App