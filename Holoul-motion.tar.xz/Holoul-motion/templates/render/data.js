// Design dimensions and absolute scene timing. Replace the examples with approved scenes.
export const W = 1080, H = 1920, FPS = 30;
export const scenes = [
  { id: 'arabic-motion-graphics', start: 0, end: 18.5 },   // Algerian Tech Innovation motion graphics
  { id: 'claude-tools-reel', start: 18.5, end: 26 },      // Claude Code Tools showcase
];
export const DURATION = scenes.at(-1).end;
// Arabic display font for motion graphics scenes. Download it first: python <skill>/scripts/get_fonts.py "Kufam"
// Falls back to a system font if the file is missing (check the still: fallback shapes are wrong for branding).
export const ARABIC_FONT = { family: 'Kufam', urls: ['/assets/fonts/Kufam/Kufam[wght].ttf'] };