// Arabic Motion Graphics: Algerian Tech Innovation
// Motion graphics video showcasing Algerian technological innovation
// With proper Arabic typography, RTL flow, and cultural integration

// Constants for video specifications
const W = 1080, H = 1920, FPS = 30;

// Arabic typography setup
export const ARABIC_FONT = {
  family: 'Kufam',
  urls: ['/assets/fonts/Kufam/Kufam[wght].ttf']
};

// Scene definitions for the motion graphics video
export const scenes = [
  // Opening Scene: Algerian Flag Reveal
  {
    id: 'flag-reveal',
    start: 0,
    end: 2.5,
    draw: function(ctx, t, {W, H, scale, dur}) {
      const progress = Math.min(1, t / dur);

      // Algerian flag colors and animation
      const colors = {
        green: {r: 0, g: 142, b: 69},
        white: {r: 255, g: 255, b: 255},
        red: {r: 206, g: 17, b: 38}
      };

      // Background: dark tech theme
      ctx.fillStyle = '#0a0f14';
      ctx.fillRect(0, 0, W, H);

      // Vertical Algerian flag stripes
      const stripeHeight = H / 3;

      for (let i = 0; i < 3; i++) {
        const y = i * stripeHeight;
        const alpha = i === 1 ? 1 : 0.3 + (progress * 0.7); // Middle stripe brightest

        ctx.fillStyle = `rgba(${colors.green.r}, ${colors.green.g}, ${colors.green.b}, ${alpha})`;
        ctx.fillRect(0, y, W, stripeHeight);
      }

      // Red stripe animation
      ctx.fillStyle = `rgba(${colors.red.r}, ${colors.red.g}, ${colors.red.b}, ${0.3 + progress * 0.7})`;
      ctx.fillRect(0, 2 * stripeHeight, W, stripeHeight);

      // White stripe with glow effect
      ctx.fillStyle = `rgba(${colors.white.r}, ${colors.white.g}, ${colors.white.b}, ${0.3 + progress * 0.7})`;
      ctx.fillRect(0, stripeHeight, W, stripeHeight);

      // Animated Algerian symbol
      const symbolSize = Math.min(W, H) * 0.3;
      const symbolX = W / 2;
      const symbolY = H / 2;

      ctx.save();
      ctx.translate(symbolX, symbolY);
      ctx.scale(progress, progress);
      ctx.fillStyle = '#ffd700';
      ctx.font = `bold ${symbolSize * 0.4}px ${ARABIC_FONT.family}`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('الجزائر', 0, -symbolSize * 0.2);
      ctx.font = `${symbolSize * 0.2}px Arial`;
      ctx.fillText('ALGERIA', 0, symbolSize * 0.2);
      ctx.restore();

      // Tech grid animation
      ctx.strokeStyle = '#00d4ff';
      ctx.lineWidth = 1;
      ctx.globalAlpha = 0.3 + progress * 0.7;

      for (let x = 0; x < W; x += W / 10) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, H);
        ctx.stroke();
      }
    }
  },

  // Tech Innovation Scene
  {
    id: 'tech-innovation',
    start: 2.5,
    end: 7.5,
    draw: function(ctx, t, {W, H, scale, dur}) {
      const timeInScene = t - 2.5;
      const progress = Math.min(1, timeInScene / (dur - 2.5));

      // Background with tech pattern
      ctx.fillStyle = '#0a0f14';
      ctx.fillRect(0, 0, W, H);

      // Animated code elements
      ctx.fillStyle = '#00ff88';
      ctx.font = `${W * 0.04}px monospace`;

      // Code snippets that appear over time
      const codeLines = [
        'function innovate() {',
        '  const Algerian = { culture: "rich", potential: "unlimited" };',
        '  return local + global;',
        '}',
        '',
        '// تحويل الأفكار إلى واقع'
      ];

      const lineHeight = W * 0.06;
      const startY = H * 0.3;

      codeLines.forEach((line, index) => {
        const lineOpacity = Math.min(1, (timeInScene - index * 0.3) / 0.5);
        if (lineOpacity > 0) {
          ctx.globalAlpha = lineOpacity;
          ctx.fillText(line, W * 0.05, startY + index * lineHeight);
        }
      });

      // Arabic explanation
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${W * 0.035}px ${ARABIC_FONT.family}`;
      ctx.textAlign = 'right';
      ctx.fillText('ابتكار جزائري', W * 0.9, H * 0.6);

      ctx.font = `${W * 0.025}px Arial`;
      ctx.fillText('Algerian Innovation', W * 0.9, H * 0.65);

      ctx.font = `${W * 0.02}px Arial`;
      ctx.fillText('تحويل الأفكار المحلية إلى حلول عالمية', W * 0.9, H * 0.75);

      // Geometric shapes representing tech
      const shapeProgress = Math.sin(timeInScene * Math.PI) * 0.5 + 0.5;

      for (let i = 0; i < 5; i++) {
        const x = W * (0.2 + i * 0.16);
        const y = H * 0.8;
        const size = 20 + shapeProgress * 30;

        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(timeInScene * (Math.PI / 4) + i * 0.5);
        ctx.fillStyle = `rgba(0, 212, 255, ${0.5 + shapeProgress * 0.5})`;
        ctx.fillRect(-size / 2, -size / 2, size, size);
        ctx.restore();
      }
    }
  },

  // Cultural Impact Scene
  {
    id: 'cultural-impact',
    start: 7.5,
    end: 15,
    draw: function(ctx, t, {W, H, scale, dur}) {
      const timeInScene = t - 7.5;
      const progress = Math.min(1, timeInScene / (dur - 7.5));

      // Animated Algerian landscape/technovation
      const time = t * 0.5;

      // Background gradient
      const gradient = ctx.createLinearGradient(0, 0, 0, H);
      gradient.addColorStop(0, '#0a0f14');
      gradient.addColorStop(1, '#1a2332');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, W, H);

      // Animated sun/moon
      const celestialY = H * 0.3 * (Math.sin(time) + 1);
      ctx.fillStyle = '#ffd700';
      ctx.beginPath();
      ctx.arc(W * 0.9, celestialY, W * 0.1, 0, Math.PI * 2);
      ctx.fill();

      // Mountains silhouette
      ctx.fillStyle = '#16202d';
      ctx.beginPath();
      ctx.moveTo(0, H * 0.7);
      ctx.lineTo(W * 0.3, H * 0.4);
      ctx.lineTo(W * 0.6, H * 0.65);
      ctx.lineTo(W * 0.9, H * 0.5);
      ctx.lineTo(W, H * 0.7);
      ctx.closePath();
      ctx.fill();

      // Growing Algerian trees
      for (let i = 0; i < 3; i++) {
        const treeX = W * (0.2 + i * 0.3);
        const treeHeight = progress * H * 0.4;

        // Tree trunk
        ctx.fillStyle = '#8b4513';
        ctx.fillRect(treeX - W * 0.02, H - treeHeight - 20, W * 0.04, 20);

        // Tree leaves (animated)
        ctx.fillStyle = '#00ff88';
        const leafCount = 8 + progress * 8;

        for (let j = 0; j < leafCount; j++) {
          const angle = (j * Math.PI * 2 / leafCount) + time * 0.5;
          const distance = (j % 3 === 0) ? treeHeight * 0.3 : treeHeight * 0.2;
          const leafX = treeX + Math.cos(angle) * distance;
          const leafY = H - treeHeight - Math.sin(angle) * distance;

          ctx.save();
          ctx.translate(leafX, leafY);
          ctx.rotate(angle);
          ctx.fillRect(-W * 0.02, -W * 0.02, W * 0.04, W * 0.04);
          ctx.restore();
        }
      }

      // Cultural symbols animation
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${W * 0.03}px ${ARABIC_FONT.family}`;
      ctx.textAlign = 'center';

      // Moving Arabic text from right to left
      const textX = W - (progress * W * 1.5);
      ctx.globalAlpha = progress;
      ctx.fillText('التكنولوجيا', textX, H * 0.8);
      ctx.fillText('المعرفة', textX, H * 0.9);
      ctx.fillText('الابتكار', textX, H * 1.0);

      // Latin transliteration
      ctx.font = `${W * 0.02}px Arial`;
      ctx.fillText('Technology | Knowledge | Innovation', W / 2, H * 0.85);

      // Connection lines between concepts
      ctx.strokeStyle = '#00d4ff';
      ctx.lineWidth = 2;
      ctx.globalAlpha = progress * 0.5;

      ctx.beginPath();
      ctx.moveTo(W - 100, H * 0.8);
      ctx.lineTo(W * 0.3, H * 0.45);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(W - 100, H * 0.9);
      ctx.lineTo(W * 0.6, H * 0.55);
      ctx.stroke();
    }
  },

  // Closing Scene
  {
    id: 'closing',
    start: 15,
    end: 18.5,
    draw: function(ctx, t, {W, H, scale, dur}) {
      const timeInScene = t - 15;
      const progress = Math.min(1, timeInScene / (dur - 15));

      // Final fade to black with Algerian branding
      if (progress > 0.7) {
        ctx.fillStyle = `rgba(0, 0, 0, ${Math.pow((progress - 0.7) / 0.3, 2)})`;
        ctx.fillRect(0, 0, W, H);
      }

      // Final Algerian text
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${W * 0.04}px ${ARABIC_FONT.family}`;
      ctx.textAlign = 'center';

      // Pulsing effect
      const pulse = Math.sin(timeInScene * 3) * 0.1 + 1;
      ctx.save();
      ctx.scale(pulse, pulse);
      ctx.fillText('الجزائر', W / 2, H * 0.5);
      ctx.restore();

      ctx.font = `bold ${W * 0.03}px Arial`;
      ctx.fillText('ALGERIAN INNOVATION', W / 2, H * 0.6);

      ctx.font = `${W * 0.02}px Arial`;
      ctx.fillText('Making Waves in Global Tech', W / 2, H * 0.7);

      // Animated Algerian flag at corners
      if (progress > 0.3) {
        const flagProgress = (progress - 0.3) / 0.7;

        // Top left flag
        const flagHeight = H * 0.15 * flagProgress;
        ctx.fillStyle = '#008E45';
        ctx.fillRect(0, 0, W * 0.2, flagHeight);
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, flagHeight * 0.33, W * 0.2, flagHeight * 0.34);
        ctx.fillStyle = '#CE1115';
        ctx.fillRect(0, flagHeight * 0.67, W * 0.2, flagHeight * 0.33);

        // Bottom right flag
        ctx.fillStyle = '#008E45';
        ctx.fillRect(W * 0.8, H - flagHeight, W * 0.2, flagHeight);
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(W * 0.8, H - flagHeight * 0.33, W * 0.2, flagHeight * 0.34);
        ctx.fillStyle = '#CE1115';
        ctx.fillRect(W * 0.8, H - flagHeight * 0.67, W * 0.2, flagHeight * 0.33);
      }
    }
  }
];

export const DURATION = scenes.at(-1).end;

export function init({W, H, scale}) {
  console.log('Algerian Tech Innovation Motion Graphics loaded');
  console.log('Arabic font:', ARABIC_FONT.family);
  console.log('Duration:', DURATION, 'seconds');
}