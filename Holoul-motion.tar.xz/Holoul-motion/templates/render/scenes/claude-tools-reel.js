// Claude Code Tools Reel: Professional Video Production Showcase
// Comprehensive demonstration of Claude's video creation capabilities
// Featuring Arabic typography, RTL flow, and cultural integration

// Constants for video specifications
const W = 1080, H = 1920, FPS = 30;

// Claude brand colors and Arabic font setup
export const ARABIC_FONT = {
  family: 'Kufam',
  urls: ['/assets/fonts/Kufam/Kufam[wght].ttf']
};

export const CLAUDE_COLORS = {
  primary: '#0066CC',      // Claude blue
  secondary: '#FFD60A',   // Claude yellow
  accent: '#FF6B6B',      // Accent red
  dark: '#0a0f14',        // Dark background
  light: '#ffffff'        // Light text
};

// Scene definitions for the Claude Tools Reel
export const scenes = [
  // Opening: Claude Tools Discovery
  {
    id: 'tools-discovery',
    start: 0,
    end: 3,
    draw: function(ctx, t, {W, H, scale, dur}) {
      const progress = Math.min(1, t / dur);

      // Dark background with tech pattern
      ctx.fillStyle = CLAUDE_COLORS.dark;
      ctx.fillRect(0, 0, W, H);

      // Tech grid animation
      ctx.strokeStyle = '#1e3a5f';
      ctx.lineWidth = 1;
      ctx.globalAlpha = 0.3 + progress * 0.4;

      for (let x = 0; x < W; x += W / 8) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, H);
        ctx.stroke();
      }

      // Claude logo/words appearing
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${W * 0.06}px Arial`;
      ctx.textAlign = 'center';
      ctx.fillText('CLAUDE', W / 2, H * 0.3);

      ctx.font = `${W * 0.04}px Arial`;
      ctx.fillText('CODE TOOLS', W / 2, H * 0.4);

      // Tool icons appearing over time
      const toolCount = 6;
      const toolSize = W * 0.08;
      const toolSpacing = W / (toolCount + 1);

      for (let i = 0; i < toolCount; i++) {
        const x = toolSpacing * (i + 1);
        const opacity = Math.min(1, (progress - i * 0.15) / 0.3);
        const scale = Math.sin(progress * 4 + i) * 0.2 + 1;

        if (opacity > 0) {
          ctx.save();
          ctx.translate(x, H * 0.6);
          ctx.scale(scale, scale);
          ctx.globalAlpha = opacity;

          // Tool icon (abstract representation)
          ctx.fillStyle = '#0066CC';
          ctx.fillRect(-toolSize / 2, -toolSize / 2, toolSize, toolSize);

          // Tool label
          ctx.fillStyle = '#ffffff';
          ctx.font = `${W * 0.015}px Arial`;
          ctx.textAlign = 'center';
          ctx.fillText(['Code', 'Edit', 'Read', 'Write', 'Glob', 'Search'][i], x, H * 0.7);

          ctx.restore();
        }
      }
    }
  },

  // Claude's Development Tools Scene
  {
    id: 'dev-tools-scene',
    start: 3,
    end: 8,
    draw: function(ctx, t, {W, H, scale, dur}) {
      const timeInScene = t - 3;
      const progress = Math.min(1, timeInScene / (dur - 3));

      // Background with Claude brand colors
      ctx.fillStyle = `linear-gradient(0% 0%, 100% 100%, from(#0a0f14), to(#1a2332))`;
      ctx.fillRect(0, 0, W, H);

      // Main Claude product icon with pulsing effect
      ctx.save();
      const pulse = Math.sin(timeInScene * 2) * 0.1 + 1;
      ctx.scale(pulse, pulse);
      ctx.translate(W / 2, H * 0.3);

      // Claude circle
      ctx.fillStyle = '#0066CC';
      ctx.beginPath();
      ctx.arc(0, 0, W * 0.15, 0, Math.PI * 2);
      ctx.fill();

      // Tool marks inside
      ctx.fillStyle = '#ffd60a';
      ctx.font = `bold ${W * 0.08}px Arial`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('⌨', 0, 0);

      ctx.restore();

      // Tool features appearing
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${W * 0.04}px Arial`;
      ctx.textAlign = 'left';

      const features = [
        'Intuitive AI assistance',
        'Seamless file editing',
        'Powerful code analysis',
        'Professional development workflows'
      ];

      const featureY = H * 0.5;

      features.forEach((feature, index) => {
        const featureOpacity = Math.min(1, (progress - index * 0.2) / 0.25);

        if (featureOpacity > 0) {
          ctx.globalAlpha = featureOpacity;
          ctx.fillText(`✓ ${feature}`, W * 0.1, featureY + index * W * 0.08);
        }
      });

      // Arabic feature demonstration
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#ffd60a';
      ctx.font = `bold ${W * 0.03}px ${ARABIC_FONT.family}`;
      ctx.textAlign = 'right';
      ctx.fillText('مساعدة ذكية بديهية', W * 0.9, H * 0.75);

      ctx.font = `${W * 0.02}px Arial`;
      ctx.fillText('Intuitive AI assistance', W * 0.9, H * 0.8);
    }
  },

  // Code Review & Analysis Scene
  {
    id: 'code-review-scene',
    start: 8,
    end: 14,
    draw: function(ctx, t, {W, H, scale, dur}) {
      const timeInScene = t - 8;
      const progress = Math.min(1, timeInScene / (dur - 8));

      // Code editor interface visualization
      ctx.fillStyle = '#1e1e1e';
      ctx.fillRect(0, 0, W, H);

      // Code blocks appearing
      ctx.globalAlpha = progress;

      // Line numbers area
      ctx.fillStyle = '#858585';
      ctx.font = `${W * 0.02}px monospace`;
      ctx.textAlign = 'right';

      for (let i = 10; i <= 50; i += 5) {
        ctx.fillText(i.toString(), W * 0.08, H * 0.2 + i * W * 0.008);
      }

      // Code syntax highlighting
      ctx.fillStyle = '#d4d4d4';
      ctx.font = `${W * 0.02}px monospace`;
      ctx.textAlign = 'left';

      const codeLines = [
        'def analyze_code(file_path):',
        '    """Analyze code for bugs and improvements"""',
        '    try:',
        '        with open(file_path) as f:',
        '            content = f.read()',
        '
        '        # Claude AI analysis',
        '        bugs = detect_issues(content)',
        '        suggestions = suggest_improvements(content)',
        '
        '        return {',
        '            "bugs": bugs,',
        '            "improvements": suggestions,',
        '            "confidence": calculate_confidence(content)'
        '        }',
        '    except Exception as e:',
        '        return {"error": str(e)}'
      ];

      const lineHeight = W * 0.006;
      const codeStartY = H * 0.3;

      codeLines.forEach((line, index) => {
        const lineOpacity = Math.min(1, (progress - index * 0.12) / 0.35);

        if (lineOpacity > 0) {
          ctx.globalAlpha = lineOpacity;
          ctx.fillText(line, W * 0.15, codeStartY + index * lineHeight * 20);
        }
      });

      // Arabic code analysis
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#50e3c2';
      ctx.font = `bold ${W * 0.03}px ${ARABIC_FONT.family}`;
      ctx.textAlign = 'right';
      ctx.fillText('تحليل الكود الاحترافي', W * 0.9, H * 0.85);

      ctx.font = `${W * 0.025}px Arial`;
      ctx.fillText('Professional Code Analysis', W * 0.9, H * 0.9);
    }
  },

  // Collaboration & Workflow Scene
  {
    id: 'collaboration-scene',
    start: 14,
    end: 20,
    draw: function(ctx, t, {W, H, scale, dur}) {
      const timeInScene = t - 14;
      const progress = Math.min(1, timeInScene / (dur - 14));

      // Collaborative workspace visualization
      ctx.fillStyle = '#0a1929';
      ctx.fillRect(0, 0, W, H);

      // Multiple screens/tabs representing collaboration
      const screenWidth = W / 3;

      for (let screen = 0; screen < 3; screen++) {
        const x = screen * screenWidth;
        const screenOpacity = Math.min(1, (progress - screen * 0.25) / 0.35);

        ctx.save();
        ctx.globalAlpha = screenOpacity;

        // Screen border
        ctx.strokeStyle = '#00d4ff';
        ctx.lineWidth = 2;
        ctx.strokeRect(x + 10, 50, screenWidth - 20, H - 100);

        // Screen content
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${W * 0.02}px Arial`;
        ctx.textAlign = 'center';

        // Screen title
        ctx.fillText(['Chat', 'Code', 'Review'][screen], x + screenWidth / 2, 80);

        // Screen content preview
        ctx.font = `${W * 0.015}px monospace`;

        if (screen === 0) {
          // Chat interface
          for (let i = 0; i < 3; i++) {
            ctx.fillText(`User: Hello Claude...`, x + screenWidth / 2, 130 + i * 30);
          }
        } else if (screen === 1) {
          // Code editor preview
          ctx.fillText(`function test():`, x + screenWidth / 2, 130);
          ctx.fillText(`    return True`, x + screenWidth / 2, 160);
        } else {
          // Review interface
          ctx.fillText(`✓ Bug found: Line 42`, x + screenWidth / 2, 130);
          ctx.fillText(`✓ Suggestion: Optimize loop`, x + screenWidth / 2, 160);
        }

        ctx.restore();
      }

      // Global collaboration message
      ctx.globalAlpha = progress;
      ctx.fillStyle = '#ffd60a';
      ctx.font = `bold ${W * 0.04}px ${ARABIC_FONT.family}`;
      ctx.textAlign = 'center';
      ctx.fillText('التعاون السلس عبر الفرق', W / 2, H * 0.85);

      ctx.font = `${W * 0.03}px Arial`;
      ctx.fillText('Seamless Collaboration Across Teams', W / 2, H * 0.9);
    }
  },

  // Closing: Claude Impact
  {
    id: 'closing-scene',
    start: 20,
    end: 26,
    draw: function(ctx, t, {W, H, scale, dur}) {
      const timeInScene = t - 20;
      const progress = Math.min(1, timeInScene / (dur - 20));

      // Fade from previous scene with Claude branding
      if (progress < 0.7) {
        ctx.fillStyle = `rgba(10, 15, 20, ${1 - progress})`;
        ctx.fillRect(0, 0, W, H);
      }

      // Main Claude message
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${W * 0.06}px Arial`;
      ctx.textAlign = 'center';

      // Pulsing Claude identity
      const pulse = Math.sin(timeInScene * 1.5) * 0.05 + 1;
      ctx.save();
      ctx.scale(pulse, pulse);
      ctx.fillText('CLAUDE', W / 2, H * 0.4);
      ctx.restore();

      // Mission statement
      ctx.font = `${W * 0.025}px Arial`;
      ctx.fillText('Transforming Software Development Through AI', W / 2, H * 0.5);

      ctx.font = `bold ${W * 0.03}px ${ARABIC_FONT.family}`;
      ctx.fillText('تحويل تطوير البرمجيات من خلال الذكاء الاصطناعي', W / 2, H * 0.6);

      // Tool ecosystem visualization
      if (progress > 0.3) {
        const ecosystemProgress = (progress - 0.3) / 0.7;
        const nodeCount = 8;
        const radius = W * 0.2 * ecosystemProgress;

        ctx.strokeStyle = '#0066CC';
        ctx.lineWidth = 2;
        ctx.globalAlpha = ecosystemProgress * 0.7;

        for (let i = 0; i < nodeCount; i++) {
          const angle = (i / nodeCount) * Math.PI * 2;
          const x = W / 2 + Math.cos(angle) * radius;
          const y = H * 0.7 + Math.sin(angle) * radius;

          ctx.beginPath();
          ctx.arc(x, y, W * 0.03, 0, Math.PI * 2);
          ctx.fillStyle = '#0066CC';
          ctx.fill();

          if (i > 0) {
            ctx.beginPath();
            ctx.moveTo(W / 2, H * 0.7);
            ctx.lineTo(x, y);
            ctx.stroke();
          }
        }
      }

      // Final call to action
      ctx.globalAlpha = progress;
      ctx.fillStyle = '#50e3c2';
      ctx.font = `bold ${W * 0.03}px Arial`;
      ctx.textAlign = 'center';
      ctx.fillText('Start Building With Claude Today', W / 2, H * 0.85);
    }
  }
];

export const DURATION = scenes.at(-1).end;

export function init({W, H, scale}) {
  console.log('Claude Code Tools Reel Loaded');
  console.log('Showcases Claude Code development tools');
  console.log('Features Arabic integration with RTL support');
  console.log('Duration:', DURATION, 'seconds');
}