# TASTE.md - Tech Innovation Explainer Reel

## Taste
- **Visual Style**: Minimalist, tech-focused with clean interfaces
- **Motion**: Smooth transitions, 60fps animations with subtle movement
- **Colors**: Deep blues (#0F1117), cyan accents (#00D9FF), white text (#FFFFFF)
- **Typography**: Inter font for UI, IBM Plex Mono for code snippets
- **Animation**: Subtle fade-ins, slide-ups, data visualizations

## Animation
- **Duration**: 20 seconds
- **Format**: 9:16 (mobile-first)
- **Frame Rate**: 60fps
- **Resolution**: Full HD (1080×1920)

## Style
- **Color Scheme**: #0F1117 (dark background), #00D9FF (cyan accent), #FFFFFF (white text)
- **Font Pairings**: Inter for headlines and UI, IBM Plex Mono for technical content
- **Visual Elements**: Geometric shapes, data charts, modern UI components
- **Typography**: Bold headlines, regular body, code and caption text

## Tooling
- **Toolkit**: Shared (use `~/.cache/khaam-motion/toolkit`)
- **Environment**: Node.js 18+, FFmpeg, Playwright
- **Version Control**: Git with proper .gitignore

## Experience
- **Audience**: Tech professionals and developers
- **Purpose**: Product demonstration and tech innovation showcase
- **Tone**: Professional, technical, yet approachable
- **Complexity**: Intermediate level

## Elements
- **Hook**: "Transform your code into visual stories - see how modern tech innovations are reshaping our digital world"
- **Storyboard**: 
   - Frame 1: Introduction to the innovation
   - Frame 2: Problem-solution demonstration
   - Frame 3: Technical implementation showcase
   - Frame 4: Impact and future outlook
   - Frame 5: Call to action

## Sound Design
- **SFX**: Subtle UI interactions, data validation sounds, transition effects
- **Voiceover**: Clear, technical narration with AI voice
- **Music**: Minimal background ambient music

## Constraints
- **Format**: 9:16 (mobile optimization)
- **Duration**: 20 seconds (200 frames at 60fps)
- **Resolution**: 1080x1920
- **Assets**: Tech-focused imagery, code snippets, modern UI elements

## Arabic Integration
- **Text**: Technical content in Arabic with Latin transcription
- **Typography**: Modern Arabic fonts that complement the overall design
- **RTL Support**: Proper right-to-left text rendering for Arabic content