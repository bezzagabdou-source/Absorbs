# Project Setup

This project is an Arabic-first motion graphics repository using the Khaam Motion skill for Claude. It creates animated videos with Arabic text, sound effects, and narration.

## Project Structure

```
/projects/your-project/
├── assets/
│   ├── fonts/              # Custom font assets
│   ├── sfx/               # Sound effects
│   └── logo/              # Project logo
├── styles/                # Project style configuration (from styles/_template.md)
├── TASTE.md              # User's style and preferences (TASTE stands for Taste, Animation, Style, Tooling, Experience)
├── PROGRESS.md           # Project progress tracking
├── LOG.md                # Session log and changes
├── assets/sfx/ATTRIBUTION.md  # Sound effect attributions
└── .khaam/               # Project configuration
    └── config.json       # Project configuration
```

## Getting Started

### 1. Project Setup

Copy this project structure into your desired directory:

```bash
# Replace "your-project" with your desired name
mkdir -p projects/your-project/assets/{fonts,sfx,logo}
touch projects/your-project/TASTE.md
mkdir -p projects/your-project/.khaam
cat > projects/your-project/.khaam/config.json << EOF
{
  "project_name": "your-project",
  "style": "path/to/styles/",
  "toolkit_dir": "~/.cache/khaam-motion/toolkit",
  "audio_python": "python3"
}
EOF
```

### 2. Arabic Typography Setup

Add Arabic fonts to `projects/your-project/assets/fonts/`:
- **Aref Ruqaa**: For headlines and UI elements
- **Noto Naskh Arabic**: For body text and paragraphs
- **Uthmanic Hafs**: For Quranic text (if applicable)

### 3. Logo Setup

Add your project logo to `projects/your-project/assets/logo/`

### 4. Sound Effects

Add sound effects to `projects/your-project/assets/sfx/`
- Mix, loop, and test your sound files
- Create `ATTRIBUTION.md` with proper licensing information

### 5. Project Style Configuration

Your project's `TASTE.md` defines:
- Visual style and animation preferences
- Color schemes and typography choices
- Animation timing and motion characteristics
- Sound effect preferences
- Voiceover choices

### 6. Initial Project Setup

1. **Configure your style** by editing `TASTE.md`
2. **Add assets** (fonts, sounds, logo)
3. **Choose your hook** using the style from `reference/hooks.md`
4. **Plan your storyboard** using the explainer reel system from `reference/explainer-reel-system.md`
5. **Generate your first video** using the workflow from `SKILL.md` §3

## Project Configuration

Edit `projects/your-project/.khaam/config.json` to customize:

```json
{
  "project_name": "your-project",
  "style": "relative/path/to/your/project/styles/",
  "toolkit_dir": "/path/to/your/toolkit",
  "audio_python": "python3",
  "toolkit_type": "shared",  // "shared", "project", or "none"
  "user_taste": "~/.cache/khaam-motion/user-taste.md"
}
```

## Project Tracking

### TASTE.md - Your Project Profile

```markdown
# TASTE.md

## Taste
- **Visual Style**: [Describe your visual preferences]
- **Motion**: [Animation characteristics]
- **Colors**: [Color palette choices]
- **Typography**: [Font choices and hierarchy]
- **Animation**: [Motion style and timing]

## Animation
- **Duration**: [Video length]
- **Format**: [9:16, 16:9, square]
- **Frame Rate**: [24, 30, 60 fps]
- **Resolution**: [Full HD, 4K, etc.]

## Style
- **Color Scheme**: [RGB/Hex values]
- **Font Pairings**: [Font combinations]
- **Visual Elements**: [Key visual components]
- **Typography**: [Text hierarchy]

## Tooling
- **Toolkit**: [Shared, project-specific, or none]
- **Environment**: [Development setup]
- **Version Control**: [Git configuration]

## Experience
- **Audience**: [Target audience]
- **Purpose**: [Video purpose]
- **Tone**: [Emotional tone]
- **Complexity**: [Technical complexity]
```

### PROGRESS.md - Project Status

Track your project's development progress:

```markdown
# PROGRESS.md

## Current Status
- [ ] Style configuration completed
- [ ] Assets organized and tested
- [ ] First hook approved
- [ ] Storyboard created
- [ ] First video rendered
- [ ] User feedback collected
- [ ] Final video delivered

## Completed Videos
- [Video 1: Description - Date]
- [Video 2: Description - Date]

## Ongoing Work
- [ ] Current video in production
- [ ] Assets being prepared
- [ ] Style refinements

## Notes
- [ ]
```

### LOG.md - Session Log

Record your project sessions:

```markdown
# LOG.md

## Session 1: Initial Setup
Date: [Date]
- Project created
- Style configured
- Assets added

## Session 2: First Video
Date: [Date]
- Hook approved
- Storyboard created
- Video rendered

## Session 3: Revision
Date: [Date]
- User feedback received
- Updates made
- Final version approved
```

## Best Practices

### Project Structure
- Keep assets organized by type
- Use consistent naming conventions
- Maintain version control
- Document licensing information

### File Organization
- `assets/fonts/`: Arabic and Latin fonts
- `assets/sfx/`: Sound effects with attributions
- `assets/logo/`: Project branding
- `styles/`: Custom style configurations
- `.khaam/`: Project configuration

### Progress Tracking
- Update PROGRESS.md regularly
- Document completed and ongoing work
- Note user feedback and revisions

## Troubleshooting

### Common Issues

1. **Font Loading Issues**
   - Ensure all fonts are properly installed
   - Check font file formats (.ttf, .otf)
   - Verify font licensing

2. **Sound Playback**
   - Test sound files before project completion
   - Ensure proper attribution files
   - Check file formats for compatibility

3. **Style Application**
   - Verify TASTE.md configuration
   - Check file paths in configuration
   - Ensure consistent naming conventions

### Getting Help

1. **Check Documentation**
   - Refer to `README.md` for initial setup
   - Use `SKILL.md` for workflow guidance
   - Consult `reference/` guides for specific tasks

2. **Project-Specific Help**
   - Use `LOG.md` for session-specific issues
   - Refer to `PROGRESS.md` for project status
   - Check project-specific configuration

## Next Steps

1. **Set up your project structure**
2. **Configure your TASTE.md**
3. **Add assets and style**
4. **Generate your first video**
5. **Track progress with PROGRESS.md**
6. **Document sessions in LOG.md**

## Example: TASTE.md Template

```markdown
# TASTE.md

## Taste
- **Visual Style**: Minimalist with bold Arabic headlines
- **Motion**: Smooth transitions, 60fps
- **Colors**: Deep blues, gold accents, white text
- **Typography**: Aref Ruqaa for headlines, Noto Naskh for body
- **Animation**: Subtle fade-ins, slide-ups

## Animation
- **Duration**: 15 seconds
- **Format**: 9:16 (mobile-first)
- **Frame Rate**: 60fps
- **Resolution**: Full HD (1080×1920)

## Style
- **Color Scheme**: #0F1117 (bg), #FBBF24 (accent), #F9FAFB (text)
- **Font Pairings**: Aref Ruqaa + Noto Naskh Arabic
- **Visual Elements**: Geometric shapes, calligraphic elements
- **Typography**: Bold headlines, regular body, caption text

## Tooling
- **Toolkit**: Shared (use `~/.cache/khaam-motion/toolkit`)
- **Environment**: Node.js 18+, FFmpeg, Playwright
- **Version Control**: Git with proper .gitignore

## Experience
- **Audience**: Young Algerian professionals
- **Purpose**: Tech innovation showcase
- **Tone**: Professional yet approachable
- **Complexity**: Intermediate
```

## Advanced Configuration

### Custom Style Template

Use `styles/_template.md` as a starting point for your project:

```markdown
# styles/your-style-name.md

## Style
- **Visual**: [Your visual description]
- **Motion**: [Your motion description]
- **Colors**: [Your color palette]
- **Typography**: [Your font choices]
- **Animation**: [Your animation style]

## Mood
- **Emotion**: [Target emotion]
- **Cultural**: [Cultural elements]
- **Technical**: [Technical approach]

## Elements
- **Hook Examples**: [3 hook examples]
- **Storyboard**: [Storyboard descriptions]
- **Sound Design**: [Sound preferences]
- **Voiceover**: [Voiceover style]

## Constraints
- **Format**: [Video format]
- **Duration**: [Video length]
- **Resolution**: [Video resolution]
- **Assets**: [Asset requirements]
```

## Quick Start

1. **Copy this project structure**
2. **Edit your TASTE.md**
3. **Add assets (fonts, sounds, logo)**
4. **Configure .khaam/config.json**
5. **Generate your first video**
6. **Track progress**

## Project Success Checklist

- [ ] Project directory created
- [ ] Assets organized
- [ ] TASTE.md configured
- [ ] Style template built
- [ ] Configuration files set up
- [ ] Progress tracking enabled
- [ ] Session logging active

This project structure ensures systematic development while maintaining flexibility for creative experimentation and efficient project management.