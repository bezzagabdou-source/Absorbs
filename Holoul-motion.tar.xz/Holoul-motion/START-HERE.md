# ابدأ هنا — «موشن خام» 🎬

هلا وغلا! هذي مهارة تخلي Claude يسوي لك **فيديوهات موشن جرافيك** كاملة بالعربي: الفكرة، والتصميم، والحركة، والصوت، وMP4 جاهز.

**أسهل طريقة:** أعطِ هذا المجلد كامل لـ Claude وقل له **«ابدأ»**. هو بيمشي معك خطوة بخطوة. والخطوات تحت لو تبي تعرفها بنفسك.

---

## ١. وش تحتاج
- **اشتراك Claude مدفوع** (Pro أو أعلى). المجاني ما فيه **Claude Code**، وهو اللي يرندر الفيديو على جهازك.
- **تطبيق Claude على الكمبيوتر**: فيه قسم **Code**. هذا هو Claude Code بواجهة سهلة.
- اختياري: حساب **ElevenLabs** لو تبي صوت معلّق بالذكاء الاصطناعي.

## ٢. اختر أقوى إعداد (مهم)
- **الموديل:** Opus 5.5
- **الـ effort:** أعلى شي، **max**

في قسم Code اكتب:
```
/model opus
/effort max
```
`max` يبقى للجلسة الحالية بس، فاكتبه كل ما تفتح جلسة جديدة.

## ٣. ثبّت المهارة
**الطريقة الأولى، وهي الأفضل: Claude Code**
1. افتح تطبيق Claude ← قسم **Code**.
2. اختر مجلد لفيديوهاتك، مثلاً `فيديوهاتي`.
3. اسحب ملف `khaam-motion.zip` أو المجلد للمحادثة، واكتب: **«ثبّت المهارة»**.
4. Claude ينسخها لمكانها الصحيح، ويفحص جهازك، ويقول لك وش ناقص. **ما يثبّت شي إلا بإذنك.**

**الطريقة الثانية: تطبيق Claude (المحادثة العادية)**
1. شغّل **Code execution** من الإعدادات.
2. ارفع `khaam-motion.zip` من **Customize ← Skills**، وفعّلها.
3. هنا تقدر تخطط وتكتب السكربت وتختار الستايل. **الرندر على جهازك يحتاج الطريقة الأولى.**

## ٤. أول فيديو لك في ١٠ دقايق
انسخ هذا وغيّر الكلام اللي بين القوسين:
```
سوّ لي فيديو موشن ٨ ثواني، عمودي ٩:١٦.
النص: «[فكرتك في جملة وحدة]».
الستايل: [صف إحساسك وألوانك، أو أرسل صورة/فيديو يعجبك].
اقترح لي ٣ هوكات لأول ٣ ثواني، واعرض لي ٣ إطارات storyboard قبل الرندر.
```
ما عندك ستايل؟ قل: **«اقترح لي ٣ اتجاهات»** أو **«وريني الأمثلة»**.
تبي ريل شرح أو أدوات بنفس إخراج الحسابات الكبيرة؟ قل: **«سوّ ريل شرح عن [الفكرة] بنظام ريل الشرح»**.

## ٥. الصوت المعلّق بالذكاء الاصطناعي (اختياري، بس يفرق كثير)
الموشن مع صوت يتكلم ويتزامن مع كل كلمة يطلع بمستوى ثاني. المهارة تسويه بـ **ElevenLabs** وبنموذجهم **Eleven v4**: Claude يكتب النص، ويولّد الصوت، ويوقّت الحركة والكابشن على كل كلمة.

**تبيه؟ هذي الخطوات (مرة وحدة بس):**
1. سوّ حساب في **elevenlabs.io**.
2. **الخطة:** المجانية فيها 10 آلاف رصيد بالشهر للتجربة، بس **ما فيها رخصة تجارية**. لو بتنشر أو تبيع، Starter وفوق فيها الرخصة التجارية (شيّك السعر الحالي في صفحة الأسعار).
3. من حسابك افتح **API Keys** وسوّ مفتاح جديد. وإذا الموقع يسمح، حدّد صلاحياته وحدّ للرصيد.
4. أضفه بنفسك كمتغير بيئة اسمه `ELEVENLABS_API_KEY`:
   - Windows: ابحث عن «Edit environment variables for your account» ← New.
   - Mac: أضف السطر `export ELEVENLABS_API_KEY=...` في ملف `~/.zshrc`.
5. سكّر Claude وافتحه من جديد، وقل: «تأكد إن مفتاح ElevenLabs شغال».

**لا تلصق المفتاح في المحادثة أبداً.** Claude يتأكد إنه موجود بس، وما يشوف قيمته.
- تقدر تختار صوت من مكتبتهم، أو تستنسخ صوتك أنت (بموافقتك).
- Claude **يستأذنك قبل كل طلب مدفوع**، ويقول لك كم بيكلف من رصيدك.
- **ما تبي صوت؟** عادي. نكمل موشن مع مؤثرات صوتية مجانية.

## ٦. أضف أشياءك بأمان
**القاعدة:** أشياءك تكون في **مجلد مشروعك**، مو داخل مجلد المهارة. لو حدّثت المهارة بعدين، ما ينمسح شي من حقك.

| تبي تضيف | وين تحطه | وش تقول لـ Claude |
|---|---|---|
| شعارك | `assets/logo/` | «هذا شعاري، استعمله في نهاية كل فيديو» |
| خطك | `assets/fonts/` | «هذا خطي، أضفه للمشروع» |
| ألوانك وستايلك | `TASTE.md` في المشروع | «احفظ هذا الستايل باسم [الاسم]» |
| أصواتك ومؤثراتك | `assets/sfx/` | «هذي أصواتي، استعملها» |
| مفتاح ElevenLabs | متغير بيئة اسمه `ELEVENLABS_API_KEY` | «ساعدني أضبط مفتاح ElevenLabs» (**لا تلصق المفتاح في المحادثة**) |

## ٧. التكلفة
- **Claude:** اشتراكك الشهري.
- **المؤثرات الصوتية:** مجانية من Openverse.
- **الخطوط المجانية:** مجانية، ورخصتها تنزل معها.
- **ElevenLabs:** اختياري، وبحسابك أنت (شوف §٥).

## ٨. إذا علّقت
| المشكلة | الحل |
|---|---|
| Claude ما يشوف المهارة | قل له: «تأكد إن المهارة في ~/.claude/skills/khaam-motion». وإذا لزم اكتب `/reload-skills` |
| الحروف العربية مقطّعة | قل: «طبّق دليل الكتابة العربية في المهارة» |
| الرندر بطيء | قل: «سوّ معاينة صغيرة أول» |
| ناقص برنامج (Node أو FFmpeg) | قل: «ثبّت الناقص خطوة خطوة» |

---

## For Claude: first-run protocol
Follow this when the user says «ابدأ» / start / install, attaches this folder or its ZIP, or has no project yet. Speak simple Gulf Arabic (or the user's language), short messages, **one step at a time**, and wait for the user between steps. Never paste long technical output; summarize it.

1. **Detect the host.**
   - Shell and file access on the user's computer = Claude Code. Continue below.
   - Claude app chat (remote sandbox, no access to the user's drive) = explain §3 option 2 in two lines: here we can plan, write and choose a style; rendering on their machine needs the Code tab. Offer to continue planning.
2. **Recommend model and effort.** You cannot change them yourself. Tell the user to type `/model opus` and `/effort max` (Opus 5.5 at max; `max` lasts for the session, or set `CLAUDE_CODE_EFFORT_LEVEL=max` to keep it). Continue either way.
3. **Install the skill if needed.** If it is not already at `~/.claude/skills/khaam-motion/SKILL.md` (or the project's `.claude/skills/`), ask permission, then copy the folder there (extract the ZIP into a new empty folder first). If a different version already exists there, show both versions and ask before replacing; keep a backup. Tell the user it loads automatically; if not, `/reload-skills`.
4. **Inventory.** Run `python "<skill>/scripts/preflight.py"` (read-only). Explain the result in 3–5 short lines: what is ready, what is missing.
5. **Install only what is missing, one tool at a time, with permission each time.** Use the user's trusted package manager:
   - Windows: `winget install OpenJS.NodeJS.LTS`, `winget install Gyan.FFmpeg`, `winget install Python.Python.3.12`
   - macOS: `brew install node ffmpeg python`
   - Linux: the distribution's package manager.
   - Renderer: a shared toolkit folder `~/.cache/khaam-motion/toolkit` with `npm init -y` then `npm install playwright` and `npx playwright install chromium`. Record it as `toolkit_dir` in the project's `.khaam/config.json`.
   Re-run preflight after installs. Never install everything "just in case".
6. **Create the first project.** Ask for a short project name, create the folder layout from `reference/planning-and-tracking.md`, copy `templates/TASTE.md`, and create `PROGRESS.md`.
7. **Their style first.** Ask for references, brand colours, fonts or a mood and build their own style (save it in the project). Offer the examples in `styles/` only if they have no direction, framed as starting points.
8. **Offer AI narration (first run only, in full).** Explain §5 in a few short lines: narration with ElevenLabs Eleven v4 makes motion videos far stronger; it needs the user's own ElevenLabs account and an API key set as `ELEVENLABS_API_KEY` (free plan = testing only, no commercial licence; Starter and up include it); you always ask before each paid request; the alternative is motion + free sound effects. If they want it, walk them through §5 steps 1–5 and confirm only that the key is present (preflight `elevenlabs_key_present`), then use `reference/voiceover.md` and `scripts/gen_tts_elevenlabs.py`. If not, continue without voice. Record the choice in `~/.cache/khaam-motion/onboarding.json` (see `SKILL.md` §0) so later projects do not repeat the explanation.
9. **First video.** Run the normal workflow in `SKILL.md`, kept small: 6–10 s, 9:16. Use the fast path in `SKILL.md` §3: one plan message (3 hooks, script, style, narration yes/no), one storyboard sheet, then **one complete preview with motion + sound (+ narration)**, then the final MP4. No separate silent or sound-only rounds. For any Arabic text, `reference/arabic-typography.md` is mandatory.
10. **Close the onboarding** in the user's language (Arabic users get Arabic only, no English labels such as "Tip:") with three short tips: where their files live, how to add their own assets (§6 table), and how to ask for changes («غيّر اللون»، «أبطئ الحركة»، «بدّل الخط»).

Never ask for or display API keys in chat. For ElevenLabs, guide the user to add `ELEVENLABS_API_KEY` as a user environment variable themselves, outside the chat: on Windows search "Edit environment variables for your account" → New; on macOS/Linux add `export ELEVENLABS_API_KEY=...` to `~/.zshrc` or `~/.bashrc` in a text editor. Then restart Claude and confirm only that the variable is present (never print it).
