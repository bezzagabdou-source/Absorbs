-- REVIEW TEMPLATE ONLY. Do not apply until request identity is set transaction-locally
-- by trusted server middleware and the runtime DB role is least-privilege.
-- Example context (inside one server-side transaction, after signature verification):
-- SELECT set_config('app.user_id', '<verified UUID>', true);
-- SELECT set_config('app.role', '<verified role>', true);
-- NULLIF protects anonymous connections from invalid UUID casts.

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE offers ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE escrow_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE disputes ENABLE ROW LEVEL SECURITY;
ALTER TABLE push_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY users_read_self_or_staff ON users
  FOR SELECT USING (
    id = NULLIF(current_setting('app.user_id', true), '')::uuid
    OR current_setting('app.role', true) IN ('admin', 'support')
  );
CREATE POLICY users_update_self ON users
  FOR UPDATE USING (id = NULLIF(current_setting('app.user_id', true), '')::uuid)
  WITH CHECK (id = NULLIF(current_setting('app.user_id', true), '')::uuid);

CREATE POLICY products_public_active_or_owner ON products
  FOR SELECT USING (
    status = 'active'
    OR seller_id = NULLIF(current_setting('app.user_id', true), '')::uuid
    OR current_setting('app.role', true) IN ('admin', 'support')
  );
CREATE POLICY products_owner_insert ON products
  FOR INSERT WITH CHECK (seller_id = NULLIF(current_setting('app.user_id', true), '')::uuid);
CREATE POLICY products_owner_update ON products
  FOR UPDATE USING (seller_id = NULLIF(current_setting('app.user_id', true), '')::uuid)
  WITH CHECK (seller_id = NULLIF(current_setting('app.user_id', true), '')::uuid);

CREATE POLICY offers_participant_read ON offers
  FOR SELECT USING (
    buyer_id = NULLIF(current_setting('app.user_id', true), '')::uuid
    OR seller_id = NULLIF(current_setting('app.user_id', true), '')::uuid
    OR current_setting('app.role', true) IN ('admin', 'support')
  );
CREATE POLICY offers_buyer_insert ON offers
  FOR INSERT WITH CHECK (buyer_id = NULLIF(current_setting('app.user_id', true), '')::uuid);

CREATE POLICY conversations_participant_access ON conversations
  FOR ALL USING (
    buyer_id = NULLIF(current_setting('app.user_id', true), '')::uuid
    OR seller_id = NULLIF(current_setting('app.user_id', true), '')::uuid
  ) WITH CHECK (
    buyer_id = NULLIF(current_setting('app.user_id', true), '')::uuid
    OR seller_id = NULLIF(current_setting('app.user_id', true), '')::uuid
  );
CREATE POLICY messages_participant_read ON messages
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM conversations c WHERE c.id = conversation_id
      AND (c.buyer_id = NULLIF(current_setting('app.user_id', true), '')::uuid
        OR c.seller_id = NULLIF(current_setting('app.user_id', true), '')::uuid)
  ));
CREATE POLICY messages_sender_insert ON messages
  FOR INSERT WITH CHECK (
    sender_id = NULLIF(current_setting('app.user_id', true), '')::uuid
    AND EXISTS (
      SELECT 1 FROM conversations c WHERE c.id = conversation_id
        AND (c.buyer_id = NULLIF(current_setting('app.user_id', true), '')::uuid
          OR c.seller_id = NULLIF(current_setting('app.user_id', true), '')::uuid)
    )
  );

CREATE POLICY escrow_participant_read ON escrow_transactions
  FOR SELECT USING (
    buyer_id = NULLIF(current_setting('app.user_id', true), '')::uuid
    OR seller_id = NULLIF(current_setting('app.user_id', true), '')::uuid
    OR current_setting('app.role', true) IN ('admin', 'support')
  );
CREATE POLICY dispute_participant_read ON disputes
  FOR SELECT USING (
    opened_by = NULLIF(current_setting('app.user_id', true), '')::uuid
    OR EXISTS (
      SELECT 1 FROM escrow_transactions e WHERE e.id = escrow_id
        AND (e.buyer_id = NULLIF(current_setting('app.user_id', true), '')::uuid
          OR e.seller_id = NULLIF(current_setting('app.user_id', true), '')::uuid)
    )
    OR current_setting('app.role', true) IN ('admin', 'support')
  );
CREATE POLICY push_owner_access ON push_subscriptions
  FOR ALL USING (user_id = NULLIF(current_setting('app.user_id', true), '')::uuid)
  WITH CHECK (user_id = NULLIF(current_setting('app.user_id', true), '')::uuid);

-- Add separate public-profile projections before granting public SELECT on users.
-- The application currently selects only displayName from the joined users table.
-- Validate policy behavior with SET ROLE and adversarial cross-account tests.
