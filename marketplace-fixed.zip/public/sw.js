/* DZ Exchange service worker: offline public pages, safe push and queued background sync. */
const CACHE_NAME = "dz-exchange-v1";
const PRECACHE_URLS = ["/", "/explore", "/offline", "/manifest.webmanifest"];
const PUBLIC_NAVIGATION = ["/", "/explore", "/offline"];
const DATABASE_NAME = "dz-exchange-offline";
const OUTBOX_STORE = "outbox";
self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await Promise.allSettled(PRECACHE_URLS.map(async (path) => { const response = await fetch(path, { credentials: "same-origin" }); if (response.ok) await cache.put(path, response); }));
    await self.skipWaiting();
  })());
});
self.addEventListener("activate", (event) => {
  event.waitUntil((async () => { const names = await caches.keys(); await Promise.all(names.filter((name) => name.startsWith("dz-exchange-") && name !== CACHE_NAME).map((name) => caches.delete(name))); await self.clients.claim(); })());
});
self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin || url.pathname.startsWith("/api/")) return;
  const isDocument = request.mode === "navigate";
  const isPublicPage = PUBLIC_NAVIGATION.some((path) => url.pathname === path || (path !== "/" && url.pathname.startsWith(`${path}/`)));
  if (isDocument) {
    event.respondWith((async () => {
      try { const response = await fetch(request); if (response.ok && isPublicPage) { const cache = await caches.open(CACHE_NAME); await cache.put(request, response.clone()); } return response; }
      catch { return await caches.match(request) ?? await caches.match("/offline") ?? Response.error(); }
    })());
    return;
  }
  if (["style", "script", "font", "image"].includes(request.destination)) {
    event.respondWith((async () => { const cache = await caches.open(CACHE_NAME); const cached = await cache.match(request); const network = fetch(request).then((response) => { if (response.ok) void cache.put(request, response.clone()); return response; }).catch(() => cached ?? Response.error()); return cached ?? network; })());
  }
});
self.addEventListener("push", (event) => {
  event.waitUntil((async () => {
    let payload = {};
    try { payload = event.data?.json() ?? {}; } catch { payload = { body: event.data?.text() ?? "Vous avez une nouvelle notification." }; }
    await self.registration.showNotification(payload.title ?? "DZ Exchange", { body: payload.body ?? "Une nouvelle activité sur votre marché local.", icon: "/icons/icon.svg", badge: "/icons/icon.svg", tag: "dz-exchange-update", data: { url: payload.url ?? "/chat" } });
  })());
});
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const target = new URL(event.notification.data?.url ?? "/", self.location.origin);
  const safeTarget = target.origin === self.location.origin ? `${target.pathname}${target.search}${target.hash}` : "/";
  event.waitUntil((async () => { const windows = await self.clients.matchAll({ type: "window", includeUncontrolled: true }); for (const client of windows) { if (new URL(client.url).origin === self.location.origin) { await client.navigate(safeTarget); await client.focus(); return; } } await self.clients.openWindow(safeTarget); })());
});
self.addEventListener("sync", (event) => {
  if (event.tag !== "dz-exchange-outbox") return;
  event.waitUntil((async () => {
    const opening = indexedDB.open(DATABASE_NAME, 2);
    opening.onupgradeneeded = () => { if (!opening.result.objectStoreNames.contains("listings")) { const listings = opening.result.createObjectStore("listings", { keyPath: "id" }); listings.createIndex("updatedAt", "updatedAt"); } if (!opening.result.objectStoreNames.contains(OUTBOX_STORE)) opening.result.createObjectStore(OUTBOX_STORE, { keyPath: "id" }); };
    const database = await new Promise((resolve, reject) => { opening.onsuccess = () => resolve(opening.result); opening.onerror = () => reject(opening.error); });
    const entries = await new Promise((resolve, reject) => { const request = database.transaction(OUTBOX_STORE, "readonly").objectStore(OUTBOX_STORE).getAll(); request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error); });
    for (const entry of entries) { try { const response = await fetch(entry.url, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: entry.body }); if (response.ok || [400, 401, 403].includes(response.status)) await new Promise((resolve, reject) => { const transaction = database.transaction(OUTBOX_STORE, "readwrite"); transaction.objectStore(OUTBOX_STORE).delete(entry.id); transaction.oncomplete = resolve; transaction.onerror = () => reject(transaction.error); }); } catch { /* Keep until the next sync. */ } }
    database.close();
  })());
});
