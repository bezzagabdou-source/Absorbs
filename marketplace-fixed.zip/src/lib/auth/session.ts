import { createHmac, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";

export type SessionClaims = {
  sub: string;
  role: "buyer" | "seller" | "admin" | "support";
  exp: number;
  iat: number;
};

const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const sessionRoles = new Set<SessionClaims["role"]>(["buyer", "seller", "admin", "support"]);

/** Verifies the compact HMAC session cookie issued by the configured identity adapter. */
export async function getSession(): Promise<SessionClaims | null> {
  const secret = process.env.DZ_SESSION_SECRET;
  if (!secret || Buffer.byteLength(secret) < 32) return null;
  const cookieStore = await cookies();
  const token = cookieStore.get("dz_session")?.value;
  if (!token) return null;
  const [encodedPayload, signature, ...extra] = token.split(".");
  if (!encodedPayload || !signature || extra.length) return null;
  const expected = createHmac("sha256", secret).update(encodedPayload).digest("base64url");
  const expectedBuffer = Buffer.from(expected);
  const suppliedBuffer = Buffer.from(signature);
  if (expectedBuffer.length !== suppliedBuffer.length || !timingSafeEqual(expectedBuffer, suppliedBuffer)) return null;
  try {
    const claims = JSON.parse(Buffer.from(encodedPayload, "base64url").toString("utf8")) as Partial<SessionClaims>;
    if (typeof claims.sub !== "string" || !uuidPattern.test(claims.sub)) return null;
    if (typeof claims.exp !== "number" || claims.exp <= Math.floor(Date.now() / 1000)) return null;
    if (typeof claims.iat !== "number" || typeof claims.role !== "string" || !sessionRoles.has(claims.role as SessionClaims["role"])) return null;
    return claims as SessionClaims;
  } catch {
    return null;
  }
}

export function hasSameOrigin(request: Request, expectedOrigin: string) {
  const origin = request.headers.get("origin");
  if (!origin) return false;
  try { return new URL(origin).origin === expectedOrigin; } catch { return false; }
}

export async function requireSession() {
  const session = await getSession();
  if (!session) return { session: null, response: Response.json({ error: "Authentication required" }, { status: 401 }) };
  return { session, response: null };
}
