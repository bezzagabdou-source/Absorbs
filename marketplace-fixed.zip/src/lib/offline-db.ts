import Dexie, { type Table } from "dexie";
import type { MarketProduct } from "@/lib/marketplace-data";

type CachedListing = { id: string; updatedAt: number; data: MarketProduct };

class DzOfflineDatabase extends Dexie {
  listings!: Table<CachedListing, string>;
  outbox!: Table<{ id: string; url: string; body: string }, string>;

  constructor() {
    super("dz-exchange-offline");
    this.version(2).stores({ listings: "id, updatedAt", outbox: "id" });
  }
}

export const offlineDatabase = new DzOfflineDatabase();

export async function cacheListings(items: MarketProduct[]) {
  if (!items.length) return;
  const updatedAt = Date.now();
  await offlineDatabase.listings.bulkPut(items.map((data) => ({ id: data.id, data, updatedAt })));
}

export async function getCachedListings() {
  const rows = await offlineDatabase.listings.orderBy("updatedAt").reverse().limit(80).toArray();
  return rows.map((row) => row.data);
}

export async function clearOfflineDatabase() {
  await offlineDatabase.delete();
}
