import type { MarketProduct } from "@/lib/marketplace-data";

type AlgoliaHit = {
  objectID?: string;
  id?: string;
  title?: string;
  description?: string;
  category?: string;
  price?: number | string;
  priceDzd?: number | string;
  condition?: string;
  wilaya?: string;
  commune?: string;
  images?: unknown;
  image?: string;
  sellerName?: string;
  sellerInitials?: string;
  sellerVerified?: boolean;
  trustTier?: number;
  rating?: number;
  delivery?: boolean;
  escrow?: boolean;
  posted?: string;
  badge?: string;
};

const conditionLabels: Record<string, MarketProduct["condition"]> = { new: "Neuf", like_new: "Comme neuf", good: "Bon état", fair: "Bon état", for_parts: "Bon état" };
const safeString = (value: unknown, fallback: string) => typeof value === "string" ? value.slice(0, 2000) : fallback;
const safeImage = (value: unknown): string | null => {
  if (typeof value !== "string") return null;
  try { return new URL(value).protocol === "https:" ? value.slice(0, 2048) : null; } catch { return null; }
};

function normalizeArabicQuery(query: string) {
  return query.normalize("NFKC").replace(/[\u064B-\u065F\u0670]/g, "").replace(/[أإآ]/g, "ا").replace(/ى/g, "ي").trim().slice(0, 100);
}

/** Uses only a restricted Algolia search key; never accepts index/URL input from the browser. */
export async function searchAlgolia(query: string): Promise<MarketProduct[] | null> {
  const appId = process.env.ALGOLIA_APP_ID;
  const searchKey = process.env.ALGOLIA_SEARCH_API_KEY;
  const index = process.env.ALGOLIA_PRODUCTS_INDEX;
  if (!appId || !searchKey || !index || !query.trim()) return null;
  try {
    const response = await fetch(`https://${encodeURIComponent(appId)}-dsn.algolia.net/1/indexes/${encodeURIComponent(index)}/query`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Algolia-Application-Id": appId, "X-Algolia-API-Key": searchKey },
      body: JSON.stringify({ query: normalizeArabicQuery(query), hitsPerPage: 80, filters: "status:active", attributesToRetrieve: ["objectID", "id", "title", "description", "category", "price", "priceDzd", "condition", "wilaya", "commune", "images", "image", "sellerName", "sellerInitials", "sellerVerified", "trustTier", "rating", "delivery", "escrow", "posted", "badge"], attributesToHighlight: [], typoTolerance: true }),
      cache: "no-store",
      signal: AbortSignal.timeout(2500),
    });
    if (!response.ok) return null;
    const result = await response.json() as { hits?: AlgoliaHit[] };
    return (result.hits ?? []).flatMap((hit) => {
      const imageList = Array.isArray(hit.images) ? hit.images.map(safeImage).filter((image): image is string => Boolean(image)) : [];
      const image = safeImage(hit.image) ?? imageList[0];
      const id = safeString(hit.objectID ?? hit.id, "");
      const title = safeString(hit.title, "");
      const price = Number(hit.priceDzd ?? hit.price);
      if (!id || !title || !Number.isFinite(price) || price < 0 || !image) return [];
      const condition = hit.condition ?? "good";
      const tier = Math.min(3, Math.max(1, Number(hit.trustTier) || 1)) as 1 | 2 | 3;
      return [{
        id, title, description: safeString(hit.description, ""), category: safeString(hit.category, "Autres"), price,
        condition: conditionLabels[condition] ?? "Bon état", wilaya: safeString(hit.wilaya, "Algérie"), commune: safeString(hit.commune, "Algérie"),
        image, images: imageList.length ? imageList : [image], sellerName: safeString(hit.sellerName, "Vendeur"),
        sellerInitials: safeString(hit.sellerInitials, "V").slice(0, 2), sellerVerified: hit.sellerVerified === true || tier > 1,
        trustTier: tier, rating: Number.isFinite(Number(hit.rating)) ? Number(hit.rating) : 4.8,
        delivery: hit.delivery === true, escrow: hit.escrow === true, posted: safeString(hit.posted, "Récemment"),
        ...(hit.badge ? { badge: safeString(hit.badge, "") } : {}),
      } satisfies MarketProduct];
    });
  } catch {
    return null;
  }
}
