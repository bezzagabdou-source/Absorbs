import { eq } from "drizzle-orm";
import { db } from "@/db";
import { categories, products, users, wilayas } from "@/db/schema";
import type { MarketProduct } from "@/lib/marketplace-data";

const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const conditionLabels: Record<string, MarketProduct["condition"]> = { new: "Neuf", like_new: "Comme neuf", good: "Bon état", fair: "Bon état", for_parts: "Bon état" };

export async function getDatabaseProduct(id: string): Promise<MarketProduct | null> {
  if (!uuidPattern.test(id)) return null;
  try {
    const [row] = await db.select({
      id: products.id, title: products.title, description: products.description, category: categories.nameFr,
      priceDzd: products.priceDzd, condition: products.condition, commune: products.commune, images: products.images,
      escrow: products.escrowEligible, delivery: products.deliveryAvailable, createdAt: products.createdAt,
      wilaya: wilayas.nameFr, sellerName: users.displayName, trustTier: users.trustTier,
    }).from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .leftJoin(wilayas, eq(products.wilayaId, wilayas.id))
      .leftJoin(users, eq(products.sellerId, users.id))
      .where(eq(products.id, id)).limit(1);
    if (!row || !row.images.length) return null;
    const tier = row.trustTier === "tier_3" ? 3 : row.trustTier === "tier_2" ? 2 : 1;
    return {
      id: row.id, title: row.title, description: row.description, category: row.category ?? "Autres",
      price: Number(row.priceDzd), condition: conditionLabels[row.condition] ?? "Bon état",
      wilaya: row.wilaya ?? "Algérie", commune: row.commune ?? "Algérie", image: row.images[0], images: row.images,
      sellerName: row.sellerName ?? "Vendeur", sellerInitials: (row.sellerName ?? "V").slice(0, 2).toUpperCase(),
      sellerVerified: tier > 1, trustTier: tier, rating: 4.8, delivery: row.delivery, escrow: row.escrow,
      posted: `le ${row.createdAt.toLocaleDateString("fr-DZ")}`,
    };
  } catch {
    return null;
  }
}
