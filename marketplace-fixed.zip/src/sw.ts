/* Source for public/sw.js. Keep the deployed worker in sync with this module. */
const CACHE_NAME = "dz-exchange-v1";
const PRECACHE_URLS = ["/", "/explore", "/offline", "/manifest.webmanifest"];
const PUBLIC_NAVIGATION = ["/", "/explore", "/offline"];
const DATABASE_NAME = "dz-exchange-offline";
const OUTBOX_STORE = "outbox";

type WorkerEvent = {
  waitUntil: (promise: Promise<unknown>) => void;
  request?: Request;
  respondWith?: (response: Promise<Response> | Response) => void;
  data?: { json: () => unknown; text: () => string };
  notification?: Notification;
  tag?: string;
};
type WorkerScope = {
  addEventListener: (type: string, listener: (event: WorkerEvent) => void) => void;
  skipWaiting: () => Promise<void>;
  clients: { claim: () => Promise<void>; matchAll: (options?: { type?: string; includeUncontrolled?: boolean }) => Promise<Array<{ url: string; focus: () => Promise<unknown>; navigate: (url: string) => Promise<unknown> }>>; openWindow: (url: string) => Promise<unknown> };
  registration: ServiceWorkerRegistration;
  location: Location;
};
const worker = globalThis as unknown as WorkerScope;

worker.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await Promise.allSettled(PRECACHE_URLS.map(async (path) => {
      const response = await fetch(path, { credentials: "same-origin" });
      if (response.ok) await cache.put(path, response);
    }));
    await worker.skipWaiting();
  })());
});

worker.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter((name) => name.startsWith("dz-exchange-") && name !== CACHE_NAME).map((name) => caches.delete(name)));
    await worker.clients.claim();
  })());
});

worker.addEventListener("fetch", (event) => {
  const request = event.request;
  if (!request || request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== worker.location.origin || url.pathname.startsWith("/api/")) return;
  const isDocument = request.mode === "navigate";
  const isPublicPage = PUBLIC_NAVIGATION.some((path) => url.pathname === path || (path !== "/" && url.pathname.startsWith(`${path}/`)));
  if (isDocument) {
    event.respondWith!((async () => {
      try {
        const response = await fetch(request);
        if (response.ok && isPublicPage) {
          const cache = await caches.open(CACHE_NAME);
          await cache.put(request, response.clone());
        }
        return response;
      } catch {
        const cached = await caches.match(request);
        return cached ?? await caches.match("/offline") ?? Response.error();
      }
    })());
    return;
  }
  if (["style", "script", "font", "image"].includes(request.destination)) {
    event.respondWith!((async () => {
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(request);
      const network = fetch(request).then((response) => {
        if (response.ok) void cache.put(request, response.clone());
        return response;
      }).catch(() => cached ?? Response.error());
      return cached ?? network;
    })());
  }
});

worker.addEventListener("push", (event) => {
  event.waitUntil((async () => {
    let payload: { title?: string; body?: string; url?: string } = {};
    try { payload = event.data?.json() as typeof payload; } catch { payload = { body: event.data?.text() ?? "Vous avez une nouvelle notification." }; }
    await worker.registration.showNotification(payload.title ?? "DZ Exchange", {
      body: payload.body ?? "Une nouvelle activité sur votre marché local.",
      icon: "/icons/icon.svg", badge: "/icons/icon.svg", tag: "dz-exchange-update", data: { url: payload.url ?? "/chat" },
    });
  })());
});

worker.addEventListener("notificationclick", (event) => {
  event.notification?.close();
  const target = new URL(String((event.notification as Notification & { data?: { url?: string } } | undefined)?.data?.url ?? "/"), worker.location.origin);
  const safeTarget = target.origin === worker.location.origin ? `${target.pathname}${target.search}${target.hash}` : "/";
  event.waitUntil((async () => {
    const windows = await worker.clients.matchAll({ type: "window", includeUncontrolled: true });
    for (const client of windows) {
      if (new URL(client.url).origin === worker.location.origin) { await client.navigate(safeTarget); await client.focus(); return; }
    }
    await worker.clients.openWindow(safeTarget);
  })());
});

worker.addEventListener("sync", (event) => {
  if (event.tag !== "dz-exchange-outbox") return;
  event.waitUntil((async () => {
    const openDatabase = indexedDB.open(DATABASE_NAME, 2);
    openDatabase.onupgradeneeded = () => {
      if (!openDatabase.result.objectStoreNames.contains("listings")) { const listings = openDatabase.result.createObjectStore("listings", { keyPath: "id" }); listings.createIndex("updatedAt", "updatedAt"); }
      if (!openDatabase.result.objectStoreNames.contains(OUTBOX_STORE)) openDatabase.result.createObjectStore(OUTBOX_STORE, { keyPath: "id" });
    };
    const database = await new Promise<IDBDatabase>((resolve, reject) => { openDatabase.onsuccess = () => resolve(openDatabase.result); openDatabase.onerror = () => reject(openDatabase.error); });
    const entries = await new Promise<Array<{ id: string; url: string; body: string }>>((resolve, reject) => { const request = database.transaction(OUTBOX_STORE, "readonly").objectStore(OUTBOX_STORE).getAll(); request.onsuccess = () => resolve(request.result as Array<{ id: string; url: string; body: string }>); request.onerror = () => reject(request.error); });
    for (const entry of entries) {
      try {
        const response = await fetch(entry.url, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: entry.body });
        if (response.ok || response.status === 400 || response.status === 401 || response.status === 403) await new Promise<void>((resolve, reject) => { const transaction = database.transaction(OUTBOX_STORE, "readwrite"); transaction.objectStore(OUTBOX_STORE).delete(entry.id); transaction.oncomplete = () => resolve(); transaction.onerror = () => reject(transaction.error); });
      } catch { /* Preserve the item for the next sync attempt. */ }
    }
    database.close();
  })());
});
