import { HomeMarketplace } from "@/components/marketplace/HomeMarketplace";

export default function HomePage() {
  return <HomeMarketplace />;
}
