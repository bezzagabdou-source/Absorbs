import { SettingsPage } from "@/components/marketplace/SettingsPage";
export const metadata = { title: "Paramètres" };
const allowedSections = ["general", "security", "preferences", "notifications", "payments"] as const;
type SettingsSection = typeof allowedSections[number];
type SearchParams = Promise<Record<string, string | string[] | undefined>>;
export default async function SettingsRoute({ searchParams }: { searchParams: SearchParams }) {
  const params = await searchParams;
  const value = Array.isArray(params.section) ? params.section[0] : params.section;
  const initialSection: SettingsSection = allowedSections.includes(value as SettingsSection) ? value as SettingsSection : "general";
  return <SettingsPage initialSection={initialSection} />;
}
