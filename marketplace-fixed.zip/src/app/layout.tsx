import type { Metadata } from "next";
import type { ReactNode } from "react";
import { MarketplaceShell } from "@/components/marketplace/MarketplaceShell";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "DZ Exchange — Le marché d'ici, en mieux", template: "%s · DZ Exchange" },
  description: "Achetez et vendez avec confiance, partout en Algérie. Des rencontres locales, des vendeurs vérifiés et une marketplace pensée pour ici.",
  applicationName: "DZ Exchange",
  appleWebApp: { capable: true, statusBarStyle: "default", title: "DZ Exchange" },
  formatDetection: { telephone: false },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="fr" suppressHydrationWarning><body><MarketplaceShell>{children}</MarketplaceShell></body></html>;
}
