import { notFound } from "next/navigation";
import { ProductDetails } from "@/components/marketplace/ProductDetails";
import { sampleProducts } from "@/lib/marketplace-data";
import { getDatabaseProduct } from "@/lib/marketplace-db";

export const dynamic = "force-dynamic";

type ProductPageProps = { params: Promise<{ id: string }> };

export default async function ProductPage({ params }: ProductPageProps) {
  const { id } = await params;
  const databaseProduct = await getDatabaseProduct(id);
  const product = databaseProduct ?? sampleProducts.find((item) => item.id === id);
  if (!product) notFound();
  return <ProductDetails product={product} />;
}
