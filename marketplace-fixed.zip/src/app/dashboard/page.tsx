import { DashboardPage } from "@/components/marketplace/DashboardPage";
export const metadata = { title: "Espace vendeur" };
export default function DashboardRoute() { return <DashboardPage />; }
