import { ChatWorkspace } from "@/components/marketplace/ChatWorkspace";
export const metadata = { title: "Messagerie" };
export default function ChatPage() { return <ChatWorkspace />; }
