import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "DZ Exchange · Le marché d'ici, en mieux",
    short_name: "DZ Exchange",
    description: "Le marché local pensé pour l'Algérie.",
    start_url: "/",
    display: "standalone",
    background_color: "#f6f7f3",
    theme_color: "#f6f7f3",
    orientation: "portrait-primary",
    icons: [{ src: "/icons/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "maskable" }],
    categories: ["shopping", "lifestyle"],
    lang: "fr-DZ",
  };
}
