/* eslint react/no-unescaped-entities: off -- Literal French apostrophes are safe JSX text. */
import Link from "next/link";
import { Icon } from "@/components/marketplace/Icon";
export default function OfflinePage() { return <main className="offline-page market-container"><span><Icon name="wifi" size={28} /></span><p className="section-kicker">MODE HORS CONNEXION</p><h1>On n'a pas perdu le fil.</h1><p>Reconnectez-vous pour découvrir les dernières annonces. Les pages consultées récemment peuvent rester disponibles sur cet appareil.</p><Link href="/" className="button-dark">Réessayer <Icon name="refresh" size={16} /></Link></main>; }
