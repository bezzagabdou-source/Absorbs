import { and, desc, eq, ilike, lte, or } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { categories, products, users, wilayas } from "@/db/schema";
import { searchAlgolia } from "@/lib/search/algolia";

const conditionLabels: Record<string, "Neuf" | "Comme neuf" | "Très bon état" | "Bon état"> = {
  new: "Neuf", like_new: "Comme neuf", good: "Bon état", fair: "Bon état", for_parts: "Bon état",
};

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const params = request.nextUrl.searchParams;
  const predicates = [eq(products.status, "active")];
  const query = params.get("q")?.trim().slice(0, 100);
  const wilaya = params.get("wilaya")?.trim().slice(0, 80);
  if (query) {
    const algoliaItems = await searchAlgolia(query);
    if (algoliaItems) return NextResponse.json({ items: algoliaItems, count: algoliaItems.length, source: "algolia" });
  }
  const maxPrice = Number(params.get("maxPrice"));
  if (query) {
    const search = or(ilike(products.title, `%${query}%`), ilike(products.description, `%${query}%`));
    if (search) predicates.push(search);
  }
  if (wilaya && wilaya !== "Toutes les wilayas") predicates.push(ilike(wilayas.nameFr, wilaya));
  if (params.get("escrow") === "true") predicates.push(eq(products.escrowEligible, true));
  if (params.get("delivery") === "true") predicates.push(eq(products.deliveryAvailable, true));
  if (Number.isFinite(maxPrice) && maxPrice > 0) predicates.push(lte(products.priceDzd, String(maxPrice)));
  try {
    const rows = await db.select({
      id: products.id, title: products.title, description: products.description, category: categories.nameFr,
      priceDzd: products.priceDzd, condition: products.condition, commune: products.commune, images: products.images,
      escrow: products.escrowEligible, delivery: products.deliveryAvailable, postedAt: products.createdAt,
      wilaya: wilayas.nameFr, sellerName: users.displayName, trustTier: users.trustTier, sellerId: users.id,
    }).from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .leftJoin(wilayas, eq(products.wilayaId, wilayas.id))
      .leftJoin(users, eq(products.sellerId, users.id))
      .where(and(...predicates)).orderBy(desc(products.createdAt)).limit(80);
    const items = rows.map((row) => {
      const images = Array.isArray(row.images) ? row.images : [];
      const tier = row.trustTier === "tier_3" ? 3 : row.trustTier === "tier_2" ? 2 : 1;
      return {
        id: row.id, title: row.title, description: row.description, category: row.category ?? "Autres",
        price: Number(row.priceDzd), condition: conditionLabels[row.condition] ?? "Bon état",
        wilaya: row.wilaya ?? "Algérie", commune: row.commune ?? "Algérie", image: images[0] ?? "",
        images, sellerName: row.sellerName ?? "Vendeur", sellerInitials: (row.sellerName ?? "V").slice(0, 2).toUpperCase(),
        sellerVerified: tier > 1, trustTier: tier, rating: 4.8, delivery: row.delivery, escrow: row.escrow,
        posted: row.postedAt.toLocaleDateString("fr-DZ"),
      };
    });
    return NextResponse.json({ items, count: items.length, source: "drizzle" });
  } catch {
    return NextResponse.json({ error: "Marketplace data is temporarily unavailable" }, { status: 503 });
  }
}
