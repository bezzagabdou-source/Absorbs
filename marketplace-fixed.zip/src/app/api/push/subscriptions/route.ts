import { and, eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { pushSubscriptions } from "@/db/schema";
import { hasSameOrigin, requireSession } from "@/lib/auth/session";

export async function POST(request: NextRequest) {
  if (!hasSameOrigin(request, request.nextUrl.origin)) return NextResponse.json({ error: "Same-origin request required" }, { status: 403 });
  const { session, response } = await requireSession();
  if (!session) return response;
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Invalid subscription" }, { status: 400 }); }
  if (!body || typeof body !== "object") return NextResponse.json({ error: "Invalid subscription" }, { status: 400 });
  const subscription = body as { endpoint?: unknown; keys?: { p256dh?: unknown; auth?: unknown } };
  if (typeof subscription.endpoint !== "string" || !subscription.endpoint.startsWith("https://") || subscription.endpoint.length > 2048 || typeof subscription.keys?.p256dh !== "string" || subscription.keys.p256dh.length > 256 || typeof subscription.keys.auth !== "string" || subscription.keys.auth.length > 128) {
    return NextResponse.json({ error: "Invalid push subscription" }, { status: 400 });
  }
  try {
    await db.insert(pushSubscriptions).values({ userId: session.sub, endpoint: subscription.endpoint, keys: { p256dh: subscription.keys.p256dh, auth: subscription.keys.auth }, userAgent: request.headers.get("user-agent")?.slice(0, 500) ?? null }).onConflictDoNothing({ target: pushSubscriptions.endpoint });
    const [ownedSubscription] = await db.select({ id: pushSubscriptions.id }).from(pushSubscriptions).where(and(eq(pushSubscriptions.endpoint, subscription.endpoint), eq(pushSubscriptions.userId, session.sub))).limit(1);
    if (!ownedSubscription) return NextResponse.json({ error: "Subscription is already registered to another account" }, { status: 409 });
    return NextResponse.json({ ok: true }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not save subscription" }, { status: 503 });
  }
}

export async function DELETE(request: NextRequest) {
  if (!hasSameOrigin(request, request.nextUrl.origin)) return NextResponse.json({ error: "Same-origin request required" }, { status: 403 });
  const { session, response } = await requireSession();
  if (!session) return response;
  const endpoint = request.nextUrl.searchParams.get("endpoint");
  if (!endpoint) return NextResponse.json({ error: "Endpoint is required" }, { status: 400 });
  try {
    await db.delete(pushSubscriptions).where(and(eq(pushSubscriptions.endpoint, endpoint), eq(pushSubscriptions.userId, session.sub)));
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Could not remove subscription" }, { status: 503 });
  }
}
