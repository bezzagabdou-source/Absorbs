import { and, eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { offers, products, users } from "@/db/schema";
import { hasSameOrigin, requireSession } from "@/lib/auth/session";

const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export async function POST(request: NextRequest) {
  if (!hasSameOrigin(request, request.nextUrl.origin)) return NextResponse.json({ error: "Same-origin request required" }, { status: 403 });
  const { session, response } = await requireSession();
  if (!session) return response;
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Invalid request body" }, { status: 400 }); }
  if (!body || typeof body !== "object") return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const payload = body as { productId?: unknown; amountDzd?: unknown; message?: unknown };
  const amount = Number(payload.amountDzd);
  if (typeof payload.productId !== "string" || !uuidPattern.test(payload.productId)) return NextResponse.json({ error: "A valid product is required" }, { status: 400 });
  if (!Number.isFinite(amount) || amount < 1 || amount > 99_999_999_999) return NextResponse.json({ error: "Enter a valid offer amount in DZD" }, { status: 400 });
  const message = typeof payload.message === "string" ? payload.message.trim().slice(0, 300) : "";
  try {
    const [buyer] = await db.select({ id: users.id, active: users.isActive }).from(users).where(eq(users.id, session.sub)).limit(1);
    if (!buyer?.active) return NextResponse.json({ error: "Account is unavailable" }, { status: 403 });
    const [product] = await db.select({ id: products.id, sellerId: products.sellerId, status: products.status }).from(products).where(eq(products.id, payload.productId)).limit(1);
    if (!product || product.status !== "active") return NextResponse.json({ error: "Listing is no longer available" }, { status: 404 });
    if (product.sellerId === session.sub) return NextResponse.json({ error: "You cannot make an offer on your own listing" }, { status: 400 });
    const [created] = await db.insert(offers).values({ productId: product.id, buyerId: session.sub, sellerId: product.sellerId, amountDzd: amount.toFixed(2), message: message || null }).returning({ id: offers.id, createdAt: offers.createdAt });
    return NextResponse.json({ id: created.id, createdAt: created.createdAt }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not create offer" }, { status: 503 });
  }
}
