import { ExploreClient } from "@/components/marketplace/ExploreClient";

export const metadata = { title: "Explorer le marché" };

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export default async function ExplorePage({ searchParams }: { searchParams: SearchParams }) {
  const params = await searchParams;
  const one = (value: string | string[] | undefined) => Array.isArray(value) ? value[0] ?? "" : value ?? "";
  const rawCategory = one(params.category);
  const categoryNames: Record<string, string> = { vehicles: "Véhicules", electronics: "Électronique", "real-estate": "Immobilier", home: "Maison" };
  const category = categoryNames[rawCategory] ?? (rawCategory && rawCategory !== "Toutes les catégories" ? rawCategory : "Toutes les catégories");
  const initialQuery = one(params.q);
  const initialWilaya = one(params.wilaya) || "Toutes les wilayas";
  const favoritesOnly = one(params.filter) === "favorites";
  return <ExploreClient key={`${initialQuery}|${initialWilaya}|${category}|${favoritesOnly}`} initialQuery={initialQuery} initialWilaya={initialWilaya} initialCategory={category} favoritesOnly={favoritesOnly} />;
}
