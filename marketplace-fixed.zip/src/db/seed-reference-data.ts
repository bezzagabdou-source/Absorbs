import { db, pool } from "@/db";
import { categories, wilayas as wilayaTable } from "@/db/schema";
import { wilayas } from "@/lib/wilayas";

const categoryRows = [
  { slug: "electronics", nameEn: "Electronics", nameFr: "Électronique", nameAr: "إلكترونيات", icon: "devices", sortOrder: 1 },
  { slug: "vehicles", nameEn: "Vehicles", nameFr: "Véhicules", nameAr: "مركبات", icon: "car", sortOrder: 2 },
  { slug: "home-garden", nameEn: "Home & garden", nameFr: "Maison & jardin", nameAr: "المنزل والحديقة", icon: "home", sortOrder: 3 },
  { slug: "real-estate", nameEn: "Real estate", nameFr: "Immobilier", nameAr: "عقارات", icon: "building", sortOrder: 4 },
  { slug: "fashion", nameEn: "Fashion", nameFr: "Mode", nameAr: "أزياء", icon: "shirt", sortOrder: 5 },
  { slug: "sports-leisure", nameEn: "Sports & leisure", nameFr: "Sports & loisirs", nameAr: "رياضة وترفيه", icon: "sparkles", sortOrder: 6 },
  { slug: "services", nameEn: "Services", nameFr: "Services", nameAr: "خدمات", icon: "briefcase", sortOrder: 7 },
  { slug: "other", nameEn: "Other", nameFr: "Autres", nameAr: "أخرى", icon: "grid", sortOrder: 8 },
];

async function seedReferenceData() {
  const wilayaRows = wilayas.map(([code, name, nameAr]) => ({ code, nameEn: name, nameFr: name, nameAr }));
  await db.transaction(async (tx) => {
    await tx.insert(wilayaTable).values(wilayaRows).onConflictDoNothing({ target: wilayaTable.code });
    await tx.insert(categories).values(categoryRows).onConflictDoNothing({ target: categories.slug });
  });
  console.info(`Ensured ${wilayaRows.length} wilayas and ${categoryRows.length} categories are present.`);
}

seedReferenceData().catch((error: unknown) => {
  console.error("Reference data seed failed.", error);
  process.exitCode = 1;
}).finally(async () => {
  await pool.end();
});
