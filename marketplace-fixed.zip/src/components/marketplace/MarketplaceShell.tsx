"use client";

import type { ReactNode } from "react";
import { Icon } from "@/components/marketplace/Icon";
import { MarketplaceHeader } from "@/components/marketplace/MarketplaceHeader";
import { MarketplaceProvider, useMarketplace } from "@/components/marketplace/marketplace-provider";
import { MobileDock } from "@/components/marketplace/MobileDock";

function ToastViewport() {
  const { toast } = useMarketplace();
  return toast ? <div className="toast-viewport" role="status"><span><Icon name="check" size={15} /></span>{toast}</div> : null;
}

export function MarketplaceShell({ children }: { children: ReactNode }) {
  return <MarketplaceProvider><MarketplaceHeader /><div className="app-main">{children}</div><MobileDock /><ToastViewport /></MarketplaceProvider>;
}
