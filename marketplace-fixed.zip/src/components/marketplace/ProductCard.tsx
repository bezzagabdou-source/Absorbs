"use client";

import Link from "next/link";
import { Icon } from "@/components/marketplace/Icon";
import { useMarketplace } from "@/components/marketplace/marketplace-provider";
import { formatPrice, type MarketProduct } from "@/lib/marketplace-data";

export function ProductCard({ product, index = 0 }: { product: MarketProduct; index?: number }) {
  const { isFavorite, toggleFavorite, notify } = useMarketplace();
  const favorite = isFavorite(product.id);
  return (
    <article className="product-card" style={{ animationDelay: `${index * 50}ms` }}>
      <Link className="product-card-image" href={`/product/${product.id}`} style={{ backgroundImage: `url("${product.image}")` }} aria-label={`Voir ${product.title}`}>
        {product.badge && <span className="product-badge">{product.badge}</span>}
        <span className="image-condition">{product.condition}</span>
      </Link>
      <button className={`favorite-button ${favorite ? "is-favorite" : ""}`} onClick={() => { toggleFavorite(product.id); notify(favorite ? "Retiré de vos favoris" : "Ajouté à vos favoris"); }} aria-label={favorite ? "Retirer des favoris" : "Ajouter aux favoris"} aria-pressed={favorite}><Icon name="heart" size={18} /></button>
      <div className="product-card-copy">
        <div className="product-card-meta"><span>{product.category}</span><span className="posted-time">{product.posted}</span></div>
        <Link className="product-card-title" href={`/product/${product.id}`}>{product.title}</Link>
        <div className="product-price-row"><strong>{formatPrice(product.price)}</strong>{product.previousPrice && <del>{formatPrice(product.previousPrice)}</del>}</div>
        <div className="product-card-bottom">
          <span className="product-location"><Icon name="pin" size={13} />{product.commune}, {product.wilaya}</span>
          <span className={`seller-mini ${product.sellerVerified ? "verified" : ""}`} title={`${product.sellerName}${product.sellerVerified ? " · Identité vérifiée" : ""}`}><span>{product.sellerInitials}</span>{product.sellerVerified && <Icon name="verified" size={12} />}</span>
        </div>
        {(product.escrow || product.delivery) && <div className="product-assurances">{product.escrow && <span><Icon name="shieldCheck" size={13} /> Achat protégé</span>}{product.delivery && <span><Icon name="truck" size={13} /> Livraison</span>}</div>}
      </div>
    </article>
  );
}
