"use client";
/* eslint react-hooks/set-state-in-effect: off -- Restore device preferences after hydration to avoid server/client mismatch. */

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

type Theme = "light" | "dark" | "amoled";
type InstallPromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };
type MarketplaceContextValue = {
  favorites: string[];
  toggleFavorite: (id: string) => void;
  isFavorite: (id: string) => boolean;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  language: string;
  setLanguage: (language: string) => void;
  notify: (message: string) => void;
  installAvailable: boolean;
  installApp: () => Promise<boolean>;
  toast: string | null;
};

const MarketplaceContext = createContext<MarketplaceContextValue | null>(null);

export function MarketplaceProvider({ children }: { children: ReactNode }) {
  const [favorites, setFavorites] = useState<string[]>([]);
  const [theme, setThemeState] = useState<Theme>("light");
  const [language, setLanguageState] = useState("Français");
  const [toast, setToast] = useState<string | null>(null);
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);

  useEffect(() => {
    try {
      const savedFavorites = window.localStorage.getItem("dz-favorites");
      const savedTheme = window.localStorage.getItem("dz-theme") as Theme | null;
      const savedLanguage = window.localStorage.getItem("dz-language");
      if (savedFavorites) setFavorites(JSON.parse(savedFavorites) as string[]);
      if (savedTheme === "light" || savedTheme === "dark" || savedTheme === "amoled") setThemeState(savedTheme);
      if (savedLanguage) setLanguageState(savedLanguage);
    } catch {
      // Storage can be disabled by the browser; the marketplace still works in memory.
    }

    if ("serviceWorker" in navigator) void navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    const onInstall = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onInstall);
    return () => window.removeEventListener("beforeinstallprompt", onInstall);
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try { window.localStorage.setItem("dz-theme", theme); } catch { /* private browsing */ }
  }, [theme]);

  useEffect(() => {
    try {
      window.localStorage.setItem("dz-favorites", JSON.stringify(favorites));
      window.localStorage.setItem("dz-language", language);
    } catch { /* private browsing */ }
  }, [favorites, language]);

  useEffect(() => {
    if (!toast) return;
    const timeout = window.setTimeout(() => setToast(null), 2900);
    return () => window.clearTimeout(timeout);
  }, [toast]);

  const toggleFavorite = useCallback((id: string) => {
    setFavorites((current) => current.includes(id) ? current.filter((favorite) => favorite !== id) : [...current, id]);
  }, []);
  const setTheme = useCallback((value: Theme) => setThemeState(value), []);
  const setLanguage = useCallback((value: string) => setLanguageState(value), []);
  const notify = useCallback((message: string) => setToast(message), []);
  const installApp = useCallback(async () => {
    if (!installPrompt) return false;
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    setInstallPrompt(null);
    return choice.outcome === "accepted";
  }, [installPrompt]);

  const value = useMemo(() => ({ favorites, toggleFavorite, isFavorite: (id: string) => favorites.includes(id), theme, setTheme, language, setLanguage, notify, installAvailable: Boolean(installPrompt), installApp, toast }), [favorites, toggleFavorite, theme, setTheme, language, setLanguage, notify, installPrompt, installApp, toast]);
  return <MarketplaceContext.Provider value={value}>{children}</MarketplaceContext.Provider>;
}

export function useMarketplace() {
  const context = useContext(MarketplaceContext);
  if (!context) throw new Error("useMarketplace must be used inside MarketplaceProvider");
  return context;
}
