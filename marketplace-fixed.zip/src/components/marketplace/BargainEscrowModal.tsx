"use client";
/* eslint react/no-unescaped-entities: off -- Literal French apostrophes are safe JSX text. */

import { useEffect, useState, type FormEvent } from "react";
import { motion } from "framer-motion";
import { Icon } from "@/components/marketplace/Icon";
import { useMarketplace } from "@/components/marketplace/marketplace-provider";
import { formatPrice, type MarketProduct } from "@/lib/marketplace-data";

type ModalTab = "offer" | "protection";

export function BargainEscrowModal({ product, open, onClose, initialTab = "offer" }: { product: MarketProduct; open: boolean; onClose: () => void; initialTab?: ModalTab }) {
  const [tab, setTab] = useState<ModalTab>(initialTab);
  const [amount, setAmount] = useState(String(Math.round(product.price * 0.92)));
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [notice, setNotice] = useState("");
  const { notify } = useMarketplace();
  const numericAmount = Number(amount) || 0;

  useEffect(() => {
    if (!open) return;
    setTab(initialTab);
    setAmount(String(Math.round(product.price * 0.92)));
    setNotice("");
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [open, initialTab, onClose, product.price]);

  if (!open) return null;

  const submitOffer = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (numericAmount < 1) { setNotice("Entrez un montant valide en dinars."); return; }
    setSending(true);
    setNotice("");
    try {
      const response = await fetch("/api/offers", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ productId: product.id, amountDzd: numericAmount, message }) });
      if (response.status === 401) {
        setNotice("Connectez-vous avec un compte vérifié pour envoyer une offre protégée.");
      } else if (!response.ok) {
        const data = await response.json().catch(() => ({})) as { error?: string };
        setNotice(data.error ?? "Cette offre n'a pas pu être envoyée. Réessayez dans un instant.");
      } else {
        setNotice("Votre offre a été envoyée au vendeur.");
        notify("Offre envoyée — le vendeur sera prévenu.");
      }
    } catch {
      setNotice("Connexion indisponible. Votre offre n'a pas été envoyée.");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <motion.section className="bargain-modal" role="dialog" aria-modal="true" aria-labelledby="bargain-title" initial={{ opacity: 0, y: 10, scale: 0.985 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.2, ease: "easeOut" }}>
        <button className="modal-close" onClick={onClose} aria-label="Fermer"><Icon name="close" size={20} /></button>
        <div className="modal-product-line"><span className="modal-product-photo" style={{ backgroundImage: `url("${product.image}")` }} /><span><small>À PROPOS DE CETTE ANNONCE</small><b>{product.title}</b><em>{formatPrice(product.price)} · {product.wilaya}</em></span></div>
        <div className="bargain-tabs" role="tablist" aria-label="Choisir une option"><button role="tab" aria-selected={tab === "offer"} className={tab === "offer" ? "active" : ""} onClick={() => { setTab("offer"); setNotice(""); }}><Icon name="message" size={17} /> Proposer un prix</button><button role="tab" aria-selected={tab === "protection"} className={tab === "protection" ? "active" : ""} onClick={() => { setTab("protection"); setNotice(""); }}><Icon name="shieldCheck" size={17} /> Achat protégé</button></div>
        {tab === "offer" ? <form className="offer-form" onSubmit={submitOffer}>
          <div className="modal-section-title"><span className="modal-icon mint"><Icon name="tag" size={18} /></span><div><h2 id="bargain-title">Un prix en tête ?</h2><p>Une proposition sympa ouvre souvent la conversation.</p></div></div>
          <label className="offer-amount-label">Votre proposition <span>Le prix affiché est {formatPrice(product.price)}</span></label>
          <div className="offer-amount-field"><input aria-label="Montant de votre offre en dinars" inputMode="numeric" type="number" min="1" max="999999999" value={amount} onChange={(event) => setAmount(event.target.value)} /><b>DA</b></div>
          <div className="offer-presets"><button type="button" onClick={() => setAmount(String(Math.round(product.price * 0.95)))}>−5%</button><button type="button" onClick={() => setAmount(String(Math.round(product.price * 0.9)))}>−10%</button><button type="button" onClick={() => setAmount(String(Math.round(product.price * 0.85)))}>−15%</button><span>{product.price > 0 && numericAmount > product.price ? "Au-dessus du prix affiché" : "Offre personnalisée"}</span></div>
          <label className="offer-message-label">Un petit mot au vendeur <span>Facultatif</span><textarea maxLength={300} placeholder="Bonjour, votre annonce m'intéresse…" value={message} onChange={(event) => setMessage(event.target.value)} /></label>
          <div className="offer-summary"><span>Votre offre</span><b>{formatPrice(numericAmount)}</b></div>
          {notice && <div className={`modal-notice ${notice.startsWith("Votre offre") ? "success" : ""}`} role="status"><Icon name={notice.startsWith("Votre offre") ? "check" : "lock"} size={16} />{notice}</div>}
          <button className="modal-primary" type="submit" disabled={sending || numericAmount < 1}>{sending ? "Envoi sécurisé…" : "Envoyer mon offre"}<Icon name="arrow" size={18} /></button>
          <p className="modal-footnote"><Icon name="shield" size={13} /> Aucune coordonnée personnelle n'est partagée avant votre accord.</p>
        </form> : <div className="escrow-explainer">
          <div className="modal-section-title"><span className="modal-icon green"><Icon name="shieldCheck" size={20} /></span><div><h2 id="bargain-title">Un échange, en confiance.</h2><p>Le parcours d'achat protégé est en préparation.</p></div></div>
          <div className="escrow-steps"><div><span>01</span><i className="step-line" /><p><b>Le paiement est sécurisé</b><small>Via CIB ou Edahabia avec un partenaire agréé.</small></p></div><div><span>02</span><i className="step-line" /><p><b>Votre colis est suivi</b><small>Livraison par un transporteur disponible dans votre wilaya.</small></p></div><div><span>03</span><i className="step-line" /><p><b>Vous confirmez la réception</b><small>Le vendeur est payé après votre confirmation.</small></p></div></div>
          <div className="escrow-provider-note"><Icon name="info" size={17} /><span><b>Pas encore actif</b><small>Les paiements et la libération des fonds ne sont pas activés dans cet environnement. Ne versez jamais d'argent en dehors d'un partenaire agréé.</small></span></div>
          <button className="modal-primary" type="button" onClick={() => { setTab("offer"); setNotice("L'achat protégé n'est pas encore activé. Vous pouvez toutefois contacter le vendeur pour organiser un échange sûr."); }}>Contacter le vendeur <Icon name="arrow" size={18} /></button>
          <p className="modal-footnote"><Icon name="lock" size={13} /> N'envoyez jamais de code OTP ni vos informations bancaires à un vendeur.</p>
        </div>}
      </motion.section>
    </div>
  );
}
