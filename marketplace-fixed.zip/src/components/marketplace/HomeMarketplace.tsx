"use client";
/* eslint react/no-unescaped-entities: off -- Literal French apostrophes are safe JSX text. */

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { Icon } from "@/components/marketplace/Icon";
import { ProductCard } from "@/components/marketplace/ProductCard";
import { categories, sampleProducts, wilayaOptions } from "@/lib/marketplace-data";

const categoryDescriptions: Record<string, string> = {
  "Électronique": "Téléphones, informatique, audio…", "Véhicules": "Auto, moto, pièces & plus", "Maison": "Tout pour mieux vivre", "Immobilier": "Votre prochain chez-vous",
  "Mode": "Les belles pièces d'occasion", "Loisirs": "Sorties, sport et passions", "Services": "Les talents près de vous", "Tout voir": "Toutes les bonnes trouvailles",
};

export function HomeMarketplace() {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [wilaya, setWilaya] = useState("Alger");
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const params = new URLSearchParams();
    if (query.trim()) params.set("q", query.trim());
    if (wilaya !== "Toutes les wilayas") params.set("wilaya", wilaya);
    router.push(`/explore?${params.toString()}`);
  };
  const featured = sampleProducts[0];
  return (
    <main className="home-page market-container">
      <section className="hero-section">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-spark"><Icon name="sparkles" size={14} /></span> DZ-EXCHANGE <span className="eyebrow-divider">/</span> L'ÉDITION ALGÉRIENNE</div>
          <h1>Le bon choix.<br /><span>La bonne personne.</span><br />Tout près de vous.</h1>
          <p className="hero-description">Achetez et vendez avec confiance, partout en Algérie. Des rencontres locales, des échanges protégés, une communauté qui se connaît.</p>
          <form className="hero-search" onSubmit={submit}>
            <label className="hero-search-input"><Icon name="search" size={19} /><input aria-label="Que recherchez-vous ?" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Un iPhone, un appartement, un vélo…" /></label>
            <span className="hero-search-divider" />
            <label className="hero-location"><Icon name="pin" size={17} /><select value={wilaya} onChange={(event) => setWilaya(event.target.value)} aria-label="Choisir une wilaya">{wilayaOptions.map((option) => <option key={option}>{option}</option>)}</select><Icon name="chevron" size={15} /></label>
            <button className="hero-search-button" aria-label="Rechercher"><Icon name="arrow" size={20} /></button>
          </form>
          <div className="hero-trending"><span>À la une</span><Link href="/explore?q=smartphone">Smartphones</Link><Link href="/explore?category=vehicles">Voitures</Link><Link href="/explore?category=real-estate">Immobilier</Link></div>
          <div className="hero-stats"><div><strong>58</strong><span>wilayas couvertes</span></div><i /><div><strong>+24k</strong><span>annonces actives</span></div><i /><div><strong>100%</strong><span>pensé pour ici</span></div></div>
        </div>
        <div className="hero-art" aria-label="Découvrez les bonnes affaires près de chez vous">
          <div className="hero-art-topline"><span>LES TROUVAILLES DU JOUR</span><span className="hero-art-live"><i /> EN DIRECT</span></div>
          <div className="hero-art-image" style={{ backgroundImage: `url("${featured.image}")` }}>
            <div className="hero-image-overlay" />
            <div className="hero-product-float"><span className="float-check"><Icon name="check" size={15} /></span><div><b>Une bonne affaire ?</b><small>Votre prochain coup de cœur est ici.</small></div><Icon name="arrow" size={18} /></div>
            <span className="hero-image-note">01 <span>/</span> 08 · SÉLECTION LOCALE</span>
          </div>
          <div className="hero-art-footer"><div><span>À DÉCOUVRIR</span><b>Des milliers de belles histoires.</b></div><Link href="/explore" aria-label="Découvrir le marché"><Icon name="arrow" size={19} /></Link></div>
          <span className="hero-art-stamp"><Icon name="leaf" size={18} /> <span>Fait<br />pour DZ</span></span>
        </div>
        <div className="hero-bg-orb hero-bg-orb-one" /><div className="hero-bg-orb hero-bg-orb-two" />
      </section>

      <section className="assurance-strip" aria-label="Nos engagements">
        <div><span className="assurance-icon mint"><Icon name="shieldCheck" size={20} /></span><p><b>Des vendeurs vérifiés</b><small>On sait avec qui vous échangez</small></p></div>
        <div><span className="assurance-icon peach"><Icon name="wallet" size={20} /></span><p><b>Un achat plus serein</b><small>Le paiement protégé, bientôt ici</small></p></div>
        <div><span className="assurance-icon lilac"><Icon name="truck" size={20} /></span><p><b>Livré dans votre wilaya</b><small>Chez vous ou en point relais</small></p></div>
        <div><span className="assurance-icon sand"><Icon name="heart" size={19} /></span><p><b>Une communauté locale</b><small>De vraies personnes, près de vous</small></p></div>
      </section>

      <section className="section-block categories-section">
        <div className="section-heading"><div><p className="section-kicker">VOTRE PROCHAINE TROUVAILLE</p><h2>On cherche quoi, aujourd'hui ?</h2></div><Link className="text-link" href="/explore">Tout explorer <Icon name="arrow" size={17} /></Link></div>
        <div className="category-grid">{categories.map((category) => <Link className="category-tile" href={`/explore?category=${encodeURIComponent(category.label)}`} key={category.label}><span className={`category-icon ${category.color}`}><Icon name={category.icon as "devices" | "car" | "home" | "building" | "shirt" | "sparkles" | "briefcase" | "grid"} size={23} /></span><b>{category.label}</b><small>{categoryDescriptions[category.label]}</small><span className="category-count">{category.count} annonces</span></Link>)}</div>
      </section>

      <section className="section-block deals-section">
        <div className="section-heading"><div><p className="section-kicker deals-kicker"><span className="pulse-dot" /> LES BELLES AFFAIRES</p><h2>Les prix qui font plaisir.</h2></div><Link className="text-link" href="/explore?sort=price-down">Voir toutes les offres <Icon name="arrow" size={17} /></Link></div>
        <div className="product-grid">{sampleProducts.slice(0, 4).map((product, index) => <ProductCard key={product.id} product={product} index={index} />)}</div>
      </section>

      <section className="local-banner">
        <div className="local-banner-copy"><span className="local-banner-kicker"><Icon name="pin" size={15} /> LE MARCHÉ, AUTOUR DE VOUS</span><h2>Les bonnes affaires<br />ne sont jamais loin.</h2><p>Des annonces proches, des échanges simples et une ville qui se retrouve. Choisissez votre wilaya, on s'occupe du reste.</p><Link className="button-light" href="/explore">Explorer autour de moi <Icon name="arrow" size={17} /></Link></div>
        <div className="local-map-art"><div className="map-rings" /><div className="map-road road-one" /><div className="map-road road-two" /><div className="map-road road-three" /><span className="map-marker marker-one"><Icon name="pin" size={17} /></span><span className="map-marker marker-two"><Icon name="pin" size={17} /></span><span className="map-marker marker-three"><Icon name="pin" size={17} /></span><span className="map-label label-one">Hydra</span><span className="map-label label-two">Alger centre</span><span className="map-you"><i /> Vous êtes ici</span><span className="map-distance">à 1,2 km</span></div>
      </section>

      <section className="section-block sellers-section">
        <div className="seller-feature-card"><div className="seller-feature-icon"><Icon name="verified" size={26} /></div><div><span className="section-kicker">LE CLUB DES VENDEURS DE CONFIANCE</span><h3>La confiance, ça se construit.<br />Et ça se reconnaît.</h3><p>Des badges clairs, une réputation méritée et de vrais outils pour les vendeurs qui font les choses bien.</p><Link href="/dashboard">Découvrir mon espace vendeur <Icon name="arrow" size={16} /></Link></div><div className="seller-badge-stack"><div className="tier-card tier-top"><Icon name="shieldCheck" size={18} /><span><b>Confiance niveau 3</b><small>Identité & activité confirmées</small></span><Icon name="check" size={16} /></div><div className="tier-card tier-bottom"><Icon name="star" size={17} /><span><b>4,9 / 5</b><small>La communauté recommande</small></span></div></div></div>
      </section>

      <section className="section-block latest-section"><div className="section-heading"><div><p className="section-kicker">AJOUTÉES À L'INSTANT</p><h2>Tout juste sur le marché.</h2></div><Link className="text-link" href="/explore?sort=newest">Les dernières annonces <Icon name="arrow" size={17} /></Link></div><div className="product-grid">{sampleProducts.slice(4, 8).map((product, index) => <ProductCard key={product.id} product={product} index={index} />)}</div></section>
      <footer className="home-footer"><Link className="brand" href="/"><span className="brand-mark"><span></span><span></span><span></span></span><span className="brand-copy"><b>dz<span>exchange</span></b><small>le marché d'ici, en mieux</small></span></Link><p>Une nouvelle façon d'échanger, pensée en Algérie et pour l'Algérie.</p><span>© 2025 DZ Exchange <i /> Une marketplace locale, en mouvement.</span></footer>
    </main>
  );
}
