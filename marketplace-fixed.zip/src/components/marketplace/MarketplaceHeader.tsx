"use client";
/* eslint react/no-unescaped-entities: off -- Literal French apostrophes are safe JSX text. */

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { Icon } from "@/components/marketplace/Icon";
import { useMarketplace } from "@/components/marketplace/marketplace-provider";
import { wilayaOptions } from "@/lib/marketplace-data";

export function MarketplaceHeader() {
  const router = useRouter();
  const pathname = usePathname();
  const [query, setQuery] = useState("");
  const [location, setLocation] = useState("Alger");
  const [menuOpen, setMenuOpen] = useState(false);
  const { favorites, notify, installAvailable, installApp } = useMarketplace();
  const submitSearch = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const params = new URLSearchParams();
    if (query.trim()) params.set("q", query.trim());
    if (location !== "Toutes les wilayas") params.set("wilaya", location);
    router.push(`/explore${params.size ? `?${params.toString()}` : ""}`);
  };

  return (
    <header className="site-header">
      <div className="header-main market-container">
        <Link className="brand" href="/" aria-label="DZ Exchange accueil">
          <span className="brand-mark"><span></span><span></span><span></span></span>
          <span className="brand-copy"><b>dz<span>exchange</span></b><small>le marché d'ici, en mieux</small></span>
        </Link>
        <form className="header-search" onSubmit={submitSearch}>
          <Icon name="search" size={19} className="search-leading" />
          <input aria-label="Rechercher un article" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Que recherchez-vous aujourd'hui ?" />
          <span className="search-divider" />
          <label className="location-select"><Icon name="pin" size={16} /><select aria-label="Wilaya" value={location} onChange={(event) => setLocation(event.target.value)}>{wilayaOptions.map((item) => <option key={item}>{item}</option>)}</select><Icon name="chevron" size={15} /></label>
          <button className="search-submit" aria-label="Lancer la recherche"><Icon name="search" size={18} /></button>
        </form>
        <div className="header-actions">
          {installAvailable && <button className="header-icon install-button" onClick={() => void installApp()} aria-label="Installer l'application"><Icon name="download" size={19} /></button>}
          <button className="header-icon header-notifications" aria-label="Notifications" onClick={() => notify("Vous êtes à jour — aucune nouvelle notification.")}><Icon name="bell" size={20} /><i /></button>
          <Link className="header-icon saved-link" href="/explore?filter=favorites" aria-label="Favoris"><Icon name="heart" size={20} />{favorites.length > 0 && <span className="count-dot">{favorites.length}</span>}</Link>
          <Link className="account-chip" href="/dashboard"><span className="account-avatar">A</span><span>Mon espace</span><Icon name="chevron" size={15} /></Link>
          <Link className="sell-button" href="/dashboard?create=true"><Icon name="plus" size={18} />Déposer une annonce</Link>
        </div>
        <button className="mobile-menu-button" aria-label="Ouvrir le menu" onClick={() => setMenuOpen(!menuOpen)}><Icon name={menuOpen ? "close" : "menu"} size={22} /></button>
      </div>
      <div className="header-categories market-container">
        <nav aria-label="Navigation principale">
          <Link className={pathname === "/explore" ? "active" : ""} href="/explore">Explorer</Link>
          <Link href="/explore?category=vehicles">Véhicules</Link>
          <Link href="/explore?category=electronics">Électronique</Link>
          <Link href="/explore?category=real-estate">Immobilier</Link>
          <Link href="/explore?category=home">Maison & jardin</Link>
        </nav>
        <div className="header-trust"><span className="trust-live-dot" />Des échanges plus sûrs, partout en Algérie <Icon name="shieldCheck" size={15} /></div>
      </div>
      <form className="mobile-search market-container" onSubmit={submitSearch}>
        <Icon name="search" size={18} /><input aria-label="Rechercher" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Rechercher un article…" /><button aria-label="Rechercher"><Icon name="arrow" size={18} /></button>
      </form>
      {menuOpen && <div className="mobile-menu"><Link href="/explore" onClick={() => setMenuOpen(false)}>Explorer le marché</Link><Link href="/dashboard" onClick={() => setMenuOpen(false)}>Mon espace vendeur</Link><Link href="/chat" onClick={() => setMenuOpen(false)}>Messages</Link><Link href="/settings" onClick={() => setMenuOpen(false)}>Paramètres</Link></div>}
    </header>
  );
}
