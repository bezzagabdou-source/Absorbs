"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Icon } from "@/components/marketplace/Icon";

const items = [
  { href: "/", label: "Accueil", icon: "home" as const },
  { href: "/explore", label: "Explorer", icon: "search" as const },
  { href: "/dashboard?create=true", label: "Vendre", icon: "plusCircle" as const, featured: true },
  { href: "/chat", label: "Messages", icon: "chat" as const },
  { href: "/settings", label: "Profil", icon: "user" as const },
];

export function MobileDock() {
  const pathname = usePathname();
  return <nav className="mobile-dock" aria-label="Navigation mobile">{items.map((item) => <Link key={item.href} href={item.href} className={`${item.featured ? "dock-sell" : ""} ${pathname === item.href ? "current" : ""}`} aria-label={item.label}><span><Icon name={item.icon} size={item.featured ? 22 : 20} /></span><small>{item.label}</small></Link>)}</nav>;
}
