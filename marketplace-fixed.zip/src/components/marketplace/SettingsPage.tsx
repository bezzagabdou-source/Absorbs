"use client";
/* eslint react/no-unescaped-entities: off -- Literal French apostrophes are safe JSX text. */

import Link from "next/link";
import { useEffect, useState } from "react";
import { Icon } from "@/components/marketplace/Icon";
import { useMarketplace } from "@/components/marketplace/marketplace-provider";
import type { IconName } from "@/lib/marketplace-ui";
import { clearOfflineDatabase } from "@/lib/offline-db";

type SettingsSection = "general" | "security" | "preferences" | "notifications" | "payments";
type ToggleKey = "twoFactor" | "offlineMode" | "dataSaver" | "push" | "sms" | "email" | "inApp";
type TogglePrefs = Record<ToggleKey, boolean>;

const sections: { id: SettingsSection; title: string; icon: IconName; note?: string }[] = [
  { id: "general", title: "Général", icon: "user" },
  { id: "security", title: "Sécurité & confiance", icon: "shieldCheck", note: "2" },
  { id: "preferences", title: "Préférences", icon: "sliders" },
  { id: "notifications", title: "Notifications", icon: "bell" },
  { id: "payments", title: "Paiements", icon: "wallet" },
];

function ToggleRow({ icon, title, description, checked, onChange, tag }: { icon: IconName; title: string; description: string; checked: boolean; onChange: () => void; tag?: string }) {
  return <div className="settings-row"><span className="settings-row-icon"><Icon name={icon} size={18} /></span><div className="settings-row-copy"><span><b>{title}</b>{tag && <em>{tag}</em>}</span><small>{description}</small></div><button type="button" className={`switch ${checked ? "on" : ""}`} role="switch" aria-checked={checked} aria-label={title} onClick={onChange}><i /></button></div>;
}

export function SettingsPage({ initialSection = "general" }: { initialSection?: SettingsSection }) {
  const [section, setSection] = useState<SettingsSection>(initialSection);
  const [prefs, setPrefs] = useState<TogglePrefs>({ twoFactor: false, offlineMode: true, dataSaver: false, push: false, sms: true, email: true, inApp: true });
  const [activeSessions, setActiveSessions] = useState(["Chrome · Cet appareil", "Safari · iPhone 14"]);
  const [offlineSize, setOfflineSize] = useState("Calcul en cours…");
  const [receiptName, setReceiptName] = useState("");
  const [kycFile, setKycFile] = useState("");
  const { theme, setTheme, language, setLanguage, notify, favorites } = useMarketplace();

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem("dz-settings");
      if (saved) setPrefs({ ...prefs, ...(JSON.parse(saved) as Partial<TogglePrefs>) });
      if (navigator.storage?.estimate) void navigator.storage.estimate().then((estimate) => setOfflineSize(`${((estimate.usage ?? 0) / (1024 * 1024)).toFixed(1)} Mo utilisés`)).catch(() => setOfflineSize("Indisponible"));
      else setOfflineSize("Indisponible");
    } catch { setOfflineSize("Indisponible"); }
    // Initial preferences are loaded once per visit.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem("dz-settings", JSON.stringify(prefs));
      document.documentElement.dataset.dataSaver = prefs.dataSaver ? "on" : "off";
    } catch { /* local preferences remain in memory */ }
  }, [prefs]);

  const update = (key: ToggleKey) => setPrefs((current) => ({ ...current, [key]: !current[key] }));
  const requestPush = async () => {
    if (!("Notification" in window)) { notify("Les notifications ne sont pas disponibles dans ce navigateur."); return; }
    const permission = await Notification.requestPermission();
    if (permission !== "granted") { notify("Vous pourrez activer les notifications dans les réglages de votre navigateur."); return; }
    const vapidKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
    if (!vapidKey) { notify("Autorisation accordée. La diffusion push sera activée dès la configuration du serveur."); return; }
    try {
      const registration = await navigator.serviceWorker.ready;
      const applicationServerKey = Uint8Array.from(atob(vapidKey.replace(/-/g, "+").replace(/_/g, "/")), (character) => character.charCodeAt(0)).buffer;
      const subscription = await registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey });
      const response = await fetch("/api/push/subscriptions", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(subscription) });
      if (response.ok) { setPrefs((current) => ({ ...current, push: true })); notify("Notifications push activées sur cet appareil."); }
      else notify(response.status === 401 ? "Connectez-vous pour enregistrer cet appareil." : "Le service push n'a pas pu enregistrer cet appareil.");
    } catch { notify("Impossible d'enregistrer cet appareil pour les notifications."); }
  };

  const clearOffline = async () => {
    try {
      const cacheNames = await caches.keys();
      await Promise.all(cacheNames.filter((name) => name.startsWith("dz-exchange")).map((name) => caches.delete(name)));
      await clearOfflineDatabase();
      setOfflineSize("0 Mo utilisés");
      notify("Les données hors ligne de DZ Exchange ont été supprimées.");
    } catch { notify("Le stockage hors ligne n'est pas accessible."); }
  };

  const chooseKycFile = (file?: File) => { if (file) { setKycFile(file.name); notify("Document sélectionné. L'envoi KYC nécessite un parcours sécurisé activé."); } };

  return (
    <main className="market-container settings-page">
      <div className="breadcrumbs"><Link href="/">Accueil</Link><Icon name="chevron" size={13} /><span>Paramètres</span></div>
      <div className="settings-title-row"><div><p className="section-kicker">VOTRE ESPACE PERSONNEL</p><h1>Tout à votre façon.</h1><p>Vos préférences, votre sécurité, votre expérience.</p></div><div className="settings-user-pill"><span className="account-avatar">A</span><span><b>Amel B.</b><small>Membre depuis 2024</small></span><span className="unverified-pill"><i /> À vérifier</span></div></div>
      <div className="settings-shell">
        <aside className="settings-sidebar"><div className="settings-side-label">MON COMPTE</div>{sections.map((item) => <button key={item.id} className={section === item.id ? "active" : ""} onClick={() => setSection(item.id)}><Icon name={item.icon} size={18} /><span>{item.title}</span>{item.note && <small>{item.note}</small>}{section === item.id && <Icon name="chevron" size={15} />}</button>)}<div className="settings-side-divider" /><Link href="/dashboard"><Icon name="chart" size={17} /> Espace vendeur <Icon name="external" size={13} /></Link><Link href="/chat"><Icon name="chat" size={17} /> Mes messages <span className="nav-unread">2</span></Link><div className="settings-help-card"><span><Icon name="help" size={18} /></span><b>Besoin d'un coup de main ?</b><small>Notre équipe est là pour vous.</small><button onClick={() => notify("L'assistance sera disponible après activation de votre compte.")}>Contacter l'assistance <Icon name="arrow" size={13} /></button></div></aside>
        <section className="settings-content">
          {section === "general" && <>
            <div className="settings-panel-heading"><div><h2>Général</h2><p>Personnalisez votre profil et votre langue.</p></div><span className="settings-panel-icon"><Icon name="user" size={19} /></span></div>
            <div className="profile-settings-card"><div className="profile-large-avatar">A<span><Icon name="camera" size={13} /></span></div><div><b>Amel B.</b><small>Profil public · Alger, Algérie</small><button onClick={() => notify("La modification du profil sera disponible une fois connectée.")}>Modifier mon profil <Icon name="arrow" size={14} /></button></div><span className="profile-id">ID membre <b>#DZ-240891</b></span></div>
            <div className="settings-card"><div className="settings-card-heading"><div><b>Langue d'affichage</b><small>Choisissez la langue qui vous ressemble.</small></div><Icon name="globe" size={18} /></div><div className="language-options">{[{ name: "Français", native: "Français", code: "FR" }, { name: "العربية", native: "العربية الفصحى", code: "AR" }, { name: "Darja", native: "الدارجة الجزائرية", code: "DZ" }, { name: "English", native: "English", code: "EN" }, { name: "Tamazight", native: "ⵜⴰⵎⴰⵣⵉⵖⵜ", code: "TZ" }].map((item) => <button key={item.name} className={language === item.name ? "selected" : ""} onClick={() => { setLanguage(item.name); notify(`Langue sélectionnée : ${item.name}. Certaines traductions arrivent bientôt.`); }}><span>{item.code}</span><b>{item.native}</b>{language === item.name && <Icon name="check" size={15} />}</button>)}</div><div className="settings-note"><Icon name="info" size={15} /> Le français est la langue complète. D'autres traductions arrivent progressivement.</div></div>
            <div className="settings-card compact-card"><div className="settings-card-heading"><div><b>Région et devise</b><small>Les prix restent affichés en dinar algérien.</small></div><Icon name="pin" size={18} /></div><div className="inline-settings-fields"><label>Wilaya<select defaultValue="Alger"><option>Alger</option><option>Oran</option><option>Constantine</option><option>Blida</option></select></label><label>Format de prix<select defaultValue="DZD · DA"><option>DZD · DA</option><option>Dinar · دج</option></select></label></div></div>
          </>}
          {section === "security" && <>
            <div className="settings-panel-heading"><div><h2>Sécurité & confiance</h2><p>Votre identité et vos accès, protégés.</p></div><span className="settings-panel-icon"><Icon name="shieldCheck" size={19} /></span></div>
            <div className="trust-progress-card"><span className="trust-progress-icon"><Icon name="shieldCheck" size={22} /></span><div><span className="trust-level-label">VOTRE NIVEAU DE CONFIANCE</span><b>Profil à compléter <span>· Niveau 0</span></b><div className="progress-track"><i /></div><small>Vérifiez votre identité pour débloquer le badge vendeur vérifié.</small></div><span className="trust-points">1 / 3 <small>étapes</small></span></div>
            <div className="settings-card security-card"><div className="settings-card-heading"><div><b>Clés d'accès & biométrie</b><small>Connectez-vous avec votre empreinte, votre visage ou une clé de sécurité.</small></div><span className="security-pill">RECOMMANDÉ</span></div><div className="passkey-row"><span className="passkey-icon"><Icon name="fingerprint" size={23} /></span><div><b>Passkeys (WebAuthn)</b><small>Connexion sans mot de passe, liée à cet appareil.</small></div><button className="button-outline-small" onClick={() => notify("L'inscription de passkey sera activée après le raccordement du fournisseur d'identité.")}>Configurer <Icon name="arrow" size={14} /></button></div><div className="settings-card-divider" /><ToggleRow icon="lock" title="Double authentification (2FA)" description="Ajouter un second facteur à chaque nouvelle connexion." checked={prefs.twoFactor} onChange={() => { update("twoFactor"); notify("Préférence 2FA enregistrée sur cet appareil. La validation serveur doit être configurée."); }} tag="À CONFIGURER" /></div>
            <div className="settings-card"><div className="settings-card-heading"><div><b>Sessions actives</b><small>Appareils connectés à votre compte.</small></div><button className="subtle-link" onClick={() => { setActiveSessions(["Chrome · Cet appareil"]); notify("Les autres sessions ont été retirées de cette liste locale."); }}>Déconnecter les autres</button></div>{activeSessions.map((session, index) => <div className="session-row" key={session}><span className={`session-device ${index === 0 ? "current" : ""}`}><Icon name={index === 0 ? "devices" : "user"} size={18} /></span><span><b>{session}</b><small>{index === 0 ? "Alger, Algérie · Maintenant" : "Dernière activité · il y a 2 jours"}</small></span>{index === 0 ? <em>ACTUELLE</em> : <button onClick={() => setActiveSessions((current) => current.filter((item) => item !== session))}>Révoquer</button>}</div>)}</div>
            <div className="settings-card kyc-card"><div className="settings-card-heading"><div><b>Vérification d'identité (KYC DZ)</b><small>Un badge vérifié aide toute la communauté à échanger sereinement.</small></div><span className="kyc-status"><i /> NON VÉRIFIÉ</span></div><div className="kyc-steps"><span><b>01</b> Pièce d'identité</span><i /><span><b>02</b> Vérification sécurisée</span><i /><span><b>03</b> Badge de confiance</span></div><div className="kyc-upload"><Icon name="file" size={19} /><span><b>{kycFile || "Document d'identité"}</b><small>JPG, PNG ou PDF · traitement sécurisé requis</small></span><label className="button-outline-small">{kycFile ? "Remplacer" : "Choisir un fichier"}<input type="file" accept="image/*,.pdf" onChange={(event) => chooseKycFile(event.target.files?.[0])} /></label></div><p className="settings-note"><Icon name="lock" size={14} /> Le document est sélectionné localement et n'est pas transmis. Le portail KYC sécurisé n'est pas encore connecté.</p></div>
          </>}
          {section === "preferences" && <>
            <div className="settings-panel-heading"><div><h2>Votre expérience.</h2><p>Le marché s'adapte à vous, pas l'inverse.</p></div><span className="settings-panel-icon"><Icon name="sliders" size={19} /></span></div>
            <div className="settings-card"><div className="settings-card-heading"><div><b>Apparence</b><small>Choisissez l'ambiance de votre marché.</small></div><Icon name="sun" size={18} /></div><div className="theme-grid">{[{ id: "light", title: "Clair", icon: "sun" as const, className: "theme-preview-light", detail: "Une lumière naturelle" }, { id: "dark", title: "Sombre", icon: "moon" as const, className: "theme-preview-dark", detail: "Un confort tout en douceur" }, { id: "amoled", title: "AMOLED", icon: "sparkles" as const, className: "theme-preview-amoled", detail: "Noir profond, batterie préservée" }].map((item) => <button key={item.id} className={`theme-option ${theme === item.id ? "selected" : ""}`} onClick={() => setTheme(item.id as "light" | "dark" | "amoled")}><span className={`theme-preview ${item.className}`}><i /><i /><i /><b><Icon name={item.icon} size={14} /></b></span><span><b>{item.title}</b><small>{item.detail}</small></span>{theme === item.id && <span className="theme-check"><Icon name="check" size={13} /></span>}</button>)}</div></div>
            <div className="settings-card"><div className="settings-card-heading"><div><b>Économies & hors ligne</b><small>Pour une expérience fluide, même sur un réseau limité.</small></div><Icon name="leaf" size={18} /></div><ToggleRow icon="box" title="Mode hors connexion" description="Garder les pages récemment consultées accessibles." checked={prefs.offlineMode} onChange={() => update("offlineMode")} /><div className="settings-card-divider" /><ToggleRow icon="sliders" title="Économiseur de données" description="Réduire la qualité des images sur les réseaux mobiles." checked={prefs.dataSaver} onChange={() => update("dataSaver")} tag="3G / 4G" /><div className="offline-storage-row"><span><b>Stockage hors ligne</b><small>{offlineSize} · vos données restent sur cet appareil.</small></span><button className="subtle-link" onClick={() => void clearOffline()}>Vider le cache</button></div></div>
            <div className="settings-card compact-card"><div className="settings-card-heading"><div><b>Confidentialité locale</b><small>Vos favoris sont stockés sur cet appareil.</small></div><Icon name="heart" size={18} /></div><div className="privacy-info-row"><span>{favorites.length} annonce{favorites.length !== 1 ? "s" : ""} sauvegardée{favorites.length !== 1 ? "s" : ""}</span><button onClick={() => notify("Retirez chaque annonce depuis l'icône cœur pour gérer vos favoris.")}>Gérer mes favoris <Icon name="arrow" size={13} /></button></div></div>
          </>}
          {section === "notifications" && <>
            <div className="settings-panel-heading"><div><h2>Les nouvelles, à votre rythme.</h2><p>Choisissez ce que vous souhaitez recevoir, et comment.</p></div><span className="settings-panel-icon"><Icon name="bellRing" size={19} /></span></div>
            <div className="notification-highlight"><span><Icon name="bellRing" size={21} /></span><div><b>Restez dans la boucle.</b><small>Un message, une offre, une bonne affaire près de vous.</small></div><button onClick={() => void requestPush()}>{prefs.push ? "Activées" : "Activer les push"}<Icon name="arrow" size={14} /></button></div>
            <div className="settings-card notification-card"><div className="settings-card-heading"><div><b>Canaux de notification</b><small>Vous pouvez modifier vos choix à tout moment.</small></div><Icon name="settings" size={18} /></div><ToggleRow icon="bell" title="Notifications push" description="Alertes instantanées sur cet appareil." checked={prefs.push} onChange={() => { if (!prefs.push) void requestPush(); else update("push"); }} /><div className="settings-card-divider" /><ToggleRow icon="message" title="Messages & offres" description="Nouveaux messages, contre-offres et réponses." checked={prefs.inApp} onChange={() => update("inApp")} /><div className="settings-card-divider" /><ToggleRow icon="tag" title="Suivi de mes annonces" description="Baisse de prix, favoris et nouveaux contacts." checked={prefs.email} onChange={() => update("email")} /><div className="settings-card-divider" /><ToggleRow icon="credit" title="SMS importants" description="Activité de compte et alertes de sécurité uniquement." checked={prefs.sms} onChange={() => update("sms")} tag="Bientôt" /></div>
            <div className="settings-note wide-note"><Icon name="lock" size={15} /> Nous ne partagerons jamais vos coordonnées sans votre accord.</div>
          </>}
          {section === "payments" && <>
            <div className="settings-panel-heading"><div><h2>À votre convenance.</h2><p>Vos moyens de paiement et reçus, au même endroit.</p></div><span className="settings-panel-icon"><Icon name="wallet" size={19} /></span></div>
            <div className="payment-beta-banner"><span><Icon name="shieldCheck" size={20} /></span><div><b>Paiements sécurisés en préparation.</b><small>Ne communiquez jamais vos codes BaridiMob ou votre code OTP à un tiers.</small></div><em>BIENTÔT</em></div>
            <div className="settings-card payment-methods"><div className="settings-card-heading"><div><b>Mes moyens de paiement</b><small>Chaque paiement est traité par un partenaire agréé.</small></div><Icon name="credit" size={18} /></div><div className="payment-provider-row"><span className="provider-logo edahabia">E</span><span><b>Edahabia · Algérie Poste</b><small>Paiement CIB / Edahabia sécurisé</small></span><span className="provider-pending">À CONFIGURER</span><button className="button-outline-small" onClick={() => notify("Le raccordement Chargily / Algérie Poste doit être activé côté serveur.")}>Configurer</button></div><div className="settings-card-divider" /><div className="payment-provider-row"><span className="provider-logo cib">CIB</span><span><b>Carte CIB</b><small>Cartes bancaires algériennes</small></span><span className="provider-pending">À CONFIGURER</span><button className="button-outline-small" onClick={() => notify("Le prestataire CIB n'est pas encore configuré.")}>Ajouter</button></div><div className="settings-card-divider" /><div className="payment-provider-row"><span className="provider-logo baridi">BP</span><span><b>BaridiMob</b><small>Validation de reçu par votre espace</small></span><span className="provider-pending">À CONFIGURER</span><button className="button-outline-small" onClick={() => document.getElementById("receipt-upload")?.click()}>Importer un reçu</button></div><input className="visually-hidden" id="receipt-upload" type="file" accept="image/*,.pdf" onChange={(event) => { const file = event.target.files?.[0]; if (file) { setReceiptName(file.name); notify("Reçu sélectionné. La validation automatique n'est pas activée."); } }} />{receiptName && <div className="receipt-selected"><Icon name="file" size={15} /> {receiptName} <span>· En attente de validation serveur</span></div>}</div>
            <div className="settings-card escrow-card"><div className="settings-card-heading"><div><b>Achat protégé · séquestre</b><small>Un tiers de confiance garde les fonds jusqu'à confirmation de livraison.</small></div><span className="provider-pending">À VENIR</span></div><div className="escrow-flow"><span><i>1</i> Paiement confirmé</span><Icon name="arrow" size={14} /><span><i>2</i> Livraison reçue</span><Icon name="arrow" size={14} /><span><i>3</i> Vendeur payé</span></div><p><Icon name="info" size={14} /> Les transactions de cette version ne débitent aucune carte et ne retiennent aucun fonds.</p></div>
          </>}
          <div className="settings-content-footer"><span>Vos préférences sont sauvegardées sur cet appareil.</span><button onClick={() => notify("Aucune modification en attente.")}>Tout est à jour <Icon name="check" size={14} /></button></div>
        </section>
      </div>
    </main>
  );
}
