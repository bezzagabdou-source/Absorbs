"use client";

import Link from "next/link";
import { useState } from "react";
import { Icon } from "@/components/marketplace/Icon";
import { BargainEscrowModal } from "@/components/marketplace/BargainEscrowModal";
import { useMarketplace } from "@/components/marketplace/marketplace-provider";
import { formatPrice, type MarketProduct } from "@/lib/marketplace-data";

export function ProductDetails({ product }: { product: MarketProduct }) {
  const [selectedImage, setSelectedImage] = useState(0);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalTab, setModalTab] = useState<"offer" | "protection">("offer");
  const { isFavorite, toggleFavorite, notify } = useMarketplace();
  const favorite = isFavorite(product.id);
  const openModal = (tab: "offer" | "protection") => { setModalTab(tab); setModalOpen(true); };
  const shareProduct = async () => {
    if (navigator.share) { try { await navigator.share({ title: product.title, text: `Découvert sur DZ Exchange · ${formatPrice(product.price)}`, url: window.location.href }); } catch { /* Share dismissed. */ } }
    else { await navigator.clipboard?.writeText(window.location.href); notify("Lien de l'annonce copié"); }
  };
  return (
    <main className="market-container product-page">
      <div className="breadcrumbs"><Link href="/">Accueil</Link><Icon name="chevron" size={13} /><Link href="/explore">Explorer</Link><Icon name="chevron" size={13} /><span>{product.category}</span></div>
      <div className="product-detail-layout">
        <section className="gallery-column" aria-label="Photos du produit">
          <div className="product-main-image" style={{ backgroundImage: `url("${product.images[selectedImage] ?? product.image}")` }}><span className="gallery-count"><Icon name="camera" size={14} /> {selectedImage + 1} / {product.images.length}</span><button className={`gallery-favorite ${favorite ? "is-favorite" : ""}`} onClick={() => { toggleFavorite(product.id); notify(favorite ? "Retiré de vos favoris" : "Ajouté à vos favoris"); }} aria-label="Ajouter aux favoris"><Icon name="heart" size={20} /></button><span className="gallery-protected"><Icon name="shieldCheck" size={14} /> Achat protégé disponible bientôt</span></div>
          <div className="gallery-thumbnails">{product.images.map((image, index) => <button key={image} className={selectedImage === index ? "selected" : ""} style={{ backgroundImage: `url("${image}")` }} aria-label={`Voir la photo ${index + 1}`} onClick={() => setSelectedImage(index)} />)}<button className="add-photo-hint" onClick={() => notify("Les photos de l'annonce sont fournies par le vendeur.")}><Icon name="plus" size={19} /></button></div>
          <div className="product-description-card"><div className="description-heading"><h2>Description</h2><button onClick={shareProduct}><Icon name="external" size={16} /> Partager</button></div><p>{product.description}</p><div className="description-tags"><span><Icon name="check" size={13} /> Vendeur vérifié</span><span><Icon name="pin" size={13} /> {product.commune}, {product.wilaya}</span><span><Icon name="clock" size={13} /> Publiée {product.posted.toLowerCase()}</span></div></div>
          <div className="price-history-card"><div><span className="section-kicker">TRANSPARENCE DES PRIX</span><h3>Le prix est juste.</h3><p>Prix affiché cette semaine · stable</p></div><div className="price-history-chart"><svg viewBox="0 0 360 90" role="img" aria-label="Graphique de prix sur les 7 derniers jours"><defs><linearGradient id="chartFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#c5e8c9" stopOpacity=".8" /><stop offset="1" stopColor="#c5e8c9" stopOpacity="0" /></linearGradient></defs><path d="M0 64 C25 57 32 66 55 53 S95 56 119 41 S155 46 179 39 S214 47 239 28 S278 35 302 22 S337 29 360 12 L360 90 L0 90Z" fill="url(#chartFill)" /><path d="M0 64 C25 57 32 66 55 53 S95 56 119 41 S155 46 179 39 S214 47 239 28 S278 35 302 22 S337 29 360 12" fill="none" stroke="#368a60" strokeWidth="3" strokeLinecap="round" /></svg><div className="chart-labels"><span>7 jours</span><span>Maintenant</span></div></div></div>
        </section>
        <aside className="product-buy-column">
          <div className="product-condition-line"><span className="condition-pill">{product.condition}</span><span className="detail-posted">{product.posted}</span></div>
          <h1>{product.title}</h1>
          <div className="detail-price-row"><strong>{formatPrice(product.price)}</strong>{product.previousPrice && <><del>{formatPrice(product.previousPrice)}</del><span className="discount-pill">−{Math.round((1 - product.price / product.previousPrice) * 100)}%</span></>}</div>
          <p className="detail-price-note">Prix indiqué par le vendeur · Négociation possible</p>
          <div className="product-action-stack"><button className="button-dark full-width" onClick={() => openModal("protection")}><Icon name="shieldCheck" size={18} /> Acheter en toute confiance <Icon name="arrow" size={17} /></button><button className="button-outline full-width" onClick={() => openModal("offer")}><Icon name="message" size={17} /> Faire une offre</button><button className="link-action" onClick={() => openModal("offer")}><Icon name="chat" size={16} /> Poser une question au vendeur</button></div>
          <div className="delivery-estimate"><div className="delivery-estimate-icon"><Icon name="truck" size={20} /></div><div><b>Livraison estimée</b><span>Selon votre wilaya · 2 à 5 jours ouvrés</span></div><button onClick={() => notify("Sélectionnez votre wilaya dans la recherche pour estimer la livraison.")}><Icon name="chevron" size={17} /></button></div>
          <div className="seller-profile-card"><div className="seller-profile-head"><div className="seller-avatar-large">{product.sellerInitials}<span className="avatar-online" /></div><div className="seller-profile-copy"><div><b>{product.sellerName}</b>{product.sellerVerified && <Icon name="verified" size={16} className="verified-blue" />}</div><span>Vendeur depuis 2022 · {product.wilaya}</span></div><button aria-label="Ouvrir le profil vendeur" onClick={() => notify("Le profil public complet sera disponible prochainement.")}><Icon name="chevron" size={17} /></button></div><div className="seller-profile-stats"><div><Icon name="star" size={15} /><b>{product.rating.toFixed(1)}</b><span>note moyenne</span></div><div><Icon name="message" size={15} /><b>~ 18 min</b><span>temps de réponse</span></div><div><Icon name="shieldCheck" size={15} /><b>Niveau {product.trustTier}</b><span>confiance</span></div></div><div className="seller-profile-footer"><span><i /> En ligne récemment</span><Link href="/chat">Voir ses annonces <Icon name="arrow" size={14} /></Link></div></div>
          <div className="safe-meetup-card"><span className="safe-meetup-icon"><Icon name="map" size={18} /></span><div><b>Vous préférez une remise en main propre ?</b><small>Retrouvez-vous dans un lieu public et fréquenté.</small></div><button onClick={() => notify("Les lieux de rencontre vérifiés seront bientôt référencés.")}><Icon name="arrow" size={17} /></button></div>
          <div className="report-link"><button onClick={() => notify("Merci. Connectez-vous pour signaler cette annonce à notre équipe.")}><Icon name="flag" size={14} /> Signaler cette annonce</button><button onClick={shareProduct}><Icon name="external" size={14} /> Partager</button></div>
        </aside>
      </div>
      <BargainEscrowModal product={product} open={modalOpen} initialTab={modalTab} onClose={() => setModalOpen(false)} />
    </main>
  );
}
