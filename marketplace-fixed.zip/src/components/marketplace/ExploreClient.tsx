"use client";
/* eslint react/no-unescaped-entities: off -- Literal French apostrophes are safe JSX text. */

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { Icon } from "@/components/marketplace/Icon";
import { ProductCard } from "@/components/marketplace/ProductCard";
import { sampleProducts, wilayaOptions, type MarketProduct } from "@/lib/marketplace-data";
import { useMarketplace } from "@/components/marketplace/marketplace-provider";
import { cacheListings, getCachedListings } from "@/lib/offline-db";

const conditions = ["Toutes conditions", "Neuf", "Comme neuf", "Très bon état", "Bon état"];

export function ExploreClient({ initialQuery = "", initialWilaya = "Toutes les wilayas", initialCategory = "Toutes les catégories", favoritesOnly = false }: { initialQuery?: string; initialWilaya?: string; initialCategory?: string; favoritesOnly?: boolean }) {
  const [products, setProducts] = useState<MarketProduct[]>(sampleProducts);
  const [query, setQuery] = useState(initialQuery);
  const [wilaya, setWilaya] = useState(initialWilaya);
  const [category, setCategory] = useState(initialCategory);
  const [sort, setSort] = useState("relevance");
  const [condition, setCondition] = useState("Toutes conditions");
  const [maxPrice, setMaxPrice] = useState("");
  const [escrowOnly, setEscrowOnly] = useState(false);
  const [deliveryOnly, setDeliveryOnly] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [source, setSource] = useState<"sample" | "database" | "algolia">("sample");
  const { favorites } = useMarketplace();

  useEffect(() => {
    let active = true;
    void getCachedListings().then((items) => {
      if (active && items.length && !navigator.onLine) { setProducts(items); setSource("database"); }
    }).catch(() => undefined);
    return () => { active = false; };
  }, []);

  useEffect(() => {
    let active = true;
    const params = new URLSearchParams();
    const searchTerm = query.trim();
    if (searchTerm) params.set("q", searchTerm);
    if (wilaya !== "Toutes les wilayas") params.set("wilaya", wilaya);
    const timeout = window.setTimeout(() => {
      fetch(`/api/listings${params.size ? `?${params.toString()}` : ""}`)
        .then(async (response) => response.ok ? response.json() as Promise<{ items?: MarketProduct[]; source?: string }> : null)
        .then((data) => {
          if (!active || !data?.items) return;
          if (data.source === "algolia") {
            setProducts(data.items);
            setSource("algolia");
            if (data.items.length) void cacheListings(data.items).catch(() => undefined);
          } else if (data.items.length) {
            setProducts(data.items);
            setSource("database");
            void cacheListings(data.items).catch(() => undefined);
          }
        })
        .catch(() => undefined);
    }, searchTerm ? 180 : 0);
    return () => { active = false; window.clearTimeout(timeout); };
  }, [query, wilaya]);

  const visibleProducts = useMemo(() => {
    const filtered = products.filter((product) => {
      const term = query.trim().toLocaleLowerCase("fr");
      const matchesQuery = !term || `${product.title} ${product.category} ${product.wilaya} ${product.commune}`.toLocaleLowerCase("fr").includes(term);
      const matchesWilaya = wilaya === "Toutes les wilayas" || product.wilaya.toLocaleLowerCase("fr") === wilaya.toLocaleLowerCase("fr");
      const matchesCategory = category === "Toutes les catégories" || product.category.toLocaleLowerCase("fr").includes(category.toLocaleLowerCase("fr"));
      const matchesCondition = condition === "Toutes conditions" || product.condition === condition;
      const matchesPrice = !maxPrice || product.price <= Number(maxPrice);
      return matchesQuery && matchesWilaya && matchesCategory && matchesCondition && matchesPrice && (!escrowOnly || product.escrow) && (!deliveryOnly || product.delivery) && (!favoritesOnly || favorites.includes(product.id));
    });
    if (sort === "price-up") return filtered.sort((a, b) => a.price - b.price);
    if (sort === "price-down") return filtered.sort((a, b) => b.price - a.price);
    if (sort === "newest") {
      const age = (posted: string) => posted.includes("min") ? 1 : posted.includes("1 h") ? 60 : posted.includes("2 h") ? 120 : posted.includes("3 h") ? 180 : posted.includes("4 h") ? 240 : posted.includes("5 h") ? 300 : posted.includes("Hier") ? 1440 : 2880;
      return filtered.sort((a, b) => age(a.posted) - age(b.posted));
    }
    return filtered;
  }, [products, query, wilaya, category, condition, maxPrice, escrowOnly, deliveryOnly, favoritesOnly, favorites, sort]);

  const resetFilters = () => { setQuery(""); setWilaya("Toutes les wilayas"); setCategory("Toutes les catégories"); setCondition("Toutes conditions"); setMaxPrice(""); setEscrowOnly(false); setDeliveryOnly(false); };
  return (
    <main className="market-container explore-page">
      <div className="breadcrumbs"><Link href="/">Accueil</Link><Icon name="chevron" size={13} /><span>Explorer le marché</span></div>
      <div className="explore-intro"><div><p className="section-kicker">VOTRE PROCHAIN COUP DE CŒUR</p><h1>À vous de trouver.</h1><p>Un marché local, des vendeurs vérifiés, des trouvailles dans les 58 wilayas.</p></div><div className="explore-live"><span className="pulse-dot" />{source !== "sample" ? "Annonces en direct" : "Sélection du moment"}<small>· actualisé à l'instant</small></div></div>
      <div className="explore-toolbar"><label className="explore-search"><Icon name="search" size={19} /><input aria-label="Chercher dans les annonces" placeholder="Ex. iPhone, appartement, vélo…" value={query} onChange={(event) => setQuery(event.target.value)} /><kbd>⌘ K</kbd></label><button className={`filter-toggle ${showFilters ? "selected" : ""}`} onClick={() => setShowFilters(!showFilters)}><Icon name="sliders" size={17} /> Filtres <span>{[wilaya !== "Toutes les wilayas", category !== "Toutes les catégories", condition !== "Toutes conditions", Boolean(maxPrice), escrowOnly, deliveryOnly].filter(Boolean).length || ""}</span></button><label className="sort-select"><span>Trier par</span><select value={sort} onChange={(event) => setSort(event.target.value)}><option value="relevance">Pertinence</option><option value="newest">Plus récentes</option><option value="price-up">Prix croissant</option><option value="price-down">Prix décroissant</option></select><Icon name="chevron" size={15} /></label></div>
      <div className="explore-layout">
        <aside className={`filter-sidebar ${showFilters ? "is-open" : ""}`}>
          <div className="filter-heading"><b>Affiner la recherche</b><button onClick={resetFilters}>Tout effacer</button></div>
          <label className="filter-field">Catégorie<select value={category} onChange={(event) => setCategory(event.target.value)}><option>Toutes les catégories</option>{[...new Set(sampleProducts.map((product) => product.category))].map((item) => <option key={item}>{item}</option>)}</select></label>
          <label className="filter-field">Wilaya<select value={wilaya} onChange={(event) => setWilaya(event.target.value)}>{wilayaOptions.map((item) => <option key={item}>{item}</option>)}</select></label>
          <div className="filter-field"><span>Budget maximum</span><div className="price-input-wrap"><input inputMode="numeric" type="number" min="0" placeholder="Sans limite" value={maxPrice} onChange={(event) => setMaxPrice(event.target.value)} /><span>DA</span></div><div className="range-shortcuts"><button onClick={() => setMaxPrice("50000")}>≤ 50k</button><button onClick={() => setMaxPrice("150000")}>≤ 150k</button><button onClick={() => setMaxPrice("300000")}>≤ 300k</button></div></div>
          <label className="filter-field">État de l'article<select value={condition} onChange={(event) => setCondition(event.target.value)}>{conditions.map((item) => <option key={item}>{item}</option>)}</select></label>
          <div className="filter-separator" /><div className="filter-field filter-checks"><span>Un achat plus serein</span><label><input type="checkbox" checked={escrowOnly} onChange={(event) => setEscrowOnly(event.target.checked)} /><span className="fake-checkbox"><Icon name="check" size={12} /></span><span><b>Achat protégé</b><small>Option de transaction sécurisée</small></span><Icon name="shieldCheck" size={16} /></label><label><input type="checkbox" checked={deliveryOnly} onChange={(event) => setDeliveryOnly(event.target.checked)} /><span className="fake-checkbox"><Icon name="check" size={12} /></span><span><b>Livraison disponible</b><small>Expédition vers ma wilaya</small></span><Icon name="truck" size={16} /></label></div>
          <div className="filter-help"><Icon name="shieldCheck" size={18} /><span><b>Votre sécurité, d'abord.</b><small>Consultez nos conseils avant chaque échange.</small></span><Icon name="chevron" size={15} /></div>
        </aside>
        <section className="explore-results">
          <div className="results-heading"><div><b>{visibleProducts.length} annonce{visibleProducts.length !== 1 ? "s" : ""}</b><span>{wilaya === "Toutes les wilayas" ? " dans toute l'Algérie" : ` près de ${wilaya}`}</span></div><button className="map-view" onClick={() => window.alert("La carte interactive sera disponible avec le fournisseur cartographique configuré.")}><Icon name="map" size={17} /> Vue carte</button></div>
          {favoritesOnly && <div className="favorites-notice"><Icon name="heart" size={17} /> Vos annonces sauvegardées <Link href="/explore">Voir tout le marché</Link></div>}
          {visibleProducts.length ? <div className="product-grid explore-product-grid">{visibleProducts.map((product, index) => <ProductCard key={product.id} product={product} index={index} />)}</div> : <div className="empty-results"><span><Icon name="search" size={23} /></span><h3>Aucune annonce ne correspond pour le moment.</h3><p>Essayez d'élargir votre recherche ou de retirer quelques filtres.</p><button className="button-dark" onClick={resetFilters}>Effacer les filtres</button></div>}
          <div className="load-more-note"><span>✓</span> Vous êtes à jour — de nouvelles trouvailles arrivent chaque jour.</div>
        </section>
      </div>
    </main>
  );
}
