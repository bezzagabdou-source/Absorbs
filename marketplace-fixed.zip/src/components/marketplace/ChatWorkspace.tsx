"use client";
/* eslint react/no-unescaped-entities: off -- Literal French apostrophes are safe JSX text. */

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { Icon } from "@/components/marketplace/Icon";
import { useMarketplace } from "@/components/marketplace/marketplace-provider";
import { formatPrice } from "@/lib/marketplace-data";

type ChatMessage = { id: number; sender: "me" | "them"; text: string; time: string; kind?: "offer" | "location" | "voice" };
type Conversation = { id: string; name: string; initials: string; color: string; product: string; price: number; image: string; time: string; unread: number; preview: string; verified: boolean; messages: ChatMessage[] };

const startConversations: Conversation[] = [
  { id: "yacine", name: "Yacine B.", initials: "YB", color: "lilac", product: "iPhone 15 Pro Max · 256 Go", price: 218000, image: "https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?auto=format&fit=crop&w=240&q=80", time: "10:42", unread: 2, preview: "Bonjour, l'article est-il toujours disponible ?", verified: true, messages: [{ id: 1, sender: "them", text: "Bonjour Amel ! Votre MacBook m'intéresse, est-il toujours disponible ?", time: "10:34" }, { id: 2, sender: "me", text: "Bonjour Yacine, oui il est toujours disponible. Je peux vous envoyer d'autres photos si vous voulez.", time: "10:37" }, { id: 3, sender: "them", text: "Super, merci ! Je suis sur Alger. Une remise en main propre est possible ?", time: "10:40" }, { id: 4, sender: "them", text: "Bonjour, l'article est-il toujours disponible ?", time: "10:42" }] },
  { id: "nesrine", name: "Nesrine A.", initials: "NA", color: "peach", product: "MacBook Air M2 · 13 pouces", price: 198000, image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=240&q=80", time: "Hier", unread: 0, preview: "Je peux venir le récupérer ce soir.", verified: true, messages: [{ id: 5, sender: "them", text: "Bonsoir, je suis intéressée par votre annonce. Le chargeur est inclus ?", time: "Hier" }, { id: 6, sender: "me", text: "Oui, le chargeur et la housse sont inclus dans le prix 🙂", time: "Hier" }, { id: 7, sender: "them", text: "Parfait, je peux venir le récupérer ce soir.", time: "Hier" }] },
  { id: "karim", name: "Karim Auto", initials: "KA", color: "blue", product: "Toyota Yaris 2021", price: 2850000, image: "https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?auto=format&fit=crop&w=240&q=80", time: "Hier", unread: 0, preview: "Offre envoyée · 2 750 000 DA", verified: true, messages: [{ id: 8, sender: "them", text: "Bonjour, votre Toyota est disponible pour un essai ?", time: "Hier" }, { id: 9, sender: "me", text: "Oui, samedi matin est possible à Sétif.", time: "Hier" }, { id: 10, sender: "them", text: "Offre envoyée · 2 750 000 DA", time: "Hier", kind: "offer" }] },
  { id: "meriem", name: "Meriem O.", initials: "MO", color: "mint", product: "Casque Sony WH-1000XM5", price: 52000, image: "https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=240&q=80", time: "Lun.", unread: 0, preview: "Merci pour votre réponse !", verified: true, messages: [{ id: 11, sender: "me", text: "L'envoi est possible vers Béjaïa, les frais sont à confirmer avec le transporteur.", time: "Lun." }, { id: 12, sender: "them", text: "Merci pour votre réponse !", time: "Lun." }] },
];

const nowLabel = () => new Intl.DateTimeFormat("fr-DZ", { hour: "2-digit", minute: "2-digit" }).format(new Date());

export function ChatWorkspace() {
  const [conversations, setConversations] = useState(startConversations);
  const [activeId, setActiveId] = useState("yacine");
  const [message, setMessage] = useState("");
  const [search, setSearch] = useState("");
  const [offerOpen, setOfferOpen] = useState(false);
  const [offerAmount, setOfferAmount] = useState("200000");
  const [recording, setRecording] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const { notify } = useMarketplace();
  const active = conversations.find((conversation) => conversation.id === activeId) ?? conversations[0];

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [active?.messages]);

  const appendMessage = (text: string, kind?: ChatMessage["kind"]) => {
    if (!active) return;
    const next: ChatMessage = { id: Date.now(), sender: "me", text, time: nowLabel(), kind };
    setConversations((current) => current.map((conversation) => conversation.id === activeId ? { ...conversation, messages: [...conversation.messages, next], preview: text, time: "Maintenant", unread: 0 } : conversation));
  };
  const sendMessage = () => { const trimmed = message.trim(); if (!trimmed) return; appendMessage(trimmed); setMessage(""); };
  const sendLocation = () => {
    if (!navigator.geolocation) { notify("La géolocalisation n'est pas disponible sur cet appareil."); return; }
    navigator.geolocation.getCurrentPosition((position) => { appendMessage(`📍 Position partagée · ${position.coords.latitude.toFixed(3)}, ${position.coords.longitude.toFixed(3)}`, "location"); notify("Votre position est ajoutée à la conversation locale."); }, () => notify("Autorisez la géolocalisation pour partager votre position."), { enableHighAccuracy: false, timeout: 8000 });
  };
  const toggleVoice = async () => {
    if (recording && recorderRef.current) { recorderRef.current.stop(); setRecording(false); return; }
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") { notify("L'enregistrement vocal n'est pas disponible dans ce navigateur."); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      recorderRef.current = recorder;
      recorder.onstop = () => { stream.getTracks().forEach((track) => track.stop()); appendMessage("Message vocal enregistré · 00:04", "voice"); };
      recorder.start(); setRecording(true); notify("Enregistrement en cours — appuyez à nouveau sur le micro pour terminer.");
      window.setTimeout(() => { if (recorder.state === "recording") { recorder.stop(); setRecording(false); } }, 10000);
    } catch { notify("Autorisez l'accès au microphone pour enregistrer un message vocal."); }
  };
  const sendOffer = () => { const amount = Number(offerAmount); if (!amount || amount < 1) return; appendMessage(`Proposition · ${formatPrice(amount)}`, "offer"); setOfferOpen(false); notify("Proposition ajoutée à cette conversation locale."); };

  return (
    <main className="market-container chat-page"><div className="breadcrumbs"><Link href="/">Accueil</Link><Icon name="chevron" size={13} /><span>Ma messagerie</span></div><div className="chat-heading"><div><p className="section-kicker">VOS ÉCHANGES EN UN SEUL ENDROIT</p><h1>On se parle ?</h1><p>Discutez, négociez et faites connaissance avant chaque échange.</p></div><span className="chat-privacy"><Icon name="lock" size={15} /> Conversations privées</span></div>
      <div className="chat-shell">
        <aside className="chat-sidebar"><div className="chat-sidebar-heading"><div><h2>Messages <span>{conversations.filter((conversation) => conversation.unread > 0).length}</span></h2><small>Restez proche de vos échanges.</small></div><button aria-label="Nouveau message" onClick={() => notify("Pour commencer une discussion, ouvrez une annonce et contactez son vendeur.")}><Icon name="plusCircle" size={20} /></button></div><label className="chat-search"><Icon name="search" size={16} /><input placeholder="Rechercher une conversation…" value={search} onChange={(event) => setSearch(event.target.value)} /><kbd>⌘ K</kbd></label><div className="chat-filter-tabs"><button className="active">Tout <span>{conversations.length}</span></button><button>Non lus <span>{conversations.filter((item) => item.unread).length}</span></button></div><div className="conversation-list">{conversations.filter((conversation) => `${conversation.name} ${conversation.product}`.toLowerCase().includes(search.toLowerCase())).map((conversation) => <button key={conversation.id} className={`conversation-item ${activeId === conversation.id ? "active" : ""}`} onClick={() => { setActiveId(conversation.id); setConversations((current) => current.map((item) => item.id === conversation.id ? { ...item, unread: 0 } : item)); }}><span className={`chat-avatar chat-avatar-${conversation.color}`}>{conversation.initials.slice(0, 1)}</span><span className="conversation-copy"><span className="conversation-name">{conversation.name}{conversation.verified && <Icon name="verified" size={13} />}</span><span className="conversation-preview">{conversation.preview}</span></span><span className="conversation-time">{conversation.time}{conversation.unread > 0 && <i>{conversation.unread}</i>}</span></button>)}</div><div className="chat-safety-tip"><span><Icon name="shieldCheck" size={17} /></span><p><b>Gardez vos échanges ici.</b><small>Ne partagez jamais de code OTP ou de coordonnées bancaires.</small></p><Icon name="chevron" size={15} /></div></aside>
        <section className="chat-thread"><div className="thread-header"><div className={`chat-avatar chat-avatar-${active.color}`}>{active.initials.slice(0, 1)}<i /></div><div className="thread-person"><span><b>{active.name}</b>{active.verified && <Icon name="verified" size={14} />}</span><small><i /> Actif récemment · Profil vérifié</small></div><div className="thread-actions"><button aria-label="Partager ma position" onClick={sendLocation}><Icon name="map" size={18} /></button><button aria-label="Plus d'options" onClick={() => notify("Actions de conversation") }><Icon name="more" size={20} /></button></div></div>
          <Link href="/product/iphone-15-pro-max-256" className="thread-product"><span style={{ backgroundImage: `url("${active.image}")` }} /><span><small>ANNONCE CONCERNÉE</small><b>{active.product}</b><strong>{formatPrice(active.price)}</strong></span><Icon name="external" size={16} /></Link>
          <div className="thread-day-divider"><span>Aujourd'hui</span></div><div className="thread-messages">{active.messages.map((item) => <div key={item.id} className={`message-row ${item.sender === "me" ? "mine" : "theirs"}`}><div className={`message-bubble ${item.kind ?? ""}`}>{item.kind === "offer" ? <div className="offer-message-card"><span><Icon name="tag" size={16} /> OFFRE PROPOSÉE</span><b>{item.text.replace("Proposition · ", "")}</b><small>En attente de réponse</small></div> : item.kind === "location" ? <div className="location-message"><Icon name="map" size={18} /><span>{item.text}</span></div> : item.kind === "voice" ? <div className="voice-message"><button onClick={() => notify("Le fichier audio n'est pas conservé dans cette maquette locale.")}><Icon name="plus" size={14} /></button><span className="voice-wave">▂ ▅ ▃ ▆ ▄ ▇ ▃ ▅ ▂ ▄ ▆ ▃</span><small>0:04</small></div> : item.text}<span className="message-time">{item.time}{item.sender === "me" && <i>✓✓</i>}</span></div></div>)}<div ref={bottomRef} /></div>
          {offerOpen && <div className="chat-offer-composer"><span><Icon name="tag" size={17} /> Faire une offre</span><label><input type="number" min="1" inputMode="numeric" value={offerAmount} onChange={(event) => setOfferAmount(event.target.value)} /><b>DA</b></label><button onClick={sendOffer}>Envoyer l'offre <Icon name="arrow" size={14} /></button><button className="offer-close" aria-label="Fermer" onClick={() => setOfferOpen(false)}><Icon name="close" size={17} /></button></div>}
          <div className="chat-composer"><div className="composer-tools"><button aria-label="Ajouter une offre" onClick={() => setOfferOpen(!offerOpen)}><Icon name="tag" size={17} /></button><button aria-label="Partager ma position" onClick={sendLocation}><Icon name="map" size={17} /></button><button aria-label="Message vocal" className={recording ? "recording" : ""} onClick={() => void toggleVoice()}><Icon name="mic" size={17} /></button><button aria-label="Ajouter une photo" onClick={() => notify("Le partage photo sera disponible après activation du stockage sécurisé.")}><Icon name="camera" size={17} /></button></div><div className="composer-input-row"><textarea aria-label="Écrire un message" placeholder="Écrire un message…" rows={1} value={message} onChange={(event) => setMessage(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); sendMessage(); } }} /><button className="send-message-button" onClick={sendMessage} aria-label="Envoyer le message"><Icon name="send" size={17} /></button></div><div className="composer-footer"><span><Icon name="lock" size={12} /> Vos coordonnées restent privées jusqu'à votre accord.</span><small>Entrée pour envoyer · Maj + Entrée pour une nouvelle ligne</small></div></div>
        </section>
      </div><div className="chat-realtime-note"><Icon name="info" size={14} /> Les messages affichés sont une démo locale. L'envoi temps réel nécessite un fournisseur de sessions et un serveur de messagerie configurés.</div></main>
  );
}
