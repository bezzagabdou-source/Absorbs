# DZ Exchange / DZD Market

An Algeria-first, multi-vendor marketplace foundation built with the existing Next.js App Router, Tailwind CSS v4, PostgreSQL and Drizzle ORM setup. The preview ships with sample listings so all primary screens remain usable before external provider credentials and catalog data are configured.

## Run locally

1. Copy `.env.example` to `.env.local` and set `DATABASE_URL` to a local PostgreSQL or pooled Neon connection string.
2. Install dependencies with `npm install`.
3. Apply the schema: `npx drizzle-kit push`.
4. Seed the 58 wilayas and starter categories with Drizzle: `npx tsx -r dotenv/config src/db/seed-reference-data.ts`.
5. Start the app with `npm run dev`.

The standard database credentials in `drizzle.config.json` are the sandbox's local PostgreSQL defaults; production deployments should replace them with environment-managed credentials. Never commit `.env.local` or provider keys.

## Routes

- `/` — editorial storefront, category discovery, local search, trust signals and featured listings.
- `/explore` — search, wilaya/category/condition/price filters, delivery and escrow eligibility, favorites, and Dexie cached results.
- `/product/[id]` — listing gallery, seller trust presentation, price history visualization, delivery estimate, offer modal and escrow disclosure.
- `/dashboard` — vendor analytics, listing manager, transaction and dispute panels.
- `/chat` — responsive conversation UI, offer composer, browser voice/location hooks.
- `/settings` — language, security/KYC, theme, offline storage, data saver, notification and payment settings.

## Technical notes

- The checked-in baseline is Next.js 16. The App Router route shapes and async `params`/`searchParams` conventions used here are also compatible with current Next.js 15. The project was not downgraded because that would be an unnecessary breaking change to the prepared sandbox.
- Public listings use a server-only Algolia adapter when configured and fall back to Drizzle at `GET /api/listings`; `POST /api/offers` and `POST /api/push/subscriptions` require the HMAC-signed `dz_session` cookie described in `docs/architecture.md`.
- Push permission can be requested in settings. Sending push notifications still requires VAPID credentials and a server-side sender.
- The deployed `public/sw.js` is the authoritative service worker. TypeScript source is kept in `src/sw.ts`. It caches public pages only, deliberately excludes `/api/*`, provides an offline fallback, handles push clicks, and drains an IndexedDB outbox on Background Sync where supported.
- Payment, escrow, KYC, identity, transport, reverse-image search, AI and realtime chat are provider boundaries, not simulated financial/security guarantees. UI calls that need credentials say so explicitly.

See [docs/architecture.md](docs/architecture.md) for the project tree, schema, state model, security, RLS, scale plan and provider activation checklist.
