# R1HIMO SHOP — لوحة الإدارة داخل البوت

التحكم بالكامل من `/admin` داخل محادثة تيليغرام الخاصة بالمالك أو المشرف. لا توجد لوحة ويب ولا واجهة API للبيع في هذه النسخة. الأزرار تشمل المنتجات والمخزون والتصنيفات والقائمة والمستخدمين والأرصدة والطلبات والشحن والنصوص والإعدادات والخصومات والإذاعة.

## التشغيل

- على Vercel يتلقى `api/index.py` تحديثات Telegram بواسطة webhook؛ البيانات محفوظة في PostgreSQL عبر `DATABASE_URL_UNPOOLED`. عرّف كذلك `BOT_TOKEN` و`OWNER_ID` في متغيرات المشروع. لا تضع التوكن في السورس.
- يتطلب إعداد webhook الأولي عنوان `/api/telegram` وسرّاً مشتقاً من التوكن. عند تحديث نشر قائم مع نفس التوكن والرابط يبقى webhook السابق فعالاً. لإعداد نشر جديد فقط، عرّف `BOT_TOKEN` و`PUBLIC_URL` محلياً ثم نفّذ:

```sh
python3 - <<'PY'
import hashlib, hmac, json, os, urllib.request
secret = hmac.new(os.environ['BOT_TOKEN'].encode(), b'r1himo-telegram-webhook-v1', hashlib.sha256).hexdigest()
url = os.environ['PUBLIC_URL'].rstrip('/') + '/api/telegram'
req = urllib.request.Request('https://api.telegram.org/bot' + os.environ['BOT_TOKEN'] + '/setWebhook',
    data=json.dumps({'url':url,'secret_token':secret,'allowed_updates':['message','callback_query'],'max_connections':1}).encode(),
    headers={'Content-Type':'application/json'})
with urllib.request.urlopen(req, timeout=30) as response:
    print('تم تفعيل webhook' if json.load(response).get('ok') else 'تعذر تفعيل webhook')
PY
```
- نسخة `rabot.py` تعمل محلياً بتقنية long polling وSQLite بعد ضبط `BOT_TOKEN` و`OWNER_ID` وتشغيل `python3 rabot.py`. استعمل توكن وقاعدة بيانات منفصلين لكل نسخة، ولا تشغل polling وwebhook للبوت نفسه في الوقت ذاته.
- القيمة الافتراضية لـ`OWNER_ID` هي `6818164226`، ويجب تغييرها إلى معرّف المالك الجديد عند نقل أو بيع النسخة. تفقد صلاحيات المشرفين أيضاً قبل نقل قاعدة بيانات قديمة.
- لم تعد هناك كلمة سر للوحة الويب؛ يتحقق البوت من معرّف تيليغرام وصلاحية المشرف، وليس كلمة سر.

النسخة الجديدة لا تحذف بيانات قاعدة الإنتاج السابقة. قواعد البيانات الجديدة تبدأ دون منتجات أو مخزون وهمي؛ يضيف المالك المنتجات ويضبط أسعارها ومخزونها وظهورها من `/admin`.

## الإذاعة والنسخ الاحتياطي

الإرسال من `/admin` بعد المعاينة والتأكيد؛ لأكثر من 20 مستلماً يجب ضغط «متابعة» لكل دفعة. الزر الخاص بالنسخة الاحتياطية متاح للمالك ويرسل بيانات حساسة على الخاص: ملف SQLite محلياً، أو تصدير JSON للبيانات على Vercel (حتى 45 ميغابايت). تصدير JSON ليس استعادة تلقائية لقاعدة البيانات؛ احتفظ أيضاً بنسخ احتياطية من مزود PostgreSQL.

## الاختبارات

```sh
python3 test_sqlite_financial.py
python3 -m pip install 'psycopg[binary]' pgserver
python3 test_pg_store.py
python3 test_webhook.py
```

الاختبارات تستخدم PostgreSQL مؤقتاً وTelegram وهمياً؛ لا تغني عن تجربة حقيقية. تُسجّل أرقام تحديثات Telegram قبل التنفيذ لتقليل التكرار، وقد يضيع تحديث إذا توقفت الدالة أثناء المعالجة، وقد تتكرر بعض رسائل الإذاعة عند انقطاع الخدمة قبل حفظ تقدم الدفعة. لا تستخدم أموالاً حقيقية قبل مراجعة واختبار شاملين.
